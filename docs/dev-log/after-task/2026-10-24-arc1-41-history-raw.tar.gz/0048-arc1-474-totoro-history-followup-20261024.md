Read-only archive-location follow-up (2026-10-24):

- With the existing Totoro ControlMaster, a depth-two home-directory search found `~/hsq_work`, the `~/h2-grid` tree, and DRM-TMB Arc 1 directories under `~/sim-archive`. In `h2-grid`, a bounded filename-only search found no Arc 1 attempt outputs, admissions, seed-audit receipts, or consumed-attempt-history files. The matches were prepared-fix receipts for other package checks.
- The named account-specific `/scratch/snakagaw` and `/project/def-snakagaw*` roots were absent or not mounted.
- A name-only scan of the retained 20 October pilot roots found per-outer admissions and summary files, but no separate complete-history pair. This does not rule out records with other names, contents inside archives, or stores outside these checked paths.

No fit or seed rerun was started. No acceptance gate receives credit from this inventory; the exact source-bound pilot receipts and complete history scope remain unresolved.
