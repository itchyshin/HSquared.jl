using Test, HSquared, REPL, Markdown
using LinearAlgebra
BLAS.set_num_threads(1)
@testset "canonical content controls" begin
    phrase = "no coefcov payload fitting route is currently wired"
    coefcov_doc = Docs.doc(Docs.Binding(HSquared, :fit_payload_v2))
    @test coefcov_doc isa Markdown.MD
    rendered = sprint(show, MIME"text/plain"(), coefcov_doc)
    content = replace(rendered, r"\s+" => " ")
    @test occursin(phrase, content)
    @test !occursin(phrase, replace(content, phrase => "a coefcov payload fitting route is now wired"))
    @test !occursin(phrase, replace(content, phrase => ""))
    help = replace(sprint(show, MIME"text/plain"(), Docs.doc(Docs.Binding(HSquared, :fit_animal_model))), r"\s+" => " ")
    @test occursin("AnimalModelSpec", help)
    @test occursin("y, X, Z, Ainv", help)
    @test all(target -> occursin(target, help), (":variance_components", ":sparse_reml", ":ai_reml", ":henderson_mme"))
    @test !occursin("intentionally not implemented in Phase 0", help)
    @test haskey(Docs.meta(HSquared), Docs.Binding(HSquared, :fit_payload_v2))
end
println("RUNTIME=", VERSION)
