using Test, HSquared, REPL, Markdown
using LinearAlgebra
BLAS.set_num_threads(1)
@testset "canonical content controls" begin
    phrase = "no coefcov payload fitting route is currently wired"
    coefcov_doc = Base.Docs.doc(HSquared.fit_payload_v2)
    @test coefcov_doc isa Markdown.MD
    content = string(coefcov_doc)
    @test occursin(phrase, content)
    @test !occursin(phrase, replace(content, phrase => "a coefcov payload fitting route is now wired"))
    @test !occursin(phrase, replace(content, phrase => ""))
    help = string(Base.Docs.doc(HSquared.fit_animal_model))
    @test occursin("AnimalModelSpec", help)
    @test occursin("y, X, Z, Ainv", help)
    @test all(target -> occursin(target, help), (":variance_components", ":sparse_reml", ":ai_reml", ":henderson_mme"))
    @test !occursin("intentionally not implemented in Phase 0", help)
    @test haskey(Docs.meta(HSquared), Docs.Binding(HSquared, :fit_payload_v2))
end
println("RUNTIME=", VERSION)
