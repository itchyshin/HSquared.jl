using HSquared,Test,LinearAlgebra,SparseArrays,REPL
    ped_ids  = [1, 2, 3, 4]
    ped_sire = [0, 0, 1, 1]
    ped_dam  = [0, 0, 2, 2]
    Ainv_direct = pedigree_inverse(ped_ids, ped_sire, ped_dam)

    # 8 records, 2 per animal.
    Z_animal = zeros(8, 4)
    for (rec, an) in enumerate([1, 1, 2, 2, 3, 3, 4, 4]); Z_animal[rec, an] = 1.0; end
    y_obs = [14.0, 13.0, 6.9, 6.1, 12.1, 11.5, 8.9, 8.5]
    X_int = ones(8, 1)  # intercept

    # Helper: build a pedigree sub-dict suitable for a block.
    pedigree_rows = Dict("id" => ped_ids, "sire" => ped_sire, "dam" => ped_dam)
    @testset "(e) malformed block errors" begin
        # Unknown block type
        @test_throws ArgumentError parse_payload_v2(Dict(
            "payload_version" => 2,
            "y" => y_obs, "X" => X_int,
            "random_effects" => [Dict("name" => "x", "type" => "unknown",
                                      "Z" => Z_animal, "relmat_status" => "identity")],
        ))

        # Missing Z incidence matrix
        @test_throws ArgumentError parse_payload_v2(Dict(
            "payload_version" => 2,
            "y" => y_obs, "X" => X_int,
            "random_effects" => [Dict("name" => "a", "type" => "iid",
                                      "relmat_status" => "identity")],
        ))

        # Missing required block envelope key: do not silently default ids.
        @test_throws ArgumentError parse_payload_v2(Dict(
            "payload_version" => 2,
            "y" => y_obs, "X" => X_int,
            "random_effects" => [Dict("name" => "a", "type" => "iid",
                                      "Z" => Z_animal,
                                      "relmat_status" => "identity")],
        ))

        # Dimension mismatch: Z has wrong number of rows
        Z_bad = zeros(5, 4)   # 5 rows vs 8 obs
        @test_throws ArgumentError parse_payload_v2(Dict(
            "payload_version" => 2,
            "y" => y_obs, "X" => X_int,
            "random_effects" => [Dict("name" => "a", "type" => "iid",
                                      "Z" => Z_bad, "relmat_status" => "identity")],
        ))

        # Dimension mismatch: Z cols != relmat_inverse dim (supplied)
        Ainv_wrong = Matrix(I, 3, 3)   # 3×3 but Z has 4 columns
        @test_throws ArgumentError parse_payload_v2(Dict(
            "payload_version" => 2,
            "y" => y_obs, "X" => X_int,
            "random_effects" => [Dict("name" => "a", "type" => "pedigree",
                                      "Z" => Z_animal, "relmat_status" => "supplied",
                                      "relmat_inverse" => Ainv_wrong)],
        ))

        # correlated block missing partner_incidence
        @test_throws ArgumentError parse_payload_v2(Dict(
            "payload_version" => 2,
            "y" => y_obs, "X" => X_int,
            "random_effects" => [Dict(
                "name" => "animal", "type" => "correlated",
                "Z" => Z_animal, "relmat_status" => "build_in_julia",
                "pedigree" => pedigree_rows,
            )],
        ))

        # Duplicate block names
        @test_throws ArgumentError parse_payload_v2(Dict(
            "payload_version" => 2,
            "y" => y_obs, "X" => X_int,
            "random_effects" => [
                Dict("name" => "animal", "type" => "iid",
                     "Z" => Z_animal, "relmat_status" => "identity"),
                Dict("name" => "animal", "type" => "iid",
                     "Z" => Z_animal, "relmat_status" => "identity"),
            ],
        ))

        # Multiple correlated blocks: not supported
        Zm2 = zeros(8, 4); for (r, d) in enumerate([1,2,1,2,1,2,1,2]); Zm2[r,d] = 1.0; end
        @test_throws ArgumentError parse_payload_v2(Dict(
            "payload_version" => 2,
            "y" => y_obs, "X" => X_int,
            "random_effects" => [
                Dict("name" => "a1", "type" => "correlated", "Z" => Z_animal,
                     "relmat_status" => "build_in_julia", "pedigree" => pedigree_rows,
                     "partner_incidence" => Zm2),
                Dict("name" => "a2", "type" => "correlated", "Z" => Z_animal,
                     "relmat_status" => "build_in_julia", "pedigree" => pedigree_rows,
                     "partner_incidence" => Zm2),
            ],
        ))

        # A single coefcov block parses, but its fit route is not wired. Keep
        # the error accurate for this one-block case as well as multi-blocks.
        coefcov_payload = Dict(
            "payload_version" => 2,
            "y" => y_obs,
            "X" => X_int,
            "random_effects" => [Dict(
                "name" => "slope",
                "type" => "coefcov",
                "Z" => Z_animal,
                "relmat_status" => "identity",
                "ids" => ped_ids,
                "basis" => "raw",
                "order" => 2,
                "Phi" => hcat(ones(length(y_obs)), collect(1.0:length(y_obs))),
                "covariate" => "time",
                "cov_structure" => "unstructured",
            )],
        )
        parsed_coefcov = parse_payload_v2(coefcov_payload)
        @test parsed_coefcov.dispatch == :coefcov
        coefcov_error = try
            fit_payload_v2(coefcov_payload)
            nothing
        catch err
            err
        end
        @test coefcov_error isa Phase0NotImplementedError
        coefcov_message = sprint(showerror, coefcov_error)
        @test occursin("no coefcov payload fitting route is currently wired", coefcov_message)
        @test !occursin("multi-block", coefcov_message)
        coefcov_doc = string(Base.Docs.doc(fit_payload_v2))
        @test occursin("no coefcov payload fitting route is currently wired", coefcov_doc)
    end
include(joinpath(@__DIR__,"candidate/test/test_api_docstrings.jl"))
println("DOC_CONTRACTS_PASS")
