using HSquared
phrase="no coefcov payload fitting route is currently wired"
raw=(@doc fit_payload_v2)
println("raw type=",typeof(raw)," phrase=",occursin(phrase,string(raw)))
using REPL
document=Base.Docs.doc(fit_payload_v2)
plain=sprint(show,MIME"text/plain"(),document)
println("document type=",typeof(document)," string phrase=",occursin(phrase,string(document))," plain phrase=",occursin(phrase,plain))
println("STRING_DOC=",repr(string(document)))
