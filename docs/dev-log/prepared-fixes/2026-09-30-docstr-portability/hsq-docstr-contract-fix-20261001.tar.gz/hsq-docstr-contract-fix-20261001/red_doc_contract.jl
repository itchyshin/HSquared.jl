using HSquared, Test
@testset "existing coefcov unsupported doc contract" begin
    coefcov_doc = string(@doc fit_payload_v2)
    @test occursin("no coefcov payload fitting route is currently wired", coefcov_doc)
end
