# Multivariate (multi-trait) Gaussian animal model — Phase 4 start.
#
# Supplied-(co)variance Henderson MME for the balanced multi-trait animal model,
# the multivariate analogue of `henderson_mme` / `two_effect_mme`. It does NOT
# estimate the genetic/residual covariance matrices (that is a separate REML/EM
# slice). Experimental, validation-scale, engine-internal.

"""
    genetic_correlation(C::AbstractMatrix)
    genetic_correlation(result)

Convert a symmetric covariance matrix `C` (e.g. the additive genetic covariance
`G0` or residual covariance `R0`) into the corresponding correlation matrix
`D⁻¹ C D⁻¹`, with `D = diag(sqrt.(diag(C)))`. Diagonal entries are exactly `1`.

The second method extracts `genetic_correlation` from a
[`multivariate_mme`](@ref) result `NamedTuple`. Requires positive diagonal
variances.
"""
function genetic_correlation(C::AbstractMatrix)
    n = size(C, 1)
    size(C, 2) == n || throw(ArgumentError("C must be square"))
    n > 0 || throw(ArgumentError("C must be nonempty"))
    Cf = Matrix{Float64}(C)
    all(isfinite, Cf) || throw(ArgumentError("C must contain only finite values"))
    scale = maximum(abs, Cf)
    isapprox(Cf, transpose(Cf); atol = 1e-12 * scale, rtol = 1e-12) ||
        throw(ArgumentError("C must be symmetric"))
    d = diag(Cf)
    all(>(0), d) || throw(ArgumentError("covariance diagonal must be positive"))
    # allow rank-deficient PSD (e.g. low-rank G); reject only indefinite inputs
    eigmin(Symmetric(Cf)) >= -1e-12 * scale ||
        throw(ArgumentError("C must be positive semidefinite"))
    s = sqrt.(d)
    R = Matrix{Float64}(undef, n, n)
    @inbounds for j in 1:n, i in 1:n
        R[i, j] = Cf[i, j] / s[i] / s[j]
    end
    all(isfinite, R) && eigmin(Symmetric(R)) >= -1e-12 ||
        throw(ArgumentError("C must be positive semidefinite after trait scaling"))
    # Only clip the negligible correlation overshoot allowed by roundoff.
    R .= clamp.(R, -1.0, 1.0)
    for i in 1:n
        R[i, i] = 1.0
    end
    return R
end

genetic_correlation(result::NamedTuple) = result.genetic_correlation

function _require_multivariate_result(result::NamedTuple)
    ok = hasproperty(result, :genetic_covariance) &&
         hasproperty(result, :residual_covariance) &&
         hasproperty(result, :beta) &&
         hasproperty(result, :breeding_values)
    ok ||
        throw(ArgumentError("result is not a multivariate HSquared result"))
    return result
end

"""
    variance_components(result::NamedTuple)

Return the genetic and residual covariance matrices from a multivariate
`HSquared` result as `(genetic_covariance, residual_covariance)`. When the
result is a multi-trait repeatability fit, also return `permanent_covariance`.
"""
function variance_components(result::NamedTuple)
    r = _require_multivariate_result(result)
    if hasproperty(r, :permanent_covariance)
        return (
            genetic_covariance = copy(r.genetic_covariance),
            permanent_covariance = copy(r.permanent_covariance),
            residual_covariance = copy(r.residual_covariance),
        )
    end
    return (
        genetic_covariance = copy(r.genetic_covariance),
        residual_covariance = copy(r.residual_covariance),
    )
end

"""
    fixed_effects(result::NamedTuple)

Return the fixed-effect matrix from a multivariate `HSquared` result.
"""
function fixed_effects(result::NamedTuple)
    return copy(_require_multivariate_result(result).beta)
end

"""
    breeding_values(result::NamedTuple)

Return the multivariate breeding-value metadata from a multivariate `HSquared`
result as `(ids, traits, values)`.
"""
function breeding_values(result::NamedTuple)
    bv = _require_multivariate_result(result).breeding_values
    ok = hasproperty(bv, :ids) && hasproperty(bv, :traits) && hasproperty(bv, :values)
    ok ||
        throw(ArgumentError("multivariate breeding_values metadata must contain ids, traits, and values"))
    return (
        ids = collect(bv.ids),
        traits = collect(bv.traits),
        values = copy(bv.values),
    )
end

"""
    heritability(result::NamedTuple)

Return the per-trait heritability vector from a multivariate REML result.
"""
function heritability(result::NamedTuple)
    r = _require_multivariate_result(result)
    hasproperty(r, :heritability) ||
        throw(ArgumentError("multivariate result does not contain heritability"))
    return copy(collect(r.heritability))
end

function _require_structured_genetic_metadata(result::NamedTuple)
    r = _require_multivariate_result(result)
    ok = hasproperty(r, :genetic_structure) &&
         hasproperty(r, :genetic_rank) &&
         hasproperty(r, :genetic_loadings) &&
         hasproperty(r, :genetic_uniqueness)
    ok ||
        throw(ArgumentError("multivariate result does not contain structured genetic metadata"))
    return r
end

"""
    genetic_structure(result::NamedTuple)

Return structured genetic covariance metadata from a multivariate REML result as
`(structure, rank)`.
"""
function genetic_structure(result::NamedTuple)
    r = _require_structured_genetic_metadata(result)
    return (structure = r.genetic_structure, rank = r.genetic_rank)
end

"""
    genetic_loadings(result::NamedTuple)

Return a copy of the structured genetic loading matrix from a low-rank or
factor-analytic multivariate REML result. Returns `nothing` when the fitted
structure has no loading matrix.
"""
function genetic_loadings(result::NamedTuple)
    L = _require_structured_genetic_metadata(result).genetic_loadings
    return isnothing(L) ? nothing : copy(L)
end

"""
    genetic_uniqueness(result::NamedTuple)

Return a copy of the structured genetic uniqueness vector from a multivariate
REML result. Returns `nothing` when the fitted structure has no uniqueness
metadata.
"""
function genetic_uniqueness(result::NamedTuple)
    ψ = _require_structured_genetic_metadata(result).genetic_uniqueness
    return isnothing(ψ) ? nothing : copy(collect(ψ))
end

"""
    multivariate_result_payload(result)

Bridge-ready, "boring" result payload (a `NamedTuple` of scalars / arrays /
nested `NamedTuple`s — Julia structs stay Julia-side) for a multivariate REML
fit from [`fit_multivariate_reml`](@ref). It mirrors [`result_payload`](@ref) for
the univariate animal model so the R twin can marshal one shape across traits.

Exposed only for the **rotation-free** genetic structures `:unstructured` and
`:diagonal`. `:lowrank` / `:factor_analytic` are rejected on purpose: their
loadings are rotation-nonidentified, so surfacing them across the bridge needs a
rotation/interpretation convention first. The payload carries the estimated
`G0`/`R0`, the per-trait genetic variances `diag(G0)`, the genetic/residual
correlations, the REML `loglik`, the genetic parameter count `n_genetic_params`
(so a `:diagonal`-vs-`:unstructured` LRT `df` is just the difference of the two
fits' counts), the fixed effects, breeding values, per-trait heritabilities, and
`converged`. It deliberately omits `genetic_loadings` / `genetic_uniqueness`.
"""
function multivariate_result_payload(result)
    s = getproperty(result, :genetic_structure)
    s in (:unstructured, :diagonal) || throw(ArgumentError(
        "multivariate_result_payload is bridge-exposed only for :unstructured and " *
        ":diagonal; :lowrank/:factor_analytic loadings are rotation-nonidentified " *
        "and gated on a rotation/interpretation convention"))
    G0 = Matrix(result.genetic_covariance)
    R0 = Matrix(result.residual_covariance)
    t = size(G0, 1)
    n_genetic_params = s == :diagonal ? t : t * (t + 1) ÷ 2
    bv = result.breeding_values
    return (
        engine = "HSquared.jl",
        target = "multivariate_reml",
        genetic_structure = String(s),
        n_traits = t,
        traits = collect(result.traits),
        genetic_covariance = G0,
        genetic_variances = diag(G0),
        residual_covariance = R0,
        genetic_correlation = Matrix(result.genetic_correlation),
        residual_correlation = Matrix(result.residual_correlation),
        heritability = copy(collect(result.heritability)),
        fixed_effects = Matrix(result.beta),
        breeding_values = (ids = bv.ids, traits = bv.traits, values = Matrix(bv.values)),
        loglik = result.loglik,
        n_genetic_params = n_genetic_params,
        converged = result.converged,
    )
end

"""
    structured_genetic_payload(result)

Rotation-INVARIANT Julia result payload for a `:lowrank` or
`:factor_analytic` multivariate REML fit from [`fit_multivariate_reml`](@ref) —
the rotation-gated companion of [`multivariate_result_payload`](@ref) (which serves
the rotation-free `:unstructured` / `:diagonal` structures).

The factor loadings of a low-rank / factor-analytic `G` are rotation-NONidentified
(`Λ` and `ΛQ` give the same `G`), so they are NEVER surfaced. Instead this exposes
rotation-INVARIANT summaries of the estimated genetic covariance `G` (the FA
rotation convention, `docs/dev-log/decisions/2026-06-19-fa-rotation-convention.md`):
the reconstructed `G`, per-trait genetic variances / correlations, the genetic
eigenstructure ([`genetic_pca`](@ref): descending eigenvalues + sign-canonicalized
principal axes; when eigenvalues are repeated, interpret the eigenspace rather
than individual axes), `mean_evolvability`, and — for `:factor_analytic` — the separate
specific variances `Ψ` (`genetic_uniqueness`, a rotation-invariant fitted component;
rotation invariance does not establish that the decomposition identifies `Ψ`). The
payload reports `genetic_uniqueness_identification = :not_assessed_by_fit`; callers
must not infer identification from convergence or positive Ledermann slack. The
`genetic_rank` field is the requested factor count `K`, not an estimated rank of `G`
or automatic rank selection. Trait labels and all trait-indexed fields follow the
input `Y` column order. `heritability` is `Gᵢᵢ/(Gᵢᵢ + Rᵢᵢ)` on the relationship
matrix reference scale, and `mean_evolvability` is coordinate- and unit-dependent.
Fixed effects, breeding
values, per-trait heritabilities, the REML `loglik`, and `converged` are
rotation-invariant and carried through. It deliberately OMITS `genetic_loadings`;
`rotation_invariant = true` and `loadings_excluded = true` make that self-describing.
"""
function structured_genetic_payload(result)
    hasproperty(result, :genetic_structure) ||
        throw(ArgumentError("structured_genetic_payload needs a multivariate REML result"))
    s = result.genetic_structure
    s in (:lowrank, :factor_analytic) || throw(ArgumentError(
        "structured_genetic_payload is for the rotation-gated :lowrank / " *
        ":factor_analytic structures; use multivariate_result_payload for " *
        ":unstructured / :diagonal"))
    r = _require_structured_genetic_metadata(result)
    G0 = Matrix(r.genetic_covariance)
    t = size(G0, 1)
    pca = genetic_pca(G0)
    ψ = r.genetic_uniqueness
    bv = r.breeding_values
    return (
        engine = "HSquared.jl",
        target = "multivariate_reml_structured",
        genetic_structure = String(s),
        genetic_rank = r.genetic_rank,
        n_traits = t,
        traits = collect(r.traits),
        genetic_covariance = G0,
        genetic_variances = diag(G0),
        genetic_correlation = Matrix(r.genetic_correlation),
        residual_covariance = Matrix(r.residual_covariance),
        residual_correlation = Matrix(r.residual_correlation),
        genetic_eigenvalues = pca.values,
        genetic_principal_axes = pca.vectors,
        mean_evolvability = mean_evolvability(G0),
        genetic_uniqueness = isnothing(ψ) ? nothing : copy(collect(ψ)),
        genetic_uniqueness_identification = isnothing(ψ) ? nothing : :not_assessed_by_fit,
        heritability = copy(collect(r.heritability)),
        fixed_effects = Matrix(r.beta),
        breeding_values = (ids = bv.ids, traits = bv.traits, values = Matrix(bv.values)),
        loglik = r.loglik,
        converged = r.converged,
        rotation_invariant = true,
        loadings_excluded = true,
    )
end

function _mv_labels(labels, n::Integer, name::AbstractString)
    values = labels === nothing ? collect(1:n) : collect(labels)
    length(values) == n || throw(ArgumentError("$name length must match its model dimension"))
    any(v -> ismissing(v) || isnothing(v), values) && throw(ArgumentError("$name must not contain missing labels"))
    normalized = strip.(string.(values))
    all(!isempty, normalized) || throw(ArgumentError("$name must not contain empty labels"))
    length(unique(normalized)) == n || throw(ArgumentError("$name must be unique after string normalization"))
    return values
end

function _mv_fd_step(h::Real)
    isfinite(h) && h > 0 || throw(ArgumentError("finite-difference step must be finite and positive"))
    hf = Float64(h)
    isfinite(hf) && hf > 0 && isfinite(hf * hf) && hf * hf > 0 ||
        throw(ArgumentError("finite-difference step and its square must be representable as finite positive Float64 values"))
    return hf
end

function _mv_fd_points(x, h)
    xf = Float64.(collect(x))
    all(isfinite, xf) || throw(ArgumentError("finite-difference coordinates must be finite Float64 values"))
    all(v -> isfinite(v + h) && isfinite(v - h) && v + h != v && v - h != v, xf) ||
        throw(ArgumentError("finite-difference perturbations must be finite and distinct from their coordinates"))
    return xf
end

function _mv_require_converged(fit)
    hasproperty(fit, :converged) && fit.converged === true ||
        throw(ArgumentError("multivariate uncertainty requires a fit with converged = true"))
    return nothing
end

function _check_finite_matrix(M, name)
    Mf = Float64.(Matrix(M))
    all(isfinite, Mf) || throw(ArgumentError("$name must not contain Inf or NaN"))
    return Mf
end

# Validate the original matrix before a Symmetric wrapper can discard a triangle.
# The scale-relative tolerance permits ordinary floating-point assembly noise;
# accepted inputs are averaged once so quadratic forms and factorizations agree.
function _check_positive_definite_matrix(M::AbstractMatrix, name::AbstractString, n::Integer)
    size(M) == (n, n) || throw(ArgumentError("$name must be $n×$n"))
    n > 0 || throw(ArgumentError("$name must have positive dimension"))
    Mf = _check_finite_matrix(M, name)
    scale = maximum(abs, Mf)
    all(abs(Mf[i, j] - Mf[j, i]) <= 1e-10 * scale for j in 1:n for i in 1:j) ||
        throw(ArgumentError("$name must be symmetric (relative tolerance 1e-10)"))
    Ms = 0.5 .* Mf .+ 0.5 .* transpose(Mf)
    isposdef(Symmetric(Ms)) || throw(ArgumentError("$name must be positive definite"))
    return Ms
end

_check_relationship_precision(Ainv::AbstractMatrix, q::Integer) =
    _check_positive_definite_matrix(Ainv, "Ainv", q)

function _check_covariance(M, name, t)
    size(M, 1) == t && size(M, 2) == t ||
        throw(ArgumentError("$name must be $t×$t (one row/column per trait)"))
    Mf = _check_finite_matrix(M, name)
    isapprox(Mf, transpose(Mf); atol = 1e-10) ||
        throw(ArgumentError("$name must be symmetric"))
    Ms = Symmetric(Mf)
    isposdef(Ms) || throw(ArgumentError("$name must be positive definite"))
    return Ms
end

"""
    diagonal_covariance(variances)

Build a diagonal trait covariance matrix from positive variance components.
This is the direct Julia engine utility for the Phase-4B `diag` genetic
covariance structure. It is a matrix builder only; it does not change the R
formula contract.
"""
function diagonal_covariance(variances)
    v = Float64.(collect(variances))
    !isempty(v) || throw(ArgumentError("variances must not be empty"))
    all(isfinite, v) || throw(ArgumentError("variances must not contain Inf or NaN"))
    all(>(0), v) || throw(ArgumentError("variances must be positive"))
    return Matrix(Diagonal(v))
end

"""
    lowrank_covariance(loadings)

Build a low-rank covariance matrix `ΛΛ'` from a `traits × rank` loading matrix
`Λ`. The result is positive semidefinite and may be singular when
`rank < traits`.
"""
function lowrank_covariance(loadings::AbstractMatrix)
    L = _check_finite_matrix(loadings, "loadings")
    size(L, 1) >= 1 || throw(ArgumentError("loadings must have at least one trait row"))
    size(L, 2) >= 1 || throw(ArgumentError("loadings must have at least one factor column"))
    C = L * transpose(L)
    all(isfinite, C) || throw(ArgumentError("reconstructed low-rank covariance must be finite"))
    all(>(0), diag(C)) || throw(ArgumentError("each trait must have positive low-rank genetic variance"))
    return C
end

"""
    factor_analytic_covariance(loadings, uniqueness)

Build a factor-analytic covariance matrix `ΛΛ' + Ψ`, where `Λ` is a
`traits × rank` loading matrix and `Ψ` is a positive diagonal uniqueness vector.
This is the direct Julia engine utility for the Phase-4B `fa(K)` covariance
structure.
"""
function factor_analytic_covariance(loadings::AbstractMatrix, uniqueness)
    L = _check_finite_matrix(loadings, "loadings")
    ψ = Float64.(collect(uniqueness))
    size(L, 1) >= 1 || throw(ArgumentError("loadings must have at least one trait row"))
    size(L, 2) >= 1 || throw(ArgumentError("loadings must have at least one factor column"))
    size(L, 1) == length(ψ) ||
        throw(ArgumentError("uniqueness length must match the number of loading rows"))
    all(isfinite, ψ) || throw(ArgumentError("uniqueness must not contain Inf or NaN"))
    all(>(0), ψ) || throw(ArgumentError("uniqueness values must be positive"))
    C = L * transpose(L) + Diagonal(ψ)
    all(isfinite, C) || throw(ArgumentError("reconstructed factor-analytic covariance must be finite"))
    return C
end

# Heywood interior bound for fitted FA uniqueness (0.8 S3).
# ψ_i is a genetic VARIANCE in the squared units of trait i. This frozen,
# absolute 1e-4 floor is not equivariant to rescaling a trait near the bound.
# Parameterization: ψ_i = FA_UNIQUENESS_FLOOR + exp(θ_i), so min(ψ̂) ≥ 1e-4
# in floating point (exp can underflow to zero at the floor).
# Matches the frozen S2 pass cut
# (`docs/dev-log/decisions/2026-09-03-v08-s2-fa-recovery-gate-prereg.md`).
# The constructor above still accepts any positive Ψ (truth DGPs, diagnostics).
const FA_UNIQUENESS_FLOOR = 1e-4

"""
    ledermann_slack(t, K)

Ledermann slack for a `t`-trait rank-`K` factor-analytic covariance:
`(t − K)² − (t + K)`. The nominal parameter count after removing factor
rotations is `m = tK + t − K(K−1)/2`; slack is twice the difference between
the ambient covariance dimension and `m`. Half the slack is an actual
covariance codimension only where the covariance map has this nominal rank.
Strictly positive slack is required before a cell can be a covered-flip
candidate; this dimension-count screen does not prove local or global
identification. Slack `≤ 0` is Ledermann-saturated (S1 `t=3 K=1` is the
disclosure cell).
"""
function ledermann_slack(t::Integer, K::Integer)
    t >= 1 || throw(ArgumentError("t (trait count) must be ≥ 1"))
    K >= 1 || throw(ArgumentError("K (factor rank) must be ≥ 1"))
    K <= t || throw(ArgumentError("K must be between 1 and t"))
    return (Int(t) - Int(K))^2 - (Int(t) + Int(K))
end

"""
    fa_covered_flip_cell(t, K) -> Bool

Return `true` only when `ledermann_slack(t, K) > 0`. Saturated cells may
still be *fitted* for diagnosis; they are refused as a covered-flip cell.
"""
fa_covered_flip_cell(t::Integer, K::Integer) = ledermann_slack(t, K) > 0

"""
    require_fa_covered_flip_cell(t, K)

Throw if `(t, K)` is Ledermann-saturated (`slack ≤ 0`). Does not block
fitting; it is the honest refuse path for a covered-flip cell.
Returns the positive slack.
"""
function require_fa_covered_flip_cell(t::Integer, K::Integer)
    slack = ledermann_slack(t, K)
    slack > 0 || throw(ArgumentError(
        "Ledermann-saturated FA (t=$t, K=$K, slack=$slack ≤ 0) is not a covered-flip cell. " *
        "S1 (t=3 K=1) showed uniqueness collapse is typical at slack ≤ 0. " *
        "The frozen S2 gate cell is t=4 K=1 (slack=4). Saturated cells remain diagnostic only."))
    return slack
end

function _fa_uniqueness_from_unconstrained(θ)
    return FA_UNIQUENESS_FLOOR .+ exp.(θ)
end

function _fa_uniqueness_to_unconstrained(ψ)
    excess = Float64.(collect(ψ)) .- FA_UNIQUENESS_FLOOR
    all(isfinite, excess) || throw(ArgumentError(
        "uniqueness must be finite and exceed the interior floor $(FA_UNIQUENESS_FLOOR)"))
    all(>(0), excess) || throw(ArgumentError(
        "uniqueness values must exceed the uniqueness-interior floor $(FA_UNIQUENESS_FLOOR); " *
        "values at or below the floor are Heywood starts"))
    return log.(excess)
end

function _canonicalize_loadings(loadings::AbstractMatrix)
    L = _check_finite_matrix(loadings, "loadings")
    size(L, 1) >= 1 || throw(ArgumentError("loadings must have at least one trait row"))
    size(L, 2) >= 1 || throw(ArgumentError("loadings must have at least one factor column"))
    for j in axes(L, 2)
        imax = firstindex(L, 1)
        maxabs = -Inf
        @inbounds for i in axes(L, 1)
            a = abs(L[i, j])
            if a > maxabs
                maxabs = a
                imax = i
            end
        end
        if L[imax, j] < 0
            @inbounds for i in axes(L, 1)
                L[i, j] = -L[i, j]
            end
        end
    end
    return L
end

# A trait record is "missing" if it is `missing` or a NaN float; everything else
# (including integers) is an observed value.
_is_present(x) = !(ismissing(x) || (x isa AbstractFloat && isnan(x)))

# Dense marginal-GLS reference for the balanced multivariate animal model
# (records ordered individual-major, trait fastest):
#   V = Z_full·(A ⊗ G0)·Z_full' + (I_n ⊗ R0),  A = Ainv⁻¹.
# Returns (beta_vec, u_vec) — the independent check on the MME assembly below.
function _multivariate_dense(yvec, Xfull, Zfull, A, G0, R0, n, t)
    AkG = kron(A, Matrix(G0))
    V = Symmetric(Zfull * AkG * transpose(Zfull) .+ kron(Matrix(1.0I, n, n), Matrix(R0)))
    Vf = cholesky(V)
    ViX = Vf \ Matrix(Xfull)
    XtViX = cholesky(Symmetric(transpose(Xfull) * ViX))
    beta = XtViX \ (transpose(Xfull) * (Vf \ yvec))
    r = yvec .- Xfull * beta
    u = AkG * (transpose(Zfull) * (Vf \ r))
    return Vector{Float64}(beta), Vector{Float64}(u)
end

"""
    multivariate_mme(Y, X, Z, Ainv, G0, R0; ids = nothing, traits = nothing)

Supplied-(co)variance Henderson solve of the **multi-trait** Gaussian animal
model. For `t` traits, `n` records, and `q` related animals:

    Y[i, :] = (X·B)[i, :] + (Z·U)[i, :] + E[i, :],
    vec(Uᵀ) ~ N(0, A ⊗ G0),   E[i, S_i] ~ N(0, R0[S_i, S_i]),

where `Y` is `n×t`, the shared fixed-effect design `X` is `n×p`, the shared
record→animal incidence `Z` is `n×q`, `Ainv = A⁻¹` is the `q×q` relationship
inverse, `G0` is the `t×t` additive genetic covariance, and `R0` is the `t×t`
residual covariance. Records are ordered individual-major with trait fastest, so
the mixed-model equations carry the genetic precision `Ainv ⊗ G0⁻¹` on the random
block and the residual precision `R⁻¹` (block-diagonal over individuals) on the
data:

    [ X'R⁻¹X    X'R⁻¹Z              ] [vec(Bᵀ)]   [ X'R⁻¹·y ]
    [ Z'R⁻¹X    Z'R⁻¹Z + Ainv⊗G0⁻¹ ] [vec(Uᵀ)] = [ Z'R⁻¹·y ]

**Unbalanced / missing-trait records** are supported: an entry of `Y` that is
`missing` or `NaN` marks an unobserved trait for that record. Such observations
are dropped from the data and individual `i`'s residual precision uses only the
observed-trait submatrix `inv(R0[S_i, S_i])` (where `S_i` is its observed-trait
set). With every trait observed this reduces to the balanced model with residual
precision `I_n ⊗ R0⁻¹`. A non-finite *observed* phenotype (`Inf` — only `missing`
/ `NaN` mark an unobserved trait), a non-finite `X`/`Z`/`Ainv`, or a trait with no
observed records is rejected with a clear `ArgumentError`.

This is the Phase-4 (multivariate Gaussian) supplied-variance engine slice: an
MME solve that does **not** estimate `G0` / `R0` (covariance-matrix estimation is
a separate REML slice), the multi-trait analogue of [`henderson_mme`](@ref). It
assumes a fixed-effect / incidence design shared across traits; per-trait designs
are not covered. Experimental, dense/validation-scale, supplied-covariance Julia
helper. R's multivariate fitting routes are documented separately.

Returns a `NamedTuple`:

  - `beta` — `p×t` fixed effects (column `k` = trait `k`);
  - `breeding_values` — `(ids, traits, values)` with `values` the `q×t` EBV matrix
    (column `k` = trait `k`);
  - `genetic_covariance`, `residual_covariance` — the supplied `G0`, `R0`;
  - `genetic_correlation`, `residual_correlation` — derived `t×t` correlations;
  - `traits` — the trait labels.
"""
function multivariate_mme(
    Y::AbstractMatrix,
    X::AbstractMatrix,
    Z::AbstractMatrix,
    Ainv::AbstractMatrix,
    G0::AbstractMatrix,
    R0::AbstractMatrix;
    ids = nothing,
    traits = nothing,
)
    n = size(Y, 1)
    t = size(Y, 2)
    t >= 1 || throw(ArgumentError("Y must have at least one trait column"))
    size(X, 1) == n || throw(ArgumentError("X must have one row per record"))
    size(Z, 1) == n || throw(ArgumentError("Z must have one row per record"))
    q = size(Ainv, 1)
    size(Ainv, 2) == q || throw(ArgumentError("Ainv must be square"))
    size(Z, 2) == q || throw(ArgumentError("Z columns must match Ainv dimensions"))
    aids = _mv_labels(ids, q, "ids")
    tlabels = _mv_labels(traits, t, "traits")
    G0s = _check_covariance(G0, "G0", t)
    R0s = _check_covariance(R0, "R0", t)

    p = size(X, 2)
    # observed-record mask (handles unbalanced / missing-trait records).
    Ym = Matrix(Y)
    present = falses(n, t)
    @inbounds for i in 1:n, k in 1:t
        present[i, k] = _is_present(Ym[i, k])
    end
    any(present) || throw(ArgumentError("Y has no observed (non-missing) entries"))
    Ai = _check_relationship_precision(Ainv, q)
    _mv_validate_inputs(present, Ym, X, Z, tlabels)
    Yfull = zeros(Float64, n, t)
    @inbounds for i in 1:n, k in 1:t
        present[i, k] && (Yfull[i, k] = Float64(Ym[i, k]))
    end

    It = sparse(1.0I, t, t)
    # individual-major (trait fastest) vectorization: vec of the transpose.
    Xfull = kron(sparse(Float64.(Matrix(X))), It)
    Zfull = kron(sparse(Float64.(Matrix(Z))), It)
    yvec = vec(permutedims(Yfull))
    Ginv_block = kron(sparse(Ai), sparse(inv(G0s)))

    if all(present)
        # balanced: a single Kronecker residual precision I_n ⊗ R0⁻¹.
        Rinv = kron(sparse(1.0I, n, n), sparse(inv(R0s)))
    else
        # unbalanced: keep observed rows; residual precision is block-diagonal
        # over individuals with individual i's block inv(R0[S_i, S_i]).
        maskvec = vec(permutedims(present))
        Xfull = Xfull[maskvec, :]
        Zfull = Zfull[maskvec, :]
        yvec = yvec[maskvec]
        blocks = SparseMatrixCSC{Float64,Int}[]
        for i in 1:n
            Si = findall(@view present[i, :])
            isempty(Si) && continue
            push!(blocks, sparse(inv(R0s[Si, Si])))
        end
        Rinv = blockdiag(blocks...)
    end

    (size(Xfull, 2) == 0 || LinearAlgebra.rank(Matrix(Xfull)) == size(Xfull, 2)) ||
        throw(ArgumentError("fixed-effect design must have full column rank over observed records"))
    Xt = transpose(Xfull)
    Zt = transpose(Zfull)
    XtRi = Xt * Rinv
    ZtRi = Zt * Rinv
    lhs = [
        XtRi * Xfull  XtRi * Zfull
        ZtRi * Xfull  ZtRi * Zfull + Ginv_block
    ]
    rhs = vcat(XtRi * yvec, ZtRi * yvec)
    solution = lhs \ rhs

    nfixed = p * t
    betavec = Vector{Float64}(solution[1:nfixed])
    uvec = Vector{Float64}(solution[(nfixed + 1):(nfixed + q * t)])
    # invert the trait-fastest vectorization back to (level × trait) matrices.
    beta = permutedims(reshape(betavec, t, p))
    ebv = permutedims(reshape(uvec, t, q))

    return (
        beta = beta,
        breeding_values = (ids = aids, traits = tlabels, values = ebv),
        genetic_covariance = Matrix(G0s),
        residual_covariance = Matrix(R0s),
        genetic_correlation = genetic_correlation(Matrix(G0s)),
        residual_correlation = genetic_correlation(Matrix(R0s)),
        traits = tlabels,
    )
end

# Pack/unpack a t×t PD covariance as an unconstrained vector through its lower
# Cholesky factor `L` (`cov = L·Lᵀ`), with log-diagonal entries so the diagonal
# stays positive. Length `t(t+1)/2`, column-major lower-triangular order.
function _chol_params_to_cov(v, t)
    L = zeros(eltype(v), t, t)
    idx = 1
    for j in 1:t, i in j:t
        L[i, j] = i == j ? exp(v[idx]) : v[idx]
        idx += 1
    end
    return L * transpose(L)
end

# Map an optimizer's Cholesky parameters only when finite precision still
# yields a finite positive-definite covariance. Exponent underflow can turn a
# nominally positive factor diagonal into zero and a singular covariance.
function _try_chol_params_to_cov(v, t)
    covariance = _chol_params_to_cov(v, t)
    all(isfinite, covariance) || return nothing
    return isposdef(Symmetric(covariance)) ? covariance : nothing
end

function _cov_to_chol_params(M::AbstractMatrix, t)
    L = cholesky(Symmetric(Matrix(Float64.(M)))).L
    v = Vector{Float64}(undef, t * (t + 1) ÷ 2)
    idx = 1
    for j in 1:t, i in j:t
        v[idx] = i == j ? log(L[i, j]) : L[i, j]
        idx += 1
    end
    return v
end

function _validate_genetic_structure(genetic_structure::Symbol, rank, t)
    genetic_structure in (:unstructured, :diagonal, :lowrank, :factor_analytic) ||
        throw(ArgumentError("genetic_structure must be :unstructured, :diagonal, :lowrank, or :factor_analytic"))
    if genetic_structure in (:lowrank, :factor_analytic)
        rank === nothing && throw(ArgumentError("rank is required for $genetic_structure"))
        rank isa Integer || throw(ArgumentError("rank must be an integer"))
        1 <= rank <= t || throw(ArgumentError("rank must be between 1 and the number of traits"))
        return Int(rank)
    end
    rank === nothing || throw(ArgumentError("rank is only used for :lowrank and :factor_analytic"))
    return 0
end

function _structured_genetic_params_to_cov(params, t, genetic_structure::Symbol, rank::Int)
    if genetic_structure == :unstructured
        return _chol_params_to_cov(params, t), nothing, nothing
    elseif genetic_structure == :diagonal
        G0 = diagonal_covariance(exp.(params))
        return G0, nothing, diag(G0)
    elseif genetic_structure == :lowrank
        L = _canonicalize_loadings(reshape(collect(params), t, rank))
        # pure low-rank G = ΛΛ' has no specific (uniqueness) variance — signal that
        # with `nothing` rather than a misleading estimated-zero vector.
        return lowrank_covariance(L), L, nothing
    else
        nload = t * rank
        L = _canonicalize_loadings(reshape(collect(@view(params[1:nload])), t, rank))
        ψ = _fa_uniqueness_from_unconstrained(@view(params[(nload + 1):end]))
        return factor_analytic_covariance(L, ψ), L, ψ
    end
end

function _structured_genetic_params0(G0_start, genetic_structure::Symbol, rank::Int, t, initial)
    if genetic_structure == :unstructured
        return _cov_to_chol_params(G0_start, t)
    elseif genetic_structure == :diagonal
        return log.(diag(G0_start))
    end

    L = if initial !== nothing && hasproperty(initial, :loadings)
        L0 = _check_finite_matrix(initial.loadings, "initial.loadings")
        size(L0) == (t, rank) ||
            throw(ArgumentError("initial.loadings must be $t×$rank"))
        L0
    else
        L0 = zeros(t, rank)
        d = sqrt.(max.(diag(G0_start), eps(Float64)))
        for k in 1:t
            L0[k, ((k - 1) % rank) + 1] = d[k]
        end
        L0
    end

    if genetic_structure == :lowrank
        return vec(L)
    end

    ψ = if initial !== nothing && hasproperty(initial, :uniqueness)
        ψ0 = Float64.(collect(initial.uniqueness))
        length(ψ0) == t || throw(ArgumentError("initial.uniqueness length must match the number of traits"))
        all(isfinite, ψ0) || throw(ArgumentError("initial.uniqueness must not contain Inf or NaN"))
        ψ0
    else
        max.(0.5 .* diag(G0_start), 2 * FA_UNIQUENESS_FLOOR)
    end
    return vcat(vec(L), _fa_uniqueness_to_unconstrained(ψ))
end

function _select_multivariate_fit_attempt(attempts)
    valid = findall(a -> a.valid && isfinite(a.objective), attempts)
    isempty(valid) && throw(ArgumentError(
        "no multivariate REML optimizer start returned a finite objective and covariance estimate"))
    converged = filter(i -> attempts[i].converged, valid)
    candidates = isempty(converged) ? valid : converged
    return candidates[argmin([attempts[i].objective for i in candidates])]
end

# Validate the observed data. `present` is the n×t observed mask. Throws a clear
# ArgumentError on a non-finite observed phenotype (e.g. Inf — only missing/NaN
# mark an unobserved trait), a non-finite entry of `X`/`Z`, or a trait with no
# observed records (which would otherwise surface as an opaque SingularException /
# PosDefException downstream). `tlabels` is used only for the message.
function _mv_validate_inputs(present, Ym, X, Z, tlabels)
    n, t = size(present)
    @inbounds for i in 1:n, k in 1:t
        if present[i, k] && !isfinite(Float64(Ym[i, k]))
            throw(ArgumentError(
                "Y[$i, $k] (trait $(tlabels[k])) is not finite; mark unobserved traits with `missing` or `NaN`, not Inf"))
        end
    end
    all(isfinite, Float64.(Matrix(X))) || throw(ArgumentError("X must not contain Inf or NaN"))
    all(isfinite, Float64.(Matrix(Z))) || throw(ArgumentError("Z must not contain Inf or NaN"))
    for k in 1:t
        any(@view present[:, k]) ||
            throw(ArgumentError("trait $(tlabels[k]) has no observed records; drop it before fitting"))
    end
    return nothing
end

# Build the observed-data design for the multivariate model in trait-fastest
# order, dropping `missing`/`NaN` records. Returns the observed response `yvec`,
# the dense expanded `Xfull` (N×p·t) and `Zfull` (N×q·t), the per-individual
# `(row-range, observed-trait-set)` list `indiv` for the block-diagonal residual,
# and the observed count `N`.
function _mv_observed(Y, X, Z, n, t, q, p)
    Ym = Matrix(Y)
    present = falses(n, t)
    @inbounds for i in 1:n, k in 1:t
        present[i, k] = _is_present(Ym[i, k])
    end
    any(present) || throw(ArgumentError("Y has no observed (non-missing) entries"))
    _mv_validate_inputs(present, Ym, X, Z, 1:t)
    rows = [(i, k) for i in 1:n for k in 1:t if present[i, k]]
    N = length(rows)
    Xfull = zeros(N, p * t)
    Zfull = zeros(N, q * t)
    yvec = zeros(N)
    for (r, (i, k)) in enumerate(rows)
        yvec[r] = Float64(Ym[i, k])
        for j in 1:p
            Xfull[r, (j - 1) * t + k] = Float64(X[i, j])
        end
        for a in 1:q
            Zfull[r, (a - 1) * t + k] = Float64(Z[i, a])
        end
    end
    indiv = Tuple{UnitRange{Int},Vector{Int}}[]
    rstart = 0
    for i in 1:n
        Si = findall(@view present[i, :])
        isempty(Si) && continue
        m = length(Si)
        push!(indiv, (rstart + 1:rstart + m, Si))
        rstart += m
    end
    return yvec, Xfull, Zfull, indiv, N
end

# Cholesky factor of the marginal covariance `V = Zfull·(A⊗G0)·Zfull' + R`,
# with `R` block-diagonal over individuals (block `i` = `R0[Sᵢ, Sᵢ]`). `V` is PD
# whenever `R0` is PD, even if `G0` is only positive semidefinite (a boundary
# REML optimum), so this stays well-defined at the boundary.
function _mv_build_Vchol(Zfull, A, indiv, N, G0, R0)
    Vg = Zfull * kron(A, G0) * transpose(Zfull)
    R = zeros(N, N)
    for (rng, Si) in indiv
        R[rng, rng] = R0[Si, Si]
    end
    return cholesky(Symmetric(Vg .+ R))
end

# Full REML log-likelihood at supplied `G0`, `R0`, INCLUDING the `(N − p')·log(2π)`
# constant (`p' = ncol(Xfull)`), so it is on the same scale as `gaussian_loglik`
# and `sparse_reml_loglik` and agrees with other full-constant Gaussian objectives on matched models.
# REML comparisons still require compatible data and fixed-effect spaces.
function _mv_reml_loglik_core(yvec, Xfull, Zfull, A, indiv, N, G0, R0)
    Vf = _mv_build_Vchol(Zfull, A, indiv, N, G0, R0)
    ViX = Vf \ Xfull
    XtViX = cholesky(Symmetric(transpose(Xfull) * ViX))
    beta = XtViX \ (transpose(Xfull) * (Vf \ yvec))
    r = yvec .- Xfull * beta
    nfix = size(Xfull, 2)
    return -0.5 * ((N - nfix) * log(2π) + logdet(Vf) + logdet(XtViX) + dot(r, Vf \ r))
end

# Genetic correlations are returned for every trait, so a candidate with a zero
# marginal genetic variance is not a valid reported fit. Pure low-rank G may be
# singular, while the other structures require positive-definite G.
function _mv_genetic_covariance_admissible(G0, genetic_structure::Symbol)
    all(isfinite, G0) && all(>(0), diag(G0)) || return false
    return genetic_structure === :lowrank || isposdef(Symmetric(G0))
end

# Return Inf for optimizer trial points whose covariance transform or marginal
# factorization is invalid. Input contracts are validated before optimization.
function _mv_reml_objective(params, yvec, Xfull, Zfull, A, indiv, N, t,
                            genetic_structure, grank, ngen)
    expected = ngen + t * (t + 1) ÷ 2
    length(params) == expected ||
        throw(DimensionMismatch("REML objective expected $expected covariance parameters, got $(length(params))"))
    local G0, R0
    try
        G0, _, _ = _structured_genetic_params_to_cov(
            @view(params[1:ngen]), t, genetic_structure, grank)
        R0 = _chol_params_to_cov(@view(params[(ngen + 1):end]), t)
        _mv_genetic_covariance_admissible(G0, genetic_structure) || return Inf
        all(isfinite, R0) || return Inf
        isposdef(Symmetric(R0)) || return Inf
    catch err
        (err isa PosDefException || err isa ArgumentError) && return Inf
        rethrow()
    end
    try
        objective = -_mv_reml_loglik_core(yvec, Xfull, Zfull, A, indiv, N, G0, R0)
        return isfinite(objective) ? objective : Inf
    catch err
        err isa PosDefException && return Inf
        rethrow()
    end
end

# GLS fixed effects and BLUP breeding values at supplied `G0`, `R0`. Uses the
# marginal-model form `u = (A⊗G0)·Zfull'·V⁻¹·(y − Xβ̂)`, which equals the MME
# solution when `G0` is PD but also works when `G0` is singular (boundary).
function _mv_gls_blup(yvec, Xfull, Zfull, A, indiv, N, G0, R0, t, p, q)
    Vf = _mv_build_Vchol(Zfull, A, indiv, N, G0, R0)
    ViX = Vf \ Xfull
    XtViX = cholesky(Symmetric(transpose(Xfull) * ViX))
    betavec = XtViX \ (transpose(Xfull) * (Vf \ yvec))
    r = yvec .- Xfull * betavec
    uvec = kron(A, G0) * (transpose(Zfull) * (Vf \ r))
    return permutedims(reshape(betavec, t, p)), permutedims(reshape(uvec, t, q))
end

# Convenience: multivariate REML log-likelihood directly from model inputs at
# supplied covariances (rebuilds the observed structures). Used in validation.
function _multivariate_reml_loglik(Y, X, Z, Ainv, G0, R0)
    n = size(Y, 1); t = size(Y, 2); q = size(Ainv, 1); p = size(X, 2)
    A = inv(Symmetric(_check_relationship_precision(Ainv, q)))
    yvec, Xfull, Zfull, indiv, N = _mv_observed(Y, X, Z, n, t, q, p)
    return _mv_reml_loglik_core(yvec, Xfull, Zfull, A, indiv, N,
                                Matrix(Float64.(Matrix(G0))), Matrix(Float64.(Matrix(R0))))
end

"""
    fit_multivariate_reml(Y, X, Z, Ainv; initial = nothing, iterations = 2000,
                          ids = nothing, traits = nothing,
                          genetic_structure = :unstructured, rank = nothing)

Estimate the genetic and residual covariance matrices `G0`, `R0` of the
multi-trait animal model by **dense REML**. Inputs match [`multivariate_mme`](@ref)
(balanced or with `missing`/`NaN` trait records); the marginal model is

    y ~ N(X·β, V),   V = Z_full·(A ⊗ G0)·Z_full' + R,

with `R` block-diagonal over individuals (individual `i`'s block `R0[Sᵢ, Sᵢ]`).
The REML log-likelihood is maximized by Nelder–Mead. The default
`:unstructured` fit uses a log-Cholesky parameterization for both `G0` and `R0`;
structured fits constrain only the additive genetic covariance and keep `R0`
unstructured positive definite. At the optimum the breeding values and fixed
effects are computed from the marginal GLS BLUP form, which remains defined for
low-rank genetic covariances.

The additive genetic covariance can be constrained with `genetic_structure`:

  - `:unstructured` (default) — full positive-definite `G0`;
  - `:diagonal` — independent trait-specific genetic variances;
  - `:lowrank` — `G0 = ΛΛ'`, requiring `rank`;
  - `:factor_analytic` — `G0 = ΛΛ' + Ψ`, requiring `rank`. Fitted uniqueness
    uses `ψ_i = FA_UNIQUENESS_FLOOR + exp(θ_i)` so `min(ψ̂) ≥ 1e-4` (Heywood
    interior bound in absolute trait-specific genetic-variance units). This
    frozen floor is not scale-equivariant near the bound: changing a trait's
    units by `c` changes its variance by `c²` but does not change `1e-4`.
    Ledermann-saturated cells (`ledermann_slack(t, K) ≤ 0`)
    may still be fitted for diagnosis; `require_fa_covered_flip_cell`
    refuses them as a covered-flip cell.

For structured fits, `initial` may supply `G0`, `R0`, `loadings`
(`traits × rank`), and `uniqueness` for `:factor_analytic`; omitted fields use
deterministic phenotypic-scale defaults. When `genetic_structure = :factor_analytic`
and `initial` is omitted, the fitter runs both its standard and a deterministic
balanced phenotypic-scale initialization. Away from the uniqueness floor, the
second start preserves the initial genetic diagonal, halves its off-diagonal
covariances, and retains the initial residual covariance; floor clamping can
also change the genetic diagonal. This is a decomposition sensitivity check,
not broad multistart protection. It returns the highest-likelihood
converged fit when one exists; if neither converges, it returns the best finite
fit with `converged = false`. `fa_start_diagnostics` records both outcomes,
whether their fitted covariances disagree, and whether uniqueness is within 1%
of the absolute floor. Supplying `initial` requests a single user-controlled
start.

Returned `genetic_loadings` use a deterministic sign convention: for each factor
column, the largest-absolute loading is non-negative. This removes arbitrary
sign flips from returned metadata but does not impose a rotation or
lower-triangular identification constraint; for `rank > 1`, loadings remain
rotation-nonunique and should not be interpreted as uniquely identified factors.

Experimental, dense/validation-scale, REML-only, Gaussian. The REML estimator is
validated by deterministic self-consistency checks (the `t = 1` reduction
recovers the univariate REML estimate; the multivariate REML log-likelihood is on
the same full-constant scale as the univariate one; the optimum beats a coarse
grid). Seeded fixtures and separately documented recovery campaigns concern
specific trait/rank/design cells. They establish no broad recovery or inference
calibration. For the unstructured multi-trait comparison, same-estimand external
parity is discharged on ONE deterministic fixture (point-estimate) by `sommer`
4.4.5 and `blupf90+` 2.60, with no ASReml or JWAS leg — treat multi-trait
variance estimates as experimental. There is no published textbook anchor for
estimated multivariate `G0`/`R0`: the R lane's Mrode Example 5.1 leg is a
*supplied*-covariance BLUP/MME anchor, so it does not check the estimated
covariances. The R twin reaches this fitter on its default `cbind()` route
(hsquared MV-4); that claim stays `partial`, and R↔engine element-wise parity at
the promotion fixture is discharged locally (hsquared A26) but is not CI-backed
— the R lane's CI provisions no Julia, so the parity legs skip there.

Returns a `NamedTuple`:

  - `genetic_covariance`, `residual_covariance` — estimated `G0`, `R0` (`t×t`);
  - `genetic_correlation`, `residual_correlation` — derived `t×t` correlations;
  - `heritability` — per-trait `h² = diag(G0)/(diag(G0)+diag(R0))`;
  - `beta`, `breeding_values` — fixed effects and EBVs at the estimate;
  - `genetic_structure`, `genetic_rank`, `genetic_loadings`,
    `genetic_uniqueness` — structure metadata (`nothing` where not applicable);
  - `loglik` — the full REML log-likelihood at the estimate, including the
    `(N − p')·log(2π)` constant, so it is on the same scale as
    [`gaussian_loglik`](@ref) / [`sparse_reml_loglik`](@ref); comparisons still
    require matched data and compatible fixed-effect spaces;
  - `converged`, `iterations`, `traits`;
  - `fa_start_diagnostics` — for FA fits, per-start objective, termination,
    iteration count, objective range, covariance disagreement, whether a
    better nonconverged start exists, and distance to the uniqueness floor;
    `nothing` for other genetic structures.

Non-finite or empty-trait inputs are rejected up front (see
[`multivariate_mme`](@ref)), so the optimizer never returns plausible-looking
covariances from `Inf`/`NaN` data; check `converged` for genuine boundary cases.
"""
function fit_multivariate_reml(
    Y::AbstractMatrix,
    X::AbstractMatrix,
    Z::AbstractMatrix,
    Ainv::AbstractMatrix;
    initial = nothing,
    iterations::Integer = 2_000,
    ids = nothing,
    traits = nothing,
    genetic_structure::Symbol = :unstructured,
    rank = nothing,
)
    n = size(Y, 1)
    t = size(Y, 2)
    t >= 1 || throw(ArgumentError("Y must have at least one trait column"))
    size(X, 1) == n || throw(ArgumentError("X must have one row per record"))
    size(Z, 1) == n || throw(ArgumentError("Z must have one row per record"))
    q = size(Ainv, 1)
    size(Ainv, 2) == q || throw(ArgumentError("Ainv must be square"))
    size(Z, 2) == q || throw(ArgumentError("Z columns must match Ainv dimensions"))
    aids = _mv_labels(ids, q, "ids")
    tlabels = _mv_labels(traits, t, "traits")

    p = size(X, 2)
    A = inv(Symmetric(_check_relationship_precision(Ainv, q)))
    yvec, Xfull, Zfull, indiv, N = _mv_observed(Y, X, Z, n, t, q, p)
    iterations > 0 || throw(ArgumentError("iterations must be positive"))
    N > size(Xfull, 2) || throw(ArgumentError("REML requires positive residual degrees of freedom"))
    (size(Xfull, 2) == 0 || LinearAlgebra.rank(Xfull) == size(Xfull, 2)) ||
        throw(ArgumentError("fixed-effect design must have full column rank over observed records"))

    grank = _validate_genetic_structure(genetic_structure, rank, t)
    ngen = if genetic_structure == :unstructured
        t * (t + 1) ÷ 2
    elseif genetic_structure == :diagonal
        t
    elseif genetic_structure == :lowrank
        t * grank
    else
        t * grank + t
    end

    function negloglik(params)
        return _mv_reml_objective(
            params, yvec, Xfull, Zfull, A, indiv, N, t,
            genetic_structure, grank, ngen)
    end

    Ym = Matrix(Y)
    phen = ones(t)
    for k in 1:t
        vals = [Float64(Ym[i, k]) for i in 1:n if _is_present(Ym[i, k])]
        if length(vals) >= 2
            mu = sum(vals) / length(vals)
            v = sum(abs2, vals .- mu) / (length(vals) - 1)
            v > 0 && (phen[k] = v)
        end
    end

    if initial === nothing
        G0_start = Matrix(Diagonal(0.5 .* phen))
        R0_start = Matrix(Diagonal(0.5 .* phen))
    else
        G0_start = hasproperty(initial, :G0) ? Matrix(Float64.(Matrix(initial.G0))) : Matrix(Diagonal(0.5 .* phen))
        R0_start = hasproperty(initial, :R0) ? Matrix(Float64.(Matrix(initial.R0))) : Matrix(Diagonal(0.5 .* phen))
    end
    _check_covariance(R0_start, "initial.R0", t)
    if genetic_structure in (:unstructured, :diagonal) ||
            (initial !== nothing && hasproperty(initial, :G0))
        _check_covariance(G0_start, "initial.G0", t)
    end
    function params_for_start(start_initial)
        Gstart = start_initial !== nothing && hasproperty(start_initial, :G0) ?
            Matrix(Float64.(Matrix(start_initial.G0))) : Matrix(Diagonal(0.5 .* phen))
        Rstart = start_initial !== nothing && hasproperty(start_initial, :R0) ?
            Matrix(Float64.(Matrix(start_initial.R0))) : Matrix(Diagonal(0.5 .* phen))
        _check_covariance(Rstart, "initial.R0", t)
        if genetic_structure in (:unstructured, :diagonal) ||
                (start_initial !== nothing && hasproperty(start_initial, :G0))
            _check_covariance(Gstart, "initial.G0", t)
        end
        return vcat(
            _structured_genetic_params0(Gstart, genetic_structure, grank, t, start_initial),
            _cov_to_chol_params(Rstart, t),
        )
    end

    start_specs = if genetic_structure == :factor_analytic && initial === nothing
        L0 = zeros(t, grank)
        d0 = sqrt.(max.(diag(G0_start), eps(Float64)))
        for k in 1:t
            L0[k, ((k - 1) % grank) + 1] = d0[k]
        end
        balanced = (
            loadings = sqrt(0.5) .* L0,
            uniqueness = max.(0.5 .* phen, 2 * FA_UNIQUENESS_FLOOR),
            R0 = R0_start,
        )
        ((name = :default, initial = nothing), (name = :balanced, initial = balanced))
    else
        name = initial === nothing ? :default : :user
        ((name = name, initial = initial),)
    end

    attempts = map(start_specs) do spec
        params0 = params_for_start(spec.initial)
        result = optimize(negloglik, params0, NelderMead(), Optim.Options(iterations = iterations))
        phat = Optim.minimizer(result)
        G0raw, L, ψ = _structured_genetic_params_to_cov(@view(phat[1:ngen]), t,
                                                        genetic_structure, grank)
        G0 = Matrix(Symmetric(G0raw))
        R0 = Matrix(Symmetric(_chol_params_to_cov(@view(phat[ngen + 1:end]), t)))
        objective = Optim.minimum(result)
        valid = isfinite(objective) &&
                _mv_genetic_covariance_admissible(G0, genetic_structure) && all(isfinite, R0) &&
                isposdef(Symmetric(R0)) &&
                (L === nothing || all(isfinite, L)) &&
                (ψ === nothing || all(isfinite, ψ))
        (; name = spec.name, result, phat, G0, R0, L, ψ,
           objective, valid, converged = Optim.converged(result),
           iterations = Optim.iterations(result))
    end
    valid_attempts = filter(a -> a.valid, attempts)
    selected_index = _select_multivariate_fit_attempt(attempts)
    selected = attempts[selected_index]
    G0hat, R0hat, Lhat, ψhat = selected.G0, selected.R0, selected.L, selected.ψ

    fa_start_diagnostics = if genetic_structure == :factor_analytic
        floor_distance = minimum(ψhat .- FA_UNIQUENESS_FLOOR)
        start_rows = map(attempts) do a
            psi_finite = a.ψ !== nothing && all(isfinite, a.ψ)
            (; name = a.name, loglik = isfinite(a.objective) ? -a.objective : nothing,
               valid = a.valid, converged = a.converged, iterations = a.iterations,
               minimum_uniqueness = psi_finite ? minimum(a.ψ) : nothing,
               uniqueness_floor_distance = psi_finite ?
                   minimum(a.ψ .- FA_UNIQUENESS_FLOOR) : nothing)
        end
        rel_g = length(valid_attempts) > 1 ?
            norm(valid_attempts[1].G0 - valid_attempts[2].G0) /
                max(norm(valid_attempts[1].G0), norm(valid_attempts[2].G0), eps()) : nothing
        rel_r = length(valid_attempts) > 1 ?
            norm(valid_attempts[1].R0 - valid_attempts[2].R0) /
                max(norm(valid_attempts[1].R0), norm(valid_attempts[2].R0), eps()) : nothing
        objective_range = length(valid_attempts) > 1 ?
            maximum(a.objective for a in valid_attempts) -
            minimum(a.objective for a in valid_attempts) : nothing
        (; strategy = length(attempts) > 1 ? :default_and_balanced : :user_initial,
           starts_attempted = length(attempts), selected_start = selected.name,
           objective_range,
           g_relative_disagreement = rel_g, r_relative_disagreement = rel_r,
           better_nonconverged_start = any(a -> !a.converged &&
                                                a.valid && isfinite(a.objective) &&
                                                a.objective < selected.objective, attempts),
           minimum_uniqueness = minimum(ψhat), uniqueness_floor_distance = floor_distance,
           near_uniqueness_floor = floor_distance <= 0.01 * FA_UNIQUENESS_FLOOR,
           starts = start_rows)
    else
        nothing
    end

    # EBVs via the GLS form (robust to a singular G0 at a boundary optimum).
    beta, ebv = _mv_gls_blup(yvec, Xfull, Zfull, A, indiv, N, G0hat, R0hat, t, p, q)
    hsq = [G0hat[k, k] / (G0hat[k, k] + R0hat[k, k]) for k in 1:t]

    return (
        genetic_covariance = G0hat,
        residual_covariance = R0hat,
        genetic_correlation = genetic_correlation(G0hat),
        residual_correlation = genetic_correlation(R0hat),
        heritability = hsq,
        beta = beta,
        breeding_values = (ids = aids, traits = tlabels, values = ebv),
        genetic_structure = genetic_structure,
        genetic_rank = genetic_structure in (:lowrank, :factor_analytic) ? grank : nothing,
        genetic_loadings = Lhat,
        genetic_uniqueness = ψhat,
        loglik = -selected.objective,
        converged = selected.converged,
        iterations = selected.iterations,
        fa_start_diagnostics = fa_start_diagnostics,
        traits = tlabels,
    )
end

# ---------------------------------------------------------------------------
# Multivariate repeatability (animal + permanent environment) — hsquared #237
# ---------------------------------------------------------------------------
# Multi-trait analogue of `fit_repeatability_reml`:
#   Y = XB + Z u_a + Z u_pe + E
#   vec(U_aᵀ) ~ N(0, A ⊗ G0),   vec(U_peᵀ) ~ N(0, I ⊗ P0)
# so the marginal covariance is
#   V = Z_full·(A ⊗ G0)·Z_full' + Z_full·(I ⊗ P0)·Z_full' + R.
# A ≠ I separates G0 from P0; repeated records separate P0 from R0.
# Without PE, animal-only REML absorbs V_PE into G0 (the #237 defect).

function _mv_pe_build_Vchol(Zfull, A, indiv, N, G0, P0, R0)
    q = size(A, 1)
    Vg = Zfull * kron(A, G0) * transpose(Zfull)
    Vp = Zfull * kron(Matrix{Float64}(I, q, q), Matrix(P0)) * transpose(Zfull)
    R = zeros(N, N)
    for (rng, Si) in indiv
        R[rng, rng] = R0[Si, Si]
    end
    return cholesky(Symmetric(Vg .+ Vp .+ R))
end

function _mv_pe_reml_loglik_core(yvec, Xfull, Zfull, A, indiv, N, G0, P0, R0)
    Vf = _mv_pe_build_Vchol(Zfull, A, indiv, N, G0, P0, R0)
    ViX = Vf \ Xfull
    XtViX = cholesky(Symmetric(transpose(Xfull) * ViX))
    beta = XtViX \ (transpose(Xfull) * (Vf \ yvec))
    r = yvec .- Xfull * beta
    nfix = size(Xfull, 2)
    return -0.5 * ((N - nfix) * log(2π) + logdet(Vf) + logdet(XtViX) + dot(r, Vf \ r))
end

function _mv_pe_gls_blup(yvec, Xfull, Zfull, A, indiv, N, G0, P0, R0, t, p, q)
    Vf = _mv_pe_build_Vchol(Zfull, A, indiv, N, G0, P0, R0)
    ViX = Vf \ Xfull
    XtViX = cholesky(Symmetric(transpose(Xfull) * ViX))
    betavec = XtViX \ (transpose(Xfull) * (Vf \ yvec))
    r = yvec .- Xfull * betavec
    Vir = Vf \ r
    ZtVir = transpose(Zfull) * Vir
    uavec = kron(A, G0) * ZtVir
    upevec = kron(Matrix{Float64}(I, q, q), Matrix(P0)) * ZtVir
    return (
        permutedims(reshape(betavec, t, p)),
        permutedims(reshape(uavec, t, q)),
        permutedims(reshape(upevec, t, q)),
    )
end

"""
    fit_multivariate_repeatability_reml(Y, X, Z, Ainv; initial = nothing,
                                        iterations = 2000, ids = nothing,
                                        traits = nothing)

Dense REML for the **multi-trait repeatability** (animal + permanent
environment) model — the engine half of hsquared #237.

    Y = X B + Z u_a + Z u_pe + E
    vec(U_aᵀ) ~ N(0, A ⊗ G0),   vec(U_peᵀ) ~ N(0, I ⊗ P0)

`G0`, `P0`, and `R0` are unstructured `t×t` covariances (honest for `t = 2`).
Per-trait heritability uses the PE denominator
`h²_k = G0[k,k] / (G0[k,k] + P0[k,k] + R0[k,k])`; repeatability is
`t_k = (G0[k,k] + P0[k,k]) / (G0[k,k] + P0[k,k] + R0[k,k])`.

Reductions: `t = 1` recovers [`fit_repeatability_reml`](@ref) variance
components; `P0 = 0` recovers the [`fit_multivariate_reml`](@ref) log-likelihood.
Experimental, dense/validation-scale, REML-only. No covered flip.

The R twin has a dedicated experimental matrix route for `cbind()` plus
`permanent()`. The generic scalar reader does not transport matrix effects.
Direct Julia calls and payload-v2 dispatch `:multivariate_repeatability`
use `Y` plus pedigree and iid permanent-environment blocks.
"""
function fit_multivariate_repeatability_reml(
    Y::AbstractMatrix,
    X::AbstractMatrix,
    Z::AbstractMatrix,
    Ainv::AbstractMatrix;
    initial = nothing,
    iterations::Integer = 2_000,
    ids = nothing,
    traits = nothing,
)
    n = size(Y, 1)
    t = size(Y, 2)
    t >= 1 || throw(ArgumentError("Y must have at least one trait column"))
    size(X, 1) == n || throw(ArgumentError("X must have one row per record"))
    size(Z, 1) == n || throw(ArgumentError("Z must have one row per record"))
    q = size(Ainv, 1)
    size(Ainv, 2) == q || throw(ArgumentError("Ainv must be square"))
    size(Z, 2) == q || throw(ArgumentError("Z columns must match Ainv dimensions"))
    aids = _mv_labels(ids, q, "ids")
    tlabels = _mv_labels(traits, t, "traits")

    p = size(X, 2)
    A = inv(Symmetric(_check_relationship_precision(Ainv, q)))
    yvec, Xfull, Zfull, indiv, N = _mv_observed(Y, X, Z, n, t, q, p)
    iterations > 0 || throw(ArgumentError("iterations must be positive"))
    N > size(Xfull, 2) || throw(ArgumentError("REML requires positive residual degrees of freedom"))
    (size(Xfull, 2) == 0 || LinearAlgebra.rank(Xfull) == size(Xfull, 2)) ||
        throw(ArgumentError("fixed-effect design must have full column rank over observed records"))
    ncov = t * (t + 1) ÷ 2

    function negloglik(params)
        G0 = _try_chol_params_to_cov(@view(params[1:ncov]), t)
        P0 = _try_chol_params_to_cov(@view(params[(ncov + 1):(2 * ncov)]), t)
        R0 = _try_chol_params_to_cov(@view(params[(2 * ncov + 1):end]), t)
        (G0 === nothing || P0 === nothing || R0 === nothing) && return Inf
        try
            objective = -_mv_pe_reml_loglik_core(yvec, Xfull, Zfull, A, indiv, N, G0, P0, R0)
            return isfinite(objective) ? objective : Inf
        catch err
            (err isa PosDefException || err isa ArgumentError) && return Inf
            rethrow()
        end
    end

    Ym = Matrix(Y)
    phen = ones(t)
    for k in 1:t
        vals = [Float64(Ym[i, k]) for i in 1:n if _is_present(Ym[i, k])]
        if length(vals) >= 2
            mu = sum(vals) / length(vals)
            v = sum(abs2, vals .- mu) / (length(vals) - 1)
            v > 0 && (phen[k] = v)
        end
    end

    if initial === nothing
        G0_start = Matrix(Diagonal((1 / 3) .* phen))
        P0_start = Matrix(Diagonal((1 / 3) .* phen))
        R0_start = Matrix(Diagonal((1 / 3) .* phen))
    else
        G0_start = hasproperty(initial, :G0) ? Matrix(Float64.(Matrix(initial.G0))) :
            Matrix(Diagonal((1 / 3) .* phen))
        P0_start = hasproperty(initial, :P0) ? Matrix(Float64.(Matrix(initial.P0))) :
            Matrix(Diagonal((1 / 3) .* phen))
        R0_start = hasproperty(initial, :R0) ? Matrix(Float64.(Matrix(initial.R0))) :
            Matrix(Diagonal((1 / 3) .* phen))
    end
    _check_covariance(G0_start, "initial.G0", t)
    _check_covariance(P0_start, "initial.P0", t)
    _check_covariance(R0_start, "initial.R0", t)
    params0 = vcat(
        _cov_to_chol_params(G0_start, t),
        _cov_to_chol_params(P0_start, t),
        _cov_to_chol_params(R0_start, t),
    )

    result = optimize(negloglik, params0, NelderMead(), Optim.Options(iterations = iterations))
    phat = Optim.minimizer(result)
    isfinite(Optim.minimum(result)) || throw(ArgumentError("repeatability optimizer did not find a finite objective"))
    G0raw = _try_chol_params_to_cov(phat[1:ncov], t)
    P0raw = _try_chol_params_to_cov(phat[(ncov + 1):(2 * ncov)], t)
    R0raw = _try_chol_params_to_cov(phat[(2 * ncov + 1):end], t)
    (G0raw === nothing || P0raw === nothing || R0raw === nothing) &&
        throw(ArgumentError("multivariate repeatability optimizer did not return finite positive-definite covariances"))
    G0hat = Matrix(Symmetric(G0raw))
    P0hat = Matrix(Symmetric(P0raw))
    R0hat = Matrix(Symmetric(R0raw))

    beta, ebv, pe = _mv_pe_gls_blup(yvec, Xfull, Zfull, A, indiv, N, G0hat, P0hat, R0hat, t, p, q)
    denom = [G0hat[k, k] + P0hat[k, k] + R0hat[k, k] for k in 1:t]
    hsq = [G0hat[k, k] / denom[k] for k in 1:t]
    rpt = [(G0hat[k, k] + P0hat[k, k]) / denom[k] for k in 1:t]

    return (
        genetic_covariance = G0hat,
        permanent_covariance = P0hat,
        residual_covariance = R0hat,
        genetic_correlation = genetic_correlation(G0hat),
        permanent_correlation = genetic_correlation(P0hat),
        residual_correlation = genetic_correlation(R0hat),
        heritability = hsq,
        repeatability = rpt,
        beta = beta,
        breeding_values = (ids = aids, traits = tlabels, values = ebv),
        permanent_effects = (ids = aids, traits = tlabels, values = pe),
        genetic_structure = :unstructured,
        genetic_rank = nothing,
        genetic_loadings = nothing,
        genetic_uniqueness = nothing,
        loglik = -Optim.minimum(result),
        converged = Optim.converged(result),
        iterations = Optim.iterations(result),
        traits = tlabels,
        estimator = :multivariate_repeatability_reml,
        n_traits = t,
        n_animals = q,
        component_names = ["animal", "permanent", "residual"],
        component_dimensions = (animal = (q, t), permanent = (q, t), residual = (n, t)),
    )
end

"""
    multivariate_repeatability_result_payload(result)

Bridge-ready payload for [`fit_multivariate_repeatability_reml`](@ref).
Exposes the three covariance blocks R needs (`G0`, `P0`, `R0`), component
names/dimensions, PE-aware per-trait `heritability` and `repeatability`,
breeding values, and permanent-environment BLUPs.

`target = "multivariate_repeatability_reml"`. Experimental; no covered flip.
"""
function multivariate_repeatability_result_payload(result)
    getproperty(result, :estimator) === :multivariate_repeatability_reml ||
        throw(ArgumentError(
            "multivariate_repeatability_result_payload expects a multivariate " *
            "repeatability REML result (estimator = :multivariate_repeatability_reml)"))
    G0 = Matrix(result.genetic_covariance)
    P0 = Matrix(result.permanent_covariance)
    R0 = Matrix(result.residual_covariance)
    t = size(G0, 1)
    ncov = t * (t + 1) ÷ 2
    bv = result.breeding_values
    pe = result.permanent_effects
    return (
        engine = "HSquared.jl",
        target = "multivariate_repeatability_reml",
        genetic_structure = "unstructured",
        n_traits = t,
        n_animals = result.n_animals,
        traits = collect(result.traits),
        component_names = collect(result.component_names),
        component_dimensions = result.component_dimensions,
        genetic_covariance = G0,
        permanent_covariance = P0,
        residual_covariance = R0,
        genetic_variances = diag(G0),
        permanent_variances = diag(P0),
        residual_variances = diag(R0),
        genetic_correlation = Matrix(result.genetic_correlation),
        permanent_correlation = Matrix(result.permanent_correlation),
        residual_correlation = Matrix(result.residual_correlation),
        heritability = copy(collect(result.heritability)),
        repeatability = copy(collect(result.repeatability)),
        fixed_effects = Matrix(result.beta),
        breeding_values = (ids = bv.ids, traits = bv.traits, values = Matrix(bv.values)),
        permanent_effects = (ids = pe.ids, traits = pe.traits, values = Matrix(pe.values)),
        loglik = result.loglik,
        n_genetic_params = ncov,
        n_permanent_params = ncov,
        n_residual_params = ncov,
        converged = result.converged,
        estimator = "multivariate_repeatability_reml",
        status = "experimental",
    )
end

# ---------------------------------------------------------------------------
# Covariance standard errors + likelihood-ratio tests (V4-MV-REML / V4-FA gap)
# ---------------------------------------------------------------------------
# Asymptotic, observed-information + delta-method standard errors for the
# unstructured multivariate REML estimate, and a likelihood-ratio test for
# nested genetic-covariance structures. Both are dense/validation-scale and
# REML-based; the SEs are computed from a finite-difference observed-information
# matrix on the log-Cholesky parameterization (the same scale the optimizer
# uses), mirroring the univariate V1-HERIT-CI machinery.

# Lanczos log-gamma (g = 7); valid for real x. Used only for the chi-square
# survival function below (the package avoids a SpecialFunctions dependency).
function _loggamma(x::Real)
    g = 7.0
    c = (0.99999999999980993, 676.5203681218851, -1259.1392167224028,
         771.32342877765313, -176.61502916214059, 12.507343278686905,
         -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7)
    if x < 0.5
        return log(π / sin(π * x)) - _loggamma(1 - x)
    end
    x -= 1
    a = c[1]
    tt = x + g + 0.5
    @inbounds for i in 2:9
        a += c[i] / (x + (i - 1))
    end
    return 0.5 * log(2π) + (x + 0.5) * log(tt) - tt + log(a)
end

# Regularized lower incomplete gamma P(a, x) by series (x < a + 1).
function _reg_gamma_p_series(a::Real, x::Real)
    ap = a
    del = 1.0 / a
    s = del
    @inbounds for _ in 1:1000
        ap += 1.0
        del *= x / ap
        s += del
        abs(del) < abs(s) * 1e-15 && break
    end
    return s * exp(-x + a * log(x) - _loggamma(a))
end

# Regularized upper incomplete gamma Q(a, x) by continued fraction (x >= a + 1).
function _reg_gamma_q_cf(a::Real, x::Real)
    tiny = 1e-300
    b = x + 1.0 - a
    cc = 1.0 / tiny
    d = 1.0 / b
    h = d
    @inbounds for i in 1:1000
        an = -i * (i - a)
        b += 2.0
        d = an * d + b
        abs(d) < tiny && (d = tiny)
        cc = b + an / cc
        abs(cc) < tiny && (cc = tiny)
        d = 1.0 / d
        del = d * cc
        h *= del
        abs(del - 1.0) < 1e-15 && break
    end
    return exp(-x + a * log(x) - _loggamma(a)) * h
end

# Upper-tail (survival) of the chi-square distribution: P(χ²_k > x).
function _chisq_sf(x::Real, k::Real)
    isfinite(k) && k > 0 || throw(ArgumentError("degrees of freedom must be finite and positive"))
    isnan(x) && throw(ArgumentError("chi-square statistic must not be NaN"))
    x <= 0 && return 1.0
    x == Inf && return 0.0
    a = k / 2
    z = x / 2
    return z < a + 1 ? 1.0 - _reg_gamma_p_series(a, z) : _reg_gamma_q_cf(a, z)
end

"""
    nested_lrt(loglik_constrained, loglik_full; df, boundary_df = 0, label = "LRT")

Fit-agnostic likelihood-ratio test helper. The statistic is
`2·(loglik_full − loglik_constrained)`; the reference distribution depends on
`boundary_df`, the number of constrained parameters lying ON a boundary of the
full parameter space under the null:

- `boundary_df = 0` (interior null): plain `χ²_df` tail, valid under regular
  local identification and ordinary likelihood asymptotics.
- `boundary_df = 1` (one parameter on its boundary, e.g. a variance fixed at 0):
  under the regular single variance-component boundary conditions, the
  50:50 chi-bar-squared mixture `½·χ²_df + ½·χ²_{df−1}` (Self & Liang 1987;
  Stram & Lee 1994). The naive `χ²_df` tail is larger than this mixture tail.
  A boundary count alone does not establish these regularity conditions.
- `boundary_df ≥ 2`: weights are not computed. The naive `χ²_df` tail is
  returned with the legacy token `mixture = :chisq_conservative`. This token
  does not certify the reference law or conservativity for arbitrary models;
  those require an appropriate regular cone limit and its component degrees.

Log-likelihoods must be finite before and after Float64 conversion. A positive
overflow of the likelihood-difference statistic has the chi-square tail limit zero.

Returns `(statistic, df, boundary_df, pvalue, boundary, mixture, note)`. Asymptotic
theory only — the single-boundary mixture is textbook, not recovery-calibrated.
"""
function nested_lrt(loglik_constrained::Real, loglik_full::Real; df::Integer,
                    boundary_df::Integer = 0, label::AbstractString = "LRT")
    df > 0 ||
        throw(ArgumentError("`full` must have more parameters than `constrained` (df = $df)"))
    0 <= boundary_df <= df ||
        throw(ArgumentError("boundary_df must be in 0:df (got boundary_df = $boundary_df, df = $df)"))
    isfinite(loglik_constrained) && isfinite(loglik_full) ||
        throw(ArgumentError("log-likelihoods must be finite"))
    lc = Float64(loglik_constrained)
    lf = Float64(loglik_full)
    isfinite(lc) && isfinite(lf) || throw(ArgumentError("log-likelihoods must be finite after Float64 conversion"))
    statistic = 2 * (lf - lc)
    s = max(statistic, 0.0)
    # χ² tail with the df = 0 edge as a point mass at 0 (tail 0 for s>0, 1 for s==0)
    chisq_tail(x, k) = k == 0 ? (x > 0 ? 0.0 : 1.0) : _chisq_sf(x, k)
    if boundary_df == 0
        pvalue = _chisq_sf(s, df)
        mixture = :chisq
    elseif boundary_df == 1
        pvalue = 0.5 * chisq_tail(s, df) + 0.5 * chisq_tail(s, df - 1)
        mixture = :chibar_5050
    else
        pvalue = _chisq_sf(s, df)
        mixture = :chisq_conservative
    end
    note = if statistic < -1e-6
        "$label: negative statistic ($(round(statistic, digits = 6))): `full` did not dominate `constrained` — check nesting and convergence"
    elseif boundary_df == 0
        "$label: interior null; χ²_$df asymptotics apply"
    elseif boundary_df == 1
        "$label: one boundary parameter; 50:50 chi-bar-squared mixture (Self & Liang 1987; Stram & Lee 1994)"
    else
        "$label: boundary weights are not computed; reported χ²_$df is a naive tail (legacy :chisq_conservative token), with validity conditional on the model boundary law"
    end
    return (statistic = statistic, df = df, boundary_df = boundary_df, pvalue = pvalue,
            boundary = boundary_df > 0, mixture = mixture, note = note)
end

# Central finite-difference Hessian of a scalar function.
function _fd_hessian(f, x::AbstractVector; h::Real = 1e-4)
    h = _mv_fd_step(h)
    x = _mv_fd_points(x, h)
    n = length(x)
    H = zeros(n, n)
    f0 = f(x)
    @inbounds for i in 1:n
        xp = collect(float.(x)); xp[i] += h
        xm = collect(float.(x)); xm[i] -= h
        H[i, i] = (f(xp) - 2 * f0 + f(xm)) / h^2
    end
    @inbounds for i in 1:n, j in (i + 1):n
        xpp = collect(float.(x)); xpp[i] += h; xpp[j] += h
        xpm = collect(float.(x)); xpm[i] += h; xpm[j] -= h
        xmp = collect(float.(x)); xmp[i] -= h; xmp[j] += h
        xmm = collect(float.(x)); xmm[i] -= h; xmm[j] -= h
        H[i, j] = (f(xpp) - f(xpm) - f(xmp) + f(xmm)) / (4 * h^2)
        H[j, i] = H[i, j]
    end
    return H
end

# Central finite-difference Jacobian of a vector-valued function.
function _fd_jacobian(g, x::AbstractVector; h::Real = 1e-4)
    h = _mv_fd_step(h)
    x = _mv_fd_points(x, h)
    n = length(x)
    g0 = g(x)
    m = length(g0)
    J = zeros(m, n)
    @inbounds for j in 1:n
        xp = collect(float.(x)); xp[j] += h
        xm = collect(float.(x)); xm[j] -= h
        J[:, j] = (g(xp) .- g(xm)) ./ (2 * h)
    end
    return J
end

# Flattened quantities of interest from a log-Cholesky parameter vector:
# [G0 lower-triangle; R0 lower-triangle; genetic-corr strict-lower;
#  residual-corr strict-lower; per-trait h²].
function _mv_quantities(θ::AbstractVector, t::Int, ng::Int)
    G = _chol_params_to_cov(@view(θ[1:ng]), t)
    R = _chol_params_to_cov(@view(θ[ng + 1:end]), t)
    rg = genetic_correlation(Matrix(G))
    rr = genetic_correlation(Matrix(R))
    out = Float64[]
    for j in 1:t, i in j:t; push!(out, G[i, j]); end
    for j in 1:t, i in j:t; push!(out, R[i, j]); end
    for j in 1:t, i in (j + 1):t; push!(out, rg[i, j]); end
    for j in 1:t, i in (j + 1):t; push!(out, rr[i, j]); end
    for k in 1:t; push!(out, G[k, k] / (G[k, k] + R[k, k])); end
    return out
end

"""
    multivariate_covariance_standard_errors(fit, Y, X, Z, Ainv; fd_step = 1e-4)

Asymptotic standard errors for an **unstructured** multivariate REML fit
([`fit_multivariate_reml`](@ref)). Pass the same `Y, X, Z, Ainv` used for the
fit. Standard errors come from the observed-information matrix (a central
finite-difference Hessian of the REML log-likelihood on the log-Cholesky
parameterization, the scale the optimizer uses) propagated through the delta
method to the genetic/residual covariances, the derived correlations, and the
per-trait heritabilities.

Returns a `NamedTuple` of `t×t` SE matrices `genetic_covariance`,
`residual_covariance`, `genetic_correlation`, `residual_correlation`
(correlation-SE diagonals are `0`), the length-`t` `heritability` SE vector, and
the raw `information` matrix.

Requires `converged = true` and a finite positive representable difference step.
Experimental, asymptotic, dense/validation-scale, REML-only. SEs are
finite-difference approximations and are wide/unreliable at small `n`; not
coverage-calibrated. Throws if the observed information is not finite
positive-definite (a flat or boundary optimum). A fitted off-diagonal
`|r| ≥ 1 − 1e-6` is treated as a boundary even when the finite-difference
Hessian appears PD (platform/roundoff). Structured/factor-analytic fits
are **not** supported by this unstructured-coordinate SE implementation;
rotation-invariant covariance quantities would need a separate identified
parameterization and validation.
"""
function multivariate_covariance_standard_errors(fit, Y, X, Z, Ainv; fd_step::Real = 1e-4)
    _mv_require_converged(fit)
    fd_step = _mv_fd_step(fd_step)
    hasproperty(fit, :permanent_covariance) &&
        throw(ArgumentError("covariance standard errors for repeatability fits require a permanent-environment-aware information matrix"))
    getproperty(fit, :genetic_structure) == :unstructured ||
        throw(ArgumentError("covariance standard errors are implemented for the :unstructured fit only; structured fits need a separately validated covariance-quantity SE path"))
    G0 = Matrix(Float64.(Matrix(fit.genetic_covariance)))
    R0 = Matrix(Float64.(Matrix(fit.residual_covariance)))
    t = size(G0, 1)
    if t > 1
        # Optimizer and finite-difference roundoff can make the information
        # matrix appear positive definite even when a fitted correlation is
        # numerically on the covariance boundary.  Reject that case directly
        # so the documented boundary contract is platform-independent.
        for C in (genetic_correlation(G0), genetic_correlation(R0))
            any(abs(C[i, j]) >= 1 - 1e-6 for j in 1:t for i in (j + 1):t) &&
                throw(ArgumentError("observed information is not finite positive-definite at the estimate (flat/boundary optimum); standard errors are unavailable"))
        end
    end
    ng = t * (t + 1) ÷ 2
    phat = vcat(_cov_to_chol_params(G0, t), _cov_to_chol_params(R0, t))
    loglik(θ) = _multivariate_reml_loglik(Y, X, Z, Ainv,
        _chol_params_to_cov(@view(θ[1:ng]), t),
        _chol_params_to_cov(@view(θ[ng + 1:end]), t))
    H = -_fd_hessian(loglik, phat; h = fd_step)
    Hsym = Symmetric((H + transpose(H)) / 2)
    (all(isfinite, H) && isposdef(Hsym)) ||
        throw(ArgumentError("observed information is not finite positive-definite at the estimate (flat/boundary optimum); standard errors are unavailable"))
    Σθ = inv(Hsym)
    J = _fd_jacobian(θ -> _mv_quantities(θ, t, ng), phat; h = fd_step)
    Σg = J * Σθ * transpose(J)
    se = sqrt.(max.(diag(Σg), 0.0))

    seG = zeros(t, t); seR = zeros(t, t); seRG = zeros(t, t); seRR = zeros(t, t)
    idx = 1
    for j in 1:t, i in j:t; seG[i, j] = se[idx]; seG[j, i] = se[idx]; idx += 1; end
    for j in 1:t, i in j:t; seR[i, j] = se[idx]; seR[j, i] = se[idx]; idx += 1; end
    for j in 1:t, i in (j + 1):t; seRG[i, j] = se[idx]; seRG[j, i] = se[idx]; idx += 1; end
    for j in 1:t, i in (j + 1):t; seRR[i, j] = se[idx]; seRR[j, i] = se[idx]; idx += 1; end
    seh2 = se[idx:idx + t - 1]

    return (
        genetic_covariance = seG,
        residual_covariance = seR,
        genetic_correlation = seRG,
        residual_correlation = seRR,
        heritability = collect(seh2),
        information = Matrix(Hsym),
    )
end

"""
    genetic_correlation_interval(fit, Y, X, Z, Ainv; level = 0.95, method = :delta,
                                 pairs = nothing, fd_step = 1e-4)

Experimental two-sided confidence interval for each off-diagonal genetic correlation
`r_g[i,j]` of an `:unstructured` multivariate REML fit. Returns a `NamedTuple` of
parallel per-pair vectors over the `t(t-1)/2` strict-lower trait pairs —
`(trait_i, trait_j, estimate, lower, upper, lower_clamped, upper_clamped, level,
method, converged)` — plus the symmetric `t×t` matrices `lower_matrix`/`upper_matrix`
(NaN on the diagonal and off the returned pairs; NO fabricated diagonal whiskers,
mirroring the `seRG` diagonal-zero convention). `pairs` optionally restricts to a
subset of `(i, j)` index tuples (`i > j`).

`method = :delta` (the only method this slice): reuses the validated observed-
information + delta-method [`multivariate_covariance_standard_errors`](@ref) `seRG`
and builds the interval on the **Fisher-z scale** (`z = atanh(r_g)`,
`se_z = se_rg/(1-r_g²)`, endpoints `tanh(z ∓ q·se_z)`) so it always lands in
`(-1, 1)`; `lower_clamped`/`upper_clamped` are `false` (delta never clamps). If the
SE path throws (non-PD observed information / boundary optimum, e.g. `r_g → ±1`), a
clear `ArgumentError` is propagated rather than a fabricated whisker. (`method =
:profile`, a profile-LRT inversion with the `(i,j)` correlation pinned, is explicit
follow-up.)

Structured fits (`:diagonal`/`:lowrank`/`:factor_analytic`) are rejected because
this interval uses only the unstructured-coordinate SE path. Off-diagonal
genetic correlations are 0 by construction under `:diagonal`; FA covariance
correlations can be identified at regular points but their interval path has
not been implemented or calibrated here.

EXPERIMENTAL, asymptotic, REML-only, and NOT coverage-calibrated — a Wald
approximation on the Fisher-z scale. It does NOT extend the `V4-MV-REML` covered
claim (which is the unstructured REML POINT ESTIMATE only); this is a new uncertainty
surface landing as partial-quality. An opt-in coverage harness is future work.
"""
function genetic_correlation_interval(fit, Y, X, Z, Ainv; level::Real = 0.95,
                                      method::Symbol = :delta, pairs = nothing,
                                      fd_step::Real = 1e-4)
    _mv_require_converged(fit)
    fd_step = _mv_fd_step(fd_step)
    0 < level < 1 || throw(ArgumentError("level must be in (0, 1)"))
    getproperty(fit, :genetic_structure) == :unstructured || throw(ArgumentError(
        "genetic_correlation_interval requires an :unstructured fit: structured-fit covariance intervals need a separately validated SE path"))
    method === :delta || throw(ArgumentError(
        "genetic_correlation_interval: only method = :delta is implemented this slice; :profile (profile-LRT with the (i,j) correlation pinned) is follow-up"))
    rg = Matrix(Float64.(Matrix(fit.genetic_correlation)))
    t = size(rg, 1)
    se = try
        multivariate_covariance_standard_errors(fit, Y, X, Z, Ainv; fd_step = fd_step)
    catch err
        err isa ArgumentError || rethrow()
        throw(ArgumentError("genetic_correlation_interval(:delta) needs the delta-method SEs, which are unavailable here ($(err isa ArgumentError ? err.msg : sprint(showerror, err))) — e.g. a flat/boundary optimum with r_g → ±1; no interval is reported (no fabricated whisker)"))
    end
    seRG = se.genetic_correlation
    z = _standard_normal_quantile((1 + level) / 2)

    wanted = pairs === nothing ? [(i, j) for j in 1:t for i in (j + 1):t] :
             [(Int(p[1]), Int(p[2])) for p in pairs]
    for (i, j) in wanted
        (1 <= j < i <= t) ||
            throw(ArgumentError("pair ($i, $j) must satisfy 1 ≤ j < i ≤ $t (strict-lower)"))
    end

    n = length(wanted)
    ti = Vector{Int}(undef, n); tj = Vector{Int}(undef, n)
    est = Vector{Float64}(undef, n); lo = Vector{Float64}(undef, n); up = Vector{Float64}(undef, n)
    lc = falses(n); uc = falses(n)
    LM = fill(NaN, t, t); UM = fill(NaN, t, t)
    for (k, (i, j)) in enumerate(wanted)
        r = rg[i, j]
        zr = atanh(r)
        se_z = seRG[i, j] / (1 - r^2)
        l = tanh(zr - z * se_z); u = tanh(zr + z * se_z)
        ti[k] = i; tj[k] = j; est[k] = r; lo[k] = l; up[k] = u
        LM[i, j] = l; LM[j, i] = l; UM[i, j] = u; UM[j, i] = u
    end
    return (trait_i = ti, trait_j = tj, estimate = est, lower = lo, upper = up,
            lower_clamped = lc, upper_clamped = uc, level = Float64(level),
            method = method, converged = fit.converged,
            lower_matrix = LM, upper_matrix = UM)
end

function _mv_nparams(fit)
    t = size(Matrix(fit.genetic_covariance), 1)
    s = getproperty(fit, :genetic_structure)
    r = getproperty(fit, :genetic_rank)
    ngen = if s == :unstructured
        t * (t + 1) ÷ 2
    elseif s == :diagonal
        t
    elseif s == :lowrank
        rr = Int(r)
        t * rr - rr * (rr - 1) ÷ 2  # nominal full-rank dimension after quotienting O(r)
    elseif s == :factor_analytic
        rr = Int(r)
        t * rr + t - rr * (rr - 1) ÷ 2  # nominal parameter count after quotienting O(r); singular strata may have less
    else
        throw(ArgumentError("unknown genetic_structure $s"))
    end
    return ngen + t * (t + 1) ÷ 2  # R0 is always unstructured
end

"""
    covariance_structure_lrt(constrained, full)

Likelihood-ratio test comparing a nested constrained genetic-covariance fit
against the `full` (less-constrained) fit, both from
[`fit_multivariate_reml`](@ref) on the **same data**. Returns a `NamedTuple`
with the LRT `statistic` `= 2(ℓ_full − ℓ_constrained)`, the parameter-count
difference `df`, the `pvalue`, a `reference` symbol naming which reference
distribution produced it, a `boundary` flag, and a `note`. Both fits must
report convergence, finite log-likelihoods, and equal trait dimensions. Only
`:diagonal`, `:lowrank`, or `:factor_analytic` nested in `:unstructured` are
accepted. The caller remains responsible for confirming that both fits use
the same data, fixed-effect design, and relationship matrix. `df` is the
**nominal generic dimension difference**: for `:lowrank`/`:factor_analytic`,
`_mv_nparams` removes the `r(r-1)/2` rotational indeterminacy of `Λ`
(`Λ` and `ΛQ` give the same `G`). This count alone does not establish local
identifiability at a particular loading matrix or regular LRT asymptotics.

Two kinds of structured null are distinguished. For neither of them is
`nested_lrt`'s chi-bar weighting invoked: this function always requests the
plain, unmixed tail (`boundary_df = 0`), because `nested_lrt`'s convex-cone
(`boundary_df ≥ 1`) branches are for genuine variance-at-zero boundaries and
neither structured null here is one:

- **No PSD-rank boundary flagged** (`:diagonal` or `:factor_analytic` nested
  in `:unstructured`, `reference = :chisq`, `boundary = false`): the plain
  χ²`df` tail is reported. For FA it is a regular asymptotic reference only
  at a locally identifiable, interior point where the covariance map has
  full local rank and the usual likelihood conditions hold. Rotation-quotient
  counting and `Ψ > 0` do not prove those conditions. For example, at
  `t = 4, K = 1`, four nonzero loadings yield Jacobian rank 8, whereas only
  two nonzero loadings leave `Ψ` nonidentified even with positive slack.
  `fit_multivariate_reml` uses the absolute genetic-variance floor
  `ψ_i = 1e-4 + exp(θ_i)`; an estimate close to the floor is another
  nonregular case. This helper checks neither local rank nor floor distance,
  so `boundary = false` is **not** a regularity certificate. The 50:50
  chi-bar correction for a single variance-at-zero boundary is not applied.

- **PSD-boundary** nulls (`:lowrank` nested in `:unstructured`,
  `reference = :chisq_naive_boundary`, `boundary = true`): a low-rank null
  `G = ΛΛ'` (rank `r < t`) lies on the boundary of the PSD cone. The regular
  χ² reference is not justified by this helper; the relevant nonstandard
  boundary limit and its weights are not derived or computed here. The
  reported p-value is the **naive** χ²`df` tail, and its direction relative
  to the relevant limit law is **not knowable** here — never call it
  conservative.

Changed in #331: because `boundary_df = 0` is now always requested, a
structured comparison whose `df` is 1 no longer receives the 50:50 chi-bar
mixture it received before. The `:lowrank`-in-`:unstructured` `t = 2`,
`rank = 1` case is the reachable instance: its reported p-value is now the
full χ²₁ tail, exactly twice the previously reported value. The statistic
and `df` are unchanged; only the reference distribution is.

Experimental, asymptotic, dense/validation-scale.
Repeatability fits include a permanent-environment covariance. This
animal-only parameter count does not cover them, so either input is rejected.
"""
function covariance_structure_lrt(constrained, full)
    (hasproperty(constrained, :permanent_covariance) ||
     hasproperty(full, :permanent_covariance)) &&
        throw(ArgumentError("covariance_structure_lrt does not support repeatability fits: the permanent-environment covariance needs a separate parameter count and reference distribution"))
    for (label, fit) in (("constrained", constrained), ("full", full))
        hasproperty(fit, :converged) && getproperty(fit, :converged) === true ||
            throw(ArgumentError("`$label` fit must report converged = true"))
        hasproperty(fit, :loglik) && isfinite(getproperty(fit, :loglik)) ||
            throw(ArgumentError("`$label` fit must have a finite loglik"))
        hasproperty(fit, :genetic_covariance) ||
            throw(ArgumentError("`$label` fit must contain genetic_covariance"))
        G = getproperty(fit, :genetic_covariance)
        size(G, 1) == size(G, 2) && size(G, 1) > 0 && all(isfinite, G) ||
            throw(ArgumentError("`$label` genetic_covariance must be finite, square, and nonempty"))
    end
    size(constrained.genetic_covariance) == size(full.genetic_covariance) ||
        throw(ArgumentError("`constrained` and `full` fits must have the same trait dimension"))
    npc = _mv_nparams(constrained)
    npf = _mv_nparams(full)
    df = npf - npc
    df > 0 ||
        throw(ArgumentError("`full` must have more covariance parameters than `constrained` (df = $df); call as covariance_structure_lrt(constrained, full)"))
    sc = getproperty(constrained, :genetic_structure)
    sf = getproperty(full, :genetic_structure)
    sf == :unstructured && sc in (:diagonal, :lowrank, :factor_analytic) ||
        throw(ArgumentError("covariance_structure_lrt supports only :diagonal, :lowrank, or :factor_analytic nested in :unstructured"))
    # The plain χ²_df tail is conditional for FA: quotienting rotations does
    # not verify local rank or distance from the uniqueness floor. `boundary`
    # below flags PSD-rank boundaries only; false is not a regularity proof.
    # :lowrank sits on the PSD-cone boundary. The relevant nonstandard limit
    # is not derived here, so the helper reports only the naive χ²_df tail and
    # leaves its direction relative to that limit law unknown.
    regular = sf == :unstructured && (sc == :diagonal || sc == :factor_analytic)
    # Always request the plain, unmixed χ²_df tail from `nested_lrt`
    # (`boundary_df = 0`): conditional for an FA interior point, and the (flagged)
    # naive reference for the PSD-boundary case. `nested_lrt`'s own
    # convex-cone (`boundary_df ≥ 1`) branches are for genuine
    # variance-at-zero boundaries and do not apply to either structured null
    # here, so they are never entered (#331/F1).
    res = nested_lrt(constrained.loglik, full.loglik; df = df, boundary_df = 0,
                     label = "covariance_structure_lrt")
    stat = res.statistic
    boundary = !regular
    reference = regular ? :chisq : :chisq_naive_boundary
    note = if stat < -1e-6
        "negative statistic ($(round(stat, digits = 6))): `full` did not dominate `constrained` — check they are nested and both converged"
    elseif regular && sc == :factor_analytic
        "FA null nested in $(sf): χ²_$df is a nominal asymptotic tail, valid only at a locally identifiable interior point with regular likelihood; rotation counting alone does not verify local rank, uniqueness-floor distance, or model identifiability"
    elseif regular
        "interior diagonal null nested in $(sf): χ²_$df is the regular asymptotic reference, subject to usual likelihood conditions"
    else
        "rank/PSD-boundary null ($(sc) nested in $(sf)): df is a nominal generic dimension difference (rotational indeterminacy removed); the reported χ²_$df p-value is the naive tail, not a derived boundary reference, and its direction relative to the relevant limit law is not known"
    end
    return (statistic = stat, df = df, pvalue = res.pvalue, boundary = boundary,
            reference = reference, note = note)
end
