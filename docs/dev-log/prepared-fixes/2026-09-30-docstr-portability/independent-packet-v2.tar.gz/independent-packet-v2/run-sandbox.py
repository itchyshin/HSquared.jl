from pathlib import Path
import os,subprocess,signal,time,json,hashlib
own=Path(__file__).resolve().parent
runtime,exe=__import__('sys').argv[1:]
pkg=own/f'package-{runtime}'
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',JULIA_NUM_THREADS='1',JULIA_PKG_OFFLINE='true',JULIA_PKG_PRECOMPILE_AUTO='0',JULIA_DEPOT_PATH='/private/tmp/hsq-goal-julia-depot:/Users/z3437171/.julia')
cmd=[exe,'--startup-file=no',f'--project={pkg}','-e','using Pkg; Pkg.test(; julia_args=["--threads=1", "--startup-file=no"])']
before={x:hashlib.sha256((pkg/x).read_bytes()).hexdigest() for x in ['Project.toml','Manifest.toml']};t=time.monotonic();timedout=False
with (own/f'actual-sandbox-{runtime}.log').open('w') as log:
 proc=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:status=proc.wait(timeout=120)
 except subprocess.TimeoutExpired:
  timedout=True;os.killpg(proc.pid,signal.SIGTERM)
  try:status=proc.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);status=proc.wait()
after={x:hashlib.sha256((pkg/x).read_bytes()).hexdigest() for x in before}
result={'runtime':runtime,'command':cmd,'exit_status':status,'elapsed_seconds':time.monotonic()-t,'timeout':timedout,'cap_seconds':120,'julia_threads':1,'blas_threads':1,'before':before,'after':after}
(own/f'actual-sandbox-{runtime}-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(1 if timedout else status)
