from pathlib import Path
import hashlib,json,difflib,shutil,subprocess
r=Path('/private/tmp/hsq-reviewed-repairs-composed-20260930');a=r/'original';b=r/'composed';base=json.loads((r/'baseline-composition-inventory.json').read_text());live=Path(json.loads((r/'snapshot.json').read_text())['live_root'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def tree(p):
 h=hashlib.sha256()
 for f in sorted(p.rglob('*')):
  if f.is_file():h.update(str(f.relative_to(p)).encode()+b'\0'+f.read_bytes()+b'\0')
 return h.hexdigest()
def diff(old,new,paths):
 out=[]
 for rel in sorted(paths):
  x=old/rel;y=new/rel
  out.extend(difflib.unified_diff(x.read_text().splitlines(True) if x.exists() else [],y.read_text().splitlines(True) if y.exists() else [],fromfile='a/'+rel if x.exists() else '/dev/null',tofile='b/'+rel if y.exists() else '/dev/null'))
 return ''.join(out)
# Reverse every logged replacement to prove the prose-only correction scope.
changes=json.loads((r/'prose-delta.json').read_text())
for rel in {v['file'] for v in changes}:
 text=(b/rel).read_text()
 for v in reversed([v for v in changes if v['file']==rel]):
  assert v['new'] in text
  text=text.replace(v['new'],v['old'],1)
 assert text==(r/'h2-before-prose'/rel).read_text(),rel
(r/'h2-prose-corrections.patch').write_text(diff(r/'h2-before-prose',b,{v['file'] for v in changes}))
# Verify the source/test changes from the first composition are confined to h2 additions.
changed=sorted(set(base['changed_files'])|{'docs/design/19-h2-scale-contract.md','test/nongaussian_h2_descriptor_regression.jl'})
for rel,pins in base['changed_files'].items():
 if rel not in ['src/nongaussian.jl','test/runtests.jl']:assert sha(b/rel)==pins['composed_sha256'],rel
newreg='\nmodule E1NonGaussianH2Descriptors\n    include(joinpath(@__DIR__, "nongaussian_h2_descriptor_regression.jl"))\nend\n'
assert (b/'test/runtests.jl').read_text()==(r/'replay-targets/test/runtests.jl').read_text()+newreg
reg=r/'runner-registration.jl';reg.write_text(reg.read_text()+newreg)
inc=json.loads((r/'focused-includes.json').read_text());inc.append(['E1NonGaussianH2Descriptors','nongaussian_h2_descriptor_regression.jl','new module include']);(r/'focused-includes.json').write_text(json.dumps(inc,indent=2)+'\n')
for _,file,_ in inc:assert (b/'test/runtests.jl').read_text().count('"'+file+'"')==1,file
assert sha(b/'test/nongaussian_h2_descriptor_regression.jl')=='6ef180997073e24708df93f1fbdd400413d140875d0aa85806649be3fe9e9986'
# Delta baseline is made from exact baseline replay files, plus untouched original doc19.
d=r/'h2-delta-original';d.mkdir(exist_ok=True)
for rel in ['src/nongaussian.jl','test/runtests.jl','docs/design/19-h2-scale-contract.md']:
 src=(r/'replay-targets'/rel) if rel in ['src/nongaussian.jl','test/runtests.jl'] else a/rel
 dst=d/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
(r/'h2-composition-delta.patch').write_text(diff(d,b,['src/nongaussian.jl','test/runtests.jl','docs/design/19-h2-scale-contract.md','test/nongaussian_h2_descriptor_regression.jl']))
(r/'combined-repairs.patch').write_text(diff(a,b,changed))
(r/'changed-files.json').write_text(json.dumps(changed,indent=2)+'\n')
results=[]
for cwd in [a,live]:
 q=subprocess.run(['git','apply','--check',str(r/'combined-repairs.patch')],cwd=cwd,text=True,capture_output=True);results.append(dict(cwd=str(cwd),exit=q.returncode,stdout=q.stdout,stderr=q.stderr));assert q.returncode==0,results[-1]
replay=r/'final-replay-targets';replay.mkdir(exist_ok=True)
for rel in changed:
 if (a/rel).exists():
  dest=replay/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a/rel,dest)
q=subprocess.run(['git','apply',str(r/'combined-repairs.patch')],cwd=replay,text=True,capture_output=True);assert q.returncode==0,q.stderr
for rel in changed:assert sha(replay/rel)==sha(b/rel),rel
# Live source unchanged; only announced HEAD checkpoints are allowed.
assert tree(live/'src')==base['original_source_tree_sha256']
for rel in changed:
 if (a/rel).exists():assert sha(live/rel)==sha(a/rel),rel
preserved=base.get('unchanged_files',{})
print('baseline preserved key:',list(k for k in base if 'preserv' in k or 'unchanged' in k))
for rel in ['src/multivariate.jl','sim/fa_ordinary_start_recovery_20260928.jl','Project.toml','Manifest.toml','test/test_fa_weak_direction.jl','test/test_payload_v2_parity.jl']:
 assert sha(a/rel)==sha(b/rel)==sha(live/rel),rel
original_sigs={}
for rel,n in [('docs/design/capability-status.md',2),('docs/design/validation-debt-register.md',3)]:
 def sig(p):return ['|'.join(t.strip() for t in line.split('|')[1:n+1]) for line in p.read_text().splitlines() if line.startswith('|')]
 assert sig(a/rel)==sig(b/rel),rel
 original_sigs[rel]=n
inv=dict(base)
inv.update(composed_source_tree_sha256=tree(b/'src'),combined_patch_sha256=sha(r/'combined-repairs.patch'),changed_files={rel:dict(original_sha256=sha(a/rel),composed_sha256=sha(b/rel)) for rel in changed},inputs=json.loads((r/'inputs.json').read_text()),live_head_at_close=subprocess.check_output(['git','rev-parse','HEAD'],cwd=live,text=True).strip(),focused_assertions=651,focused_assertions_basis='481 baseline assertions carried; 170 new h2 assertions executed on final composition',h2_check_exit=0,h2_assertions=170,h2_checks_log_sha256=sha(r/'h2-composition-checks.log'),h2_prose_patch_sha256=sha(r/'h2-prose-corrections.patch'),h2_delta_patch_sha256=sha(r/'h2-composition-delta.patch'),h2_prose_reversible_scope_proof=True,h2_test_sha256=sha(b/'test/nongaussian_h2_descriptor_regression.jl'),registered_test_includes=inc,status_table_signature_columns=original_sigs,preserved_files={rel:sha(b/rel) for rel in ['src/multivariate.jl','sim/fa_ordinary_start_recovery_20260928.jl','Project.toml','Manifest.toml','test/test_fa_weak_direction.jl','test/test_payload_v2_parity.jl']},h2_addition_old_testfiles_byte_identical=True,h2_new_helper_references_in_baseline_focused_tests=0,final_runner_sha256=sha(b/'test/runtests.jl'),payload_parser_sha256=sha(b/'src/bridge_payload_v2.jl'))
(r/'composition-inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
(r/'final-combined-apply-check.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:inv[k] for k in ['composed_source_tree_sha256','combined_patch_sha256','final_runner_sha256','payload_parser_sha256','live_head_at_close']},indent=2));print('Changed files',len(changed),'inputs',len(inv['inputs']))
