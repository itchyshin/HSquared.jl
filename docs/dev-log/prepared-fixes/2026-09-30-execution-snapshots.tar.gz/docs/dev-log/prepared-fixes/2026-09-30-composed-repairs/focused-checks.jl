using Test, LinearAlgebra, SparseArrays, Statistics, HSquared

@testset "Composition Julia syntax" begin
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "src/genetic_gllvm.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "src/bridge_payload_v2.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "src/random_regression.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "src/validation_status.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "src/data.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "src/nongaussian.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "src/postfit.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "src/genomic.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "test/runtests.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "test/gllvm_input_guard_regression.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "test/gllvm_descriptor_record_regression.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "test/test_coefcov_fields.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "test/rr_descriptor_scale_regression.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "test/data_dict_missing_count_regression.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "test/flat_integral_endpoint_regression.jl"), String)) isa Expr
    @test Meta.parseall(read(joinpath(@__DIR__, "composed", "test/nongaussian_finite_ingress_regression.jl"), String)) isa Expr
end

module BaselineValidationStatus
include(joinpath(@__DIR__, "original", "src", "validation_status.jl"))
end
@testset "Validation row IDs and statuses retained" begin
    before = BaselineValidationStatus.validation_status()
    after = HSquared.validation_status()
    @test Set((r.id, r.status) for r in before) == Set((r.id, r.status) for r in after)
    @test count(r -> r.status == "covered", before) == count(r -> r.status == "covered", after)
end
module E1GLLVMInputGuards
include(joinpath(@__DIR__, "composed", "test", "gllvm_input_guard_regression.jl"))
end

module E1GLLVMDescriptorRecord
include(joinpath(@__DIR__, "composed", "test", "gllvm_descriptor_record_regression.jl"))
end

module E1CoefcovFields
include(joinpath(@__DIR__, "composed", "test", "test_coefcov_fields.jl"))
end

module E1RRDescriptors
include(joinpath(@__DIR__, "composed", "test", "rr_descriptor_scale_regression.jl"))
end

module E1DataDictMissingCount
include(joinpath(@__DIR__, "composed", "test", "data_dict_missing_count_regression.jl"))
end

module E1FlatIntegralEndpoints
include(joinpath(@__DIR__, "composed", "test", "flat_integral_endpoint_regression.jl"))
end

module E1NonGaussianFiniteIngress
include(joinpath(@__DIR__, "composed", "test", "nongaussian_finite_ingress_regression.jl"))
end

module E1MarkerPostfitContract
using Test, LinearAlgebra, SparseArrays, Statistics, HSquared
include(joinpath(@__DIR__, "focused-marker-testset.jl"))
end
