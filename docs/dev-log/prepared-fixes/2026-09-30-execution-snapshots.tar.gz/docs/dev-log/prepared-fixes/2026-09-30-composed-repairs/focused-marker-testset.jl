@testset "Phase 5 post-fit marker scan (#45)" begin
    # The (fit, markers) entry points must reduce EXACTLY to the explicit-argument
    # scans at the fit's design (y/X/Z), relationship precision (Ainv), and fitted
    # variance components — the fit object already carries spec.Ainv.
    ped = normalize_pedigree(["a1", "a2", "a3", "a4", "a5", "a6"],
        ["0", "0", "a1", "a1", "a2", "a2"], ["0", "0", "a2", "a2", "0", "0"])
    Ainv = pedigree_inverse(ped)
    y = [2.0, 3.0, 2.5, 3.5, 4.0, 1.5]
    X = ones(6, 1)
    Z = sparse(1.0I, 6, 6)
    spec = animal_model_spec(y, X, Z, Ainv; ids = ped.ids, method = :REML)
    lik = gaussian_loglik(spec, 1.2, 0.8; method = :REML)
    fit = AnimalModelFit(spec, lik, (sigma_a2 = 1.2, sigma_e2 = 0.8), true, "supplied", 0)
    markers = Float64[0 1 2; 1 1 0; 2 0 1; 0 2 1; 1 0 2; 2 1 0]
    mids = ["m1", "m2", "m3"]

    # mixed-model (relatedness-corrected GLS) post-fit == explicit args
    pf = mixed_model_marker_scan(fit, markers; marker_ids = mids)
    ex = mixed_model_marker_scan(y, X, Z, Ainv, markers, 1.2, 0.8; marker_ids = mids)
    @test pf == ex
    @test pf.target == :mixed_model_marker_scan
    @test pf.marker_ids == mids
    @test length(pf.effects) == 3
    payload = marker_scan_result_payload(pf)
    @test propertynames(payload) == (
        :engine,
        :target,
        :n_markers,
        :marker_ids,
        :effects,
        :standard_errors,
        :z_scores,
        :chisq,
        :p_values,
        :bonferroni_p_values,
        :bh_q_values,
        :lod_scores,
        :denominators,
        :allele_frequencies,
        :vanraden_scale,
        :variance_components,
    )
    @test payload.engine == "HSquared.jl"
    @test payload.target == :mixed_model_marker_scan
    @test payload.n_markers == 3
    @test payload.marker_ids == mids
    @test payload.effects ≈ pf.effects
    @test payload.standard_errors ≈ pf.standard_errors
    @test payload.z_scores ≈ pf.z_scores
    @test payload.chisq ≈ pf.chisq
    @test payload.p_values ≈ pf.p_values
    @test payload.bonferroni_p_values ≈ pf.bonferroni_p_values
    @test payload.bh_q_values ≈ pf.bh_q_values
    @test payload.lod_scores ≈ pf.lod_scores
    @test payload.denominators ≈ pf.denominators
    @test payload.allele_frequencies ≈ pf.p
    @test payload.vanraden_scale ≈ pf.k
    @test payload.variance_components == (sigma_a2 = 1.2, sigma_e2 = 0.8)

    # fixed-effect post-fit == explicit args (uses the fit's residual variance)
    pf2 = single_marker_scan(fit, markers; marker_ids = mids)
    ex2 = single_marker_scan(y, X, markers; sigma_e2 = 0.8, marker_ids = mids)
    @test pf2 == ex2

    # Discriminating (review #45, Curie): a NON-identity (permutation) random-effect
    # incidence Z changes the GLS covariance V = σ²a Z A Z' + σ²e I, so the fit's Z
    # must genuinely be threaded through (not silently treated as identity).
    P = sparse(Float64[0 1 0 0 0 0
                       1 0 0 0 0 0
                       0 0 0 1 0 0
                       0 0 1 0 0 0
                       0 0 0 0 0 1
                       0 0 0 0 1 0])
    specP = animal_model_spec(y, X, P, Ainv; ids = ped.ids, method = :REML)
    likP = gaussian_loglik(specP, 1.2, 0.8; method = :REML)
    fitP = AnimalModelFit(specP, likP, (sigma_a2 = 1.2, sigma_e2 = 0.8), true, "supplied", 0)
    @test mixed_model_marker_scan(fitP, markers; marker_ids = mids) ==
          mixed_model_marker_scan(y, X, P, Ainv, markers, 1.2, 0.8; marker_ids = mids)
    @test mixed_model_marker_scan(fitP, markers).effects != pf.effects   # permutation Z ≠ identity Z
    # the fixed-effect screen ignores Z/Ainv: same y/X/σ²e ⇒ identical regardless of Z
    @test single_marker_scan(fitP, markers; marker_ids = mids) ==
          single_marker_scan(fit, markers; marker_ids = mids)

    # Fitted convenience routes fail closed before delegating when convergence
    # was not reported, even though their six-argument fixture constructor is valid.
    unresolved = AnimalModelFit(spec, lik, (sigma_a2 = 1.2, sigma_e2 = 0.8), false, "supplied", 0)
    for scan in (mixed_model_marker_scan, single_marker_scan)
        err = try
            scan(unresolved, markers)
            nothing
        catch e
            e
        end
        @test err isa ArgumentError
        @test occursin("fit must have converged", sprint(showerror, err))
    end

    # At sigma_a2 = 0 the mixed GLS covariance is sigma_e2*I. Compare its
    # coefficients and Wald errors to an independent residualized OLS calculation.
    sigma_e2_zero_additive = 0.8
    W = markers .- mean(markers; dims = 1)
    XtX = transpose(X) * X
    y_resid = y - X * (XtX \ (transpose(X) * y))
    oracle_effects = Float64[]
    oracle_ses = Float64[]
    oracle_denominators = Float64[]
    for j in axes(W, 2)
        w = W[:, j]
        w_resid = w - X * (XtX \ (transpose(X) * w))
        d = dot(w_resid, w_resid)
        push!(oracle_denominators, d)
        push!(oracle_effects, dot(w_resid, y_resid) / d)
        push!(oracle_ses, sqrt(sigma_e2_zero_additive / d))
    end
    zero_mixed = mixed_model_marker_scan(y, X, Z, Ainv, markers, 0.0, sigma_e2_zero_additive)
    zero_loco = loco_mixed_model_marker_scan(
        y, X, Z, Dict("chr1" => Matrix{Float64}(I, length(y), length(y))),
        fill("chr1", size(markers, 2)), markers, 0.0, sigma_e2_zero_additive,
    )
    for scan in (zero_mixed, zero_loco)
        @test scan.effects ≈ oracle_effects rtol = 1e-12 atol = 1e-12
        @test scan.standard_errors ≈ oracle_ses rtol = 1e-12 atol = 1e-12
        @test scan.z_scores ≈ oracle_effects ./ oracle_ses rtol = 1e-12 atol = 1e-12
        @test scan.denominators .* sigma_e2_zero_additive ≈ oracle_denominators rtol = 1e-12 atol = 1e-12
    end
    @test zero_mixed.variance_components == (sigma_a2 = 0.0, sigma_e2 = sigma_e2_zero_additive)
    @test_throws ArgumentError mixed_model_marker_scan(y, X, Z, Ainv, markers, -eps(), 1.0)
    @test_throws ArgumentError mixed_model_marker_scan(y, X, Z, Ainv, markers, NaN, 1.0)
    @test_throws ArgumentError mixed_model_marker_scan(y, X, Z, Ainv, markers, Inf, 1.0)
    negative_tiny = -BigFloat(10)^(-1000)
    @test negative_tiny < 0
    @test iszero(Float64(negative_tiny)) && signbit(Float64(negative_tiny))
    @test_throws ArgumentError mixed_model_marker_scan(y, X, Z, Ainv, markers, negative_tiny, 1.0)
    @test_throws ArgumentError loco_mixed_model_marker_scan(
        y, X, Z, Dict("chr1" => Matrix{Float64}(I, length(y), length(y))),
        fill("chr1", size(markers, 2)), markers, negative_tiny, 1.0,
    )
end

