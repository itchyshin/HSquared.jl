from pathlib import Path
import json, shutil
root=Path('/private/tmp/hsq-reviewed-repairs-composed-20260930'); composed=root/'composed'
changes=[]
def edit(rel,old,new,origin):
 p=composed/rel; s=p.read_text(); assert s.count(old)==1,(rel,old,s.count(old))
 changes.append(dict(file=rel,old=old,new=new,before_line=s[:s.index(old)].count('\n')+1,origin=origin))
 p.write_text(s.replace(old,new))
for rel in ['src/nongaussian.jl','docs/design/19-h2-scale-contract.md']:
 p=root/'h2-before-prose'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(composed/rel,p)
src='src/nongaussian.jl';doc='docs/design/19-h2-scale-contract.md'
edit(src,'# log-scale distribution-specific variance V_link = Var[log Y] = ψ₁(shape)', '# log-scale residual variance V_link = Var(log Y | η) = ψ₁(shape)','Astra Gamma conditional residual correction; adjacent same notation')
edit(src,'#    h²_obs ∈ (0,1) (verified numerically in the tests, not assumed). The expectation is', '#    the theoretical population projection satisfies h²_obs ∈ [0,1] when the\n#    observation variance is finite and positive, including zero at V_A = 0.\n#    Finite quadrature approximates these population moments. The expectation is','parent bound qualification')
edit(src,'(verified equal), always < h2_latent.', '(verified equal). In the exact finite-moment model, h2_observation is no greater than h2_latent; equal at zero genetic variance. Finite quadrature approximates this ordering.','Astra probit zero variance qualification')
edit(src,'# Gamma (log link). LATENT (log) scale: V_link = Var[log Y] = ψ₁(shape) (trigamma) — EXACT,', '# Gamma (log link). LATENT (log) scale: V_link = Var(log Y | η) = ψ₁(shape) (trigamma), EXACT,','Astra Gamma conditional residual correction')
edit(src,'V_link = trigamma(shape) = Var[log Y] (EXACT, doc-19 §3.1)', 'V_link = trigamma(shape) = Var(log Y | eta), the log-residual variance (EXACT, doc-19 §3.1)','Astra Gamma returned caveat correction')
edit(src,'`h2_observation ∈ (0,1)`), integrating over the LINEAR-PREDICTOR distribution', 'the theoretical population projection satisfies `h2_observation ∈ [0,1]` when\nobservation variance is finite and positive, including zero at `V_A = 0`), integrating\nover the LINEAR-PREDICTOR distribution','parent public docstring bound qualification')
edit(src,"variance) via the module's existing 20-node Gauss–Hermite for logit and the", "variance) via the module's existing 20-node Gauss–Hermite for logit, which approximates\nthe population moments, and the",'parent quadrature qualification')
edit(src,'COUNT for Poisson; Gaussian reduces to `V_A/(V_A+σ²e)` on both scales. **Threshold\nfamilies**', 'COUNT for Poisson; Gaussian reduces to `V_A/(V_A+σ²e)` on both scales. Gaussian uses\nthis conditional ratio on both scales and requires `predictor_variance = 0`; nonzero\nfixed-effect spread is rejected. **Threshold families**','parent Gaussian conditional ratio requirement')
edit(src,'predictor variance, is the NS "variance explained by fixed effects" term). The', 'predictor variance, is the NS "variance explained by fixed effects" term). This is\nadditional fixed-predictor spread, not total predictor variance. `V_η = V_A + V_fixed`\nassumes zero covariance between genetic and fixed contributions and a normal\npredictor approximation. The','parent predictor variance assumptions')
edit(src,'with a caveat for a per-record varying `n_trials` (a single data-scale h² is\nill-defined under varying denominators — not silently averaged).', 'with a caveat for genuinely varying per-record `n_trials` (a single data-scale h²\nis ill-defined under varying denominators). Constant fit trial vectors use their\ncommon scalar trial count.','parent common versus varying trials')
# All four Gamma shorthand occurrences carry the same conditional meaning.
s=(composed/doc).read_text(); assert s.count('Var[log Y]')==4,s.count('Var[log Y]')
for _ in range(4):
 s=(composed/doc).read_text(); pos=s.index('Var[log Y]');changes.append(dict(file=doc,old='Var[log Y]',new='Var(log Y | η)',before_line=s[:pos].count('\n')+1,origin='Astra Gamma conditional residual correction'));(composed/doc).write_text(s[:pos]+s[pos:].replace('Var[log Y]','Var(log Y | η)',1))
edit(doc,'`Ψ² V_A ≤ Var(E[y|η])`, so `h²_observation ∈ (0,1)` — verified numerically in the suite, not\nassumed.', '`Ψ² V_A ≤ Var(E[y|η])`, so the theoretical population projection satisfies\n`h²_observation ∈ [0,1]` when observation variance is finite and positive, including\nzero at `V_A = 0`. Finite quadrature approximates these population moments.','parent zero variance bound synchronization')
edit(doc,'incidences (maximum ≈ 0.637 at `p = 0.5`), the observed-0/1 heritability is **always smaller\nthan the liability heritability** — the classic Dempster–Lerner ordering (verified\nempirically:', 'incidences (maximum ≈ 0.637 at `p = 0.5`), the observed-0/1 heritability is **no greater\nthan the liability heritability**, with equality at zero genetic variance and strict\ninequality at positive genetic variance in the exact finite-moment model. This is\nthe classic Dempster–Lerner ordering; finite quadrature approximates it (verified\nempirically:','Astra probit zero variance qualification')
edit(doc,'log(Y/μ)`, whose variance for `Y ~ Gamma(shape ν, mean μ)` is a standard, mean-independent fact:', 'log(Y/μ)`, whose conditional variance for `Y | η ~ Gamma(shape ν, mean μ)`\nwith `η` held fixed is a standard, mean-independent fact:','Astra conditional Gamma interpretation')
edit(doc,'**Numerically verified** (dependency-free, `3×10⁶` Marsaglia–Tsang draws per shape): the empirical', '**Numerically verified** (dependency-free, `3×10⁶` Marsaglia–Tsang draws per shape,\nwith `η` held fixed): the empirical','Astra historical Gamma check clarification')
(root/'prose-delta.json').write_text(json.dumps(changes,indent=2,ensure_ascii=False)+'\n')
r=composed/'test/runtests.jl'; r.write_text(r.read_text()+'\nmodule E1NonGaussianH2Descriptors\n    include(joinpath(@__DIR__, "nongaussian_h2_descriptor_regression.jl"))\nend\n')
inc=json.loads((root/'focused-includes.json').read_text());print(type(inc).__name__)
(root/'baseline-composition-receipt.md').write_text((root/'baseline-composition-receipt.md').read_text().replace('to6271','to 6271'))
print('Prose corrections:',len(changes))
