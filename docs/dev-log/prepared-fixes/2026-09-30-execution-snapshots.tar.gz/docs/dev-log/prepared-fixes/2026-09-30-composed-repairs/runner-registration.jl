
# Exact-current E1 repairs: keep standalone test scopes independent.
module E1GLLVMInputGuards
    include(joinpath(@__DIR__, "gllvm_input_guard_regression.jl"))
end

module E1GLLVMDescriptorRecord
    include(joinpath(@__DIR__, "gllvm_descriptor_record_regression.jl"))
end

module E1RRDescriptors
    include(joinpath(@__DIR__, "rr_descriptor_scale_regression.jl"))
end

module E1DataDictMissingCount
    include(joinpath(@__DIR__, "data_dict_missing_count_regression.jl"))
end

module E1FlatIntegralEndpoints
    include(joinpath(@__DIR__, "flat_integral_endpoint_regression.jl"))
end

module E1NonGaussianFiniteIngress
    include(joinpath(@__DIR__, "nongaussian_finite_ingress_regression.jl"))
end


module E1NonGaussianH2Descriptors
    include(joinpath(@__DIR__, "nongaussian_h2_descriptor_regression.jl"))
end
