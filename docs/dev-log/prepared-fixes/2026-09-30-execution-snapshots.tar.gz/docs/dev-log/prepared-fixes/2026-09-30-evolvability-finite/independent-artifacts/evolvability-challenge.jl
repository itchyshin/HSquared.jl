using Test,LinearAlgebra
module E
using LinearAlgebra
include("/private/tmp/e1-matrix-helper-finite-independent-20260930/evolvability/prepared/src/evolvability.jl")
end
@testset "Independent finite descriptive geometry challenges" begin
    G=diagm([7.,2.]);b=[1.,2.]
    @test E.evolvability(G,b)≈3.
    @test E.respondability(G,b)≈sqrt(13.)
    @test E.conditional_evolvability(G,b)≈7/3
    @test E.autonomy(G,b)≈7/9
    @test E.variance_along_gradient(G,b;normalize=false)==15.
    @test E.evolvability(G,-b)≈E.evolvability(G,b)
    @test E.respondability(G,-b)≈E.respondability(G,b)
    for scale in (1e-300,1e300)
        @test E.evolvability(scale*G,b)/scale≈3. rtol=1e-12
        @test E.respondability(scale*G,b)/scale≈sqrt(13.) rtol=1e-12
    end
    for b0 in ([0.,0.],[1e200,-1e200],[floatmax(Float64),floatmax(Float64)])
        @test E.variance_along_gradient(zeros(2,2),b0;normalize=false)==0.
    end
    @test E.evolvability(zeros(2,2),[1.,0.])==0.
    @test E.respondability(zeros(2,2),[1.,0.])==0.
    @test E.variance_along_gradient(diagm([1e-300,1e-300]),[1e154,0.];normalize=false)≈1e8
    @test E.variance_along_gradient(diagm([1e300,1e300]),[1e-200,0.];normalize=false)≈1e-100
    @test E.variance_along_gradient(diagm(fill(floatmax(Float64),2)),[1.,0.];normalize=false)==floatmax(Float64)
    @test E.evolvability(diagm(fill(floatmax(Float64),2)),[floatmax(Float64),0.])==floatmax(Float64)
    @test E.respondability(diagm(fill(floatmax(Float64),2)),[floatmax(Float64),0.])==floatmax(Float64)
    for beta in ([1e200,0.],[Inf,0.],[NaN,0.])
        @test_throws ArgumentError E.variance_along_gradient(Matrix{Float64}(I,2,2),beta;normalize=false)
    end
    @test_throws ArgumentError E.variance_along_gradient(diagm([1e308,1e308]),[2.,0.];normalize=false)
    @test_throws ArgumentError E.evolvability(diagm([1.,-1.]),[1.,0.])
    @test_throws ArgumentError E.respondability(diagm([1.,-1.]),[1.,0.])
    @test E.variance_along_gradient([1. -1.;-1. 1.],[1e200,1e200];normalize=false)==0.
    # Carried cancellation boundary: a mathematically zero PSD-null contrast can
    # still overflow intermediate products and is refused, not falsely returned.
    @test_throws ArgumentError E.variance_along_gradient(fill(1e307,2,2),[1e308,-1e308];normalize=false)
    println("EV_RETAINED_RAW_CANCELLATION_REFUSAL finite exact-null answer is not certified at all scales")
end
