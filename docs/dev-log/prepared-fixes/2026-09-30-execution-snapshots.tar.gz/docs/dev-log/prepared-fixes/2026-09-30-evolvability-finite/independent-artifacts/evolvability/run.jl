module HSquared
using LinearAlgebra
include(joinpath(ARGS[1],"src","evolvability.jl"))
end
using .HSquared,Test,LinearAlgebra
using .HSquared: evolvability,conditional_evolvability,autonomy,respondability,mean_evolvability,genetic_pca,genetic_pca_plot_data
include(joinpath(@__DIR__,"test","evolvability_finite_output_regression.jl"))
include(joinpath(@__DIR__,"test","existing_evolvability_stability.jl"))
