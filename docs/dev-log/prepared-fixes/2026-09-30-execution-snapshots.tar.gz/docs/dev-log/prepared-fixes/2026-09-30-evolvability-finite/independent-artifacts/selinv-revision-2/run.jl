module HSquared
using LinearAlgebra,SparseArrays
include(joinpath(ARGS[1],"src","takahashi_selinv.jl"))
end
using .HSquared,Test,LinearAlgebra,SparseArrays
include(joinpath(@__DIR__,"test","selinv_trace_finite_regression.jl"))
include(joinpath(@__DIR__,"test","existing_selinv_contracts.jl"))
