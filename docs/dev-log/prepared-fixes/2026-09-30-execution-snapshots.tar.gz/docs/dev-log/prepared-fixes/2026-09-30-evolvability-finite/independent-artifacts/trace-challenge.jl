using Test, LinearAlgebra, SparseArrays
module BaseTrace
using LinearAlgebra,SparseArrays
include("/private/tmp/e1-matrix-helper-finite-independent-20260930/selinv/original/src/takahashi_selinv.jl")
end
module FixedTrace
using LinearAlgebra,SparseArrays
include("/private/tmp/e1-matrix-helper-finite-independent-20260930/selinv/prepared/src/takahashi_selinv.jl")
end
@testset "Independent selected trace challenges" begin
    C=sparse([3. .4 .1;.4 2. .2;.1 .2 1.5]);f=cholesky(Symmetric(C));Ci=inv(Matrix(C))
    Q=sparse([2. -.6 .3;-.6 -1. .8;.3 .8 4.])
    truth=tr(Matrix(Q)*Ci)
    @test FixedTrace.selinv_trace_against(f,Q,0)≈truth atol=1e-12
    @test FixedTrace.selinv_block_traces(f,[Q],[0])≈[truth] atol=1e-12
    Q2=sparse([-3. .5;.5 2.]);truth2=tr(Matrix(Q2)*Ci[2:3,2:3])
    @test FixedTrace.selinv_trace_against(f,Q2,1)≈truth2 atol=1e-12
    @test FixedTrace.selinv_block_traces(f,[Q,Q2],[0,1])≈[truth,truth2] atol=1e-12
    neg=-Q;@test FixedTrace.selinv_trace_against(f,neg,0)≈-truth
    diagfactor=cholesky(Symmetric(spdiagm(0=>ones(2))))
    off=sparse([1],[2],[big"1e-400"],2,2)
    @test_throws ArgumentError BaseTrace.selinv_trace_against(diagfactor,off,0)
    @test_throws ArgumentError BaseTrace.selinv_block_traces(diagfactor,[off],[0])
    @test FixedTrace.selinv_trace_against(diagfactor,off,0)==0.
    @test FixedTrace.selinv_block_traces(diagfactor,[off],[0])==[0.]
    println("MH01_ORIGINAL_NONZERO_OFFPATTERN_REFUSED, PREPARED_ACCEPTS_ZERO")
    # Existing carried conversion underflow: original BigFloat arithmetic can
    # produce a representable nonzero trace after scaling by a large inverse.
    tinyfactor=cholesky(Symmetric(sparse(reshape([1e-200],1,1))))
    tinyweight=sparse(reshape([big"1e-400"],1,1))
    b=BaseTrace.selinv_trace_against(tinyfactor,tinyweight,0)
    r=FixedTrace.selinv_trace_against(tinyfactor,tinyweight,0)
    @test Float64(b)≈1e-200
    @test r==0.
    println("MH02_CONVERTED_WEIGHT_UNDERFLOW original=",Float64(b)," prepared=",r)
    for v in (NaN,Inf,-Inf,big"1e400",-big"1e400")
        q=sparse(reshape([v],1,1));unit=cholesky(Symmetric(sparse(reshape([1.],1,1))))
        @test_throws ArgumentError FixedTrace.selinv_trace_against(unit,q,0)
        @test_throws ArgumentError FixedTrace.selinv_block_traces(unit,[q],[0])
    end
end
