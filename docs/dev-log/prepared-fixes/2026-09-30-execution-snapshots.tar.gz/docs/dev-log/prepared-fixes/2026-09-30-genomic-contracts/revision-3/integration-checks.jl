using Test,HSquared,LinearAlgebra,Statistics,SparseArrays
@testset "G1 with independently reviewed G2-G6" begin
    include("test/test_genomic_summary_contracts.jl")
    include("test/test_genomic_doc_bindings.jl")
    include("test/test_genomic_variance_boundary.jl")
    include("test/focused-marker-testset.jl")
end
