using HSquared,Test
@testset "Representable public marker contribution boundary" begin
 scan=single_marker_scan([1.,2.,3.,2.],ones(4,1),reshape([0.,1.,2.,1.],4,1))
 for (p,e) in ((.5,1.8961503816218352e154),(.1,3.160250636036392e154))
  ref=Float64(2BigFloat(p)*(1-BigFloat(p))*BigFloat(e)^2)
  @test isfinite(ref)
  s=(marker_ids=["m"],effects=[e],p=[p])
  a=try marker_variance_explained(s).marker_variances[1] catch err;err end
  b=try marker_scan_table(merge(scan,(effects=[e],p=[p]))).marker_variances[1] catch err;err end
  @test a isa Float64 && isfinite(a) && isapprox(a,ref;rtol=8eps(Float64))
  @test b isa Float64 && isfinite(b) && isapprox(b,ref;rtol=8eps(Float64))
 end
end
