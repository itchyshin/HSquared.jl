include(joinpath(@__DIR__,"run_contracts.jl"))
for p in (.5,.1,1e-200)
 av=2p*(1-p); e=Float64(sqrt(BigFloat(floatmax(Float64))/BigFloat(av)))
 for x in (prevfloat(prevfloat(e)),prevfloat(e),e,nextfloat(e))
  ref=Float64(BigFloat(av)*BigFloat(x)^2)
  got=try HSquared._marker_variance_contributions([av],[x])[1] catch err;err end
  isfinite(ref) && !(got isa Float64 && isfinite(got)) && println("BOUNDARY_MISMATCH p=",p," effect=",x," ref=",ref," got=",got)
 end
end
