using Test

@testset "Complete G2-G6 scratch controls" begin
    include("test/test_genomic_summary_contracts.jl")
    include("test/test_genomic_doc_bindings.jl")
end
