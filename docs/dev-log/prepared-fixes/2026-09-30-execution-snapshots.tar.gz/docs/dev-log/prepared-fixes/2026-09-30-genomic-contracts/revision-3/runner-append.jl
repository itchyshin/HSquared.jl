
module E1GenomicContracts
    include(joinpath(@__DIR__, "test_genomic_summary_contracts.jl"))
    include(joinpath(@__DIR__, "test_genomic_doc_bindings.jl"))
    include(joinpath(@__DIR__, "test_genomic_variance_boundary.jl"))
end
