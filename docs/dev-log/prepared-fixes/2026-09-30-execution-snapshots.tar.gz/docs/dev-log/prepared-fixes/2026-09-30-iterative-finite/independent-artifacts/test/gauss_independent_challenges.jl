using Test,HSquared,LinearAlgebra,SparseArrays,Random

@testset "Gauss independent iterative finite challenges" begin
    @testset "finite range refusal and finite failure iterate" begin
        @test_throws ArgumentError HSquared._pcg_solve(identity,[1e-200];tol=1e-10,maxiter=1,applyMinv=identity)
        @test_throws ArgumentError HSquared._pcg_solve(identity,[floatmax(Float64),floatmax(Float64)];tol=1e-10,maxiter=1,applyMinv=identity)
        @test_throws ArgumentError HSquared._pcg_solve(identity,[1.];tol=1e-10,maxiter=1,applyMinv=r->[Inf])
        @test_throws ArgumentError HSquared._pcg_solve(v->[Inf],[1.];tol=1e-10,maxiter=1,applyMinv=identity)
        for C in ([2. .3;.3 4.], [1. 0.;0. 1.])
            b=[1.,2.]
            x,iters,r=HSquared._pcg_solve(v->C*v,b;tol=1e-14,maxiter=1,applyMinv=identity)
            @test all(isfinite,x)
            @test r ≈ norm(b-C*x)/norm(b) atol=eps()
            @test iters==1
        end
        x,iters,r=HSquared._pcg_solve(identity,[0.];tol=1e-14,maxiter=1,applyMinv=identity)
        @test (x,iters,r)==([0.],0,0.)
    end
    @testset "independent scaled summaries" begin
        tiny=nextfloat(0.)
        for samples in ([tiny,3tiny], [floatmax(Float64),-.5floatmax(Float64),.25floatmax(Float64)],
                        [-floatmax(Float64),floatmax(Float64)], [2.,4.,8.,-10.])
            values=BigFloat.(samples); n=length(values); avg=sum(values)/n
            sem=sqrt(sum((values.-avg).^2)/(n-1)/n)
            m,s=HSquared._matrix_free_probe_summary(samples)
            @test isapprox(m,Float64(avg);rtol=8eps(),atol=0.)
            @test isapprox(s,Float64(sem);rtol=8eps(),atol=0.)
        end
        m,s=HSquared._matrix_free_probe_summary([0.])
        @test m==0. && isnan(s)
        a=sparse([1. 0.;0. 2.]); v=HSquared._matrix_free_float64_data("sparse",a)
        @test issparse(v) && v==a
    end
    @testset "invalid update retains coherent fitted state" begin
        y=[1.,1.]; X=ones(2,1); Z=spzeros(2,1); Q=spdiagm(0=>[1.]); effects=[(Z,Q)]
        fit=fit_multi_effect_mc_reml(y,X,effects;initial=[2.,3.],iterations=1,nprobe=2,ids=[["g"]])
        @test !fit.converged
        @test fit.variance_components==(sigmas=[2.],sigma_e2=3.)
        @test fit.trace_evaluation_variance_components==fit.variance_components
        solved=solve_multi_effect_pcg(y,X,effects,fit.variance_components.sigmas,fit.variance_components.sigma_e2;ids=[["g"]])
        @test fit.beta≈solved.beta
        @test fit.beta≈[1.]
        @test fit.effects==solved.effects
        @test fit.trace_mcse==[0.]
        @test fit.ratios≈[.4]
        @test fit.boundary==[false]
        @test isnan(fit.loglik) && isnan(fit.loglik_mcse)
        ll,se=matrix_free_reml_loglik(y,X,effects,[2.],3.;slq_probes=1,slq_steps=2)
        @test isfinite(ll) && isnan(se)
    end
    @testset "failed SLQ is explicit" begin
        Q=sparse([.8e308 .6e308;.6e308 .8e308])
        seed=first(filter(s->all(==(first(rand(MersenneTwister(s),(-1.,1.),2))),rand(MersenneTwister(s),(-1.,1.),2)),0:30))
        err=try
            matrix_free_reml_loglik(zeros(3),zeros(3,0),[(spzeros(3,2),Q)],[.5],1.;slq_probes=1,slq_steps=2,seed=seed)
            nothing
        catch e
            e
        end
        @test err isa ArgumentError
        @test occursin("SLQ",sprint(showerror,err))
    end
end
