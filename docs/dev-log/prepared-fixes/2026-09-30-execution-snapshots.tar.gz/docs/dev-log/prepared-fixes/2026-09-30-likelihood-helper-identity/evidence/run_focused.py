from pathlib import Path
import subprocess,os,time,json,sys
p=Path('.'); label=sys.argv[1]; tests=sys.argv[2:]
code='using LinearAlgebra; println("Julia=",VERSION," JuliaThreads=",Threads.nthreads()," BLASThreads=",BLAS.get_num_threads());'+''.join('include('+json.dumps(str((p/'test'/f).resolve()))+');' for f in tests)
cmd=['/Users/z3437171/.juliaup/bin/julia','--compiled-modules=no','--startup-file=no','--project=package','-e',code]
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',JULIA_NUM_THREADS='1',JULIA_DEPOT_PATH='/private/tmp/hsq-goal-julia-depot:/Users/z3437171/.julia');t=time.monotonic()
with (p/'evidence'/f'{label}.log').open('w') as out:
 proc=subprocess.Popen(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
 try:status=proc.wait(timeout=110)
 except subprocess.TimeoutExpired:proc.kill();proc.wait();raise
elapsed=time.monotonic()-t;(p/'evidence'/f'{label}-run.json').write_text(json.dumps({'command':cmd,'elapsed_seconds':elapsed,'exitcode':status,'threads':1,'timeout':110},indent=2)+'\n');print('exit',status,'elapsed',round(elapsed,2));print((p/'evidence'/f'{label}.log').read_text()[-2400:])
