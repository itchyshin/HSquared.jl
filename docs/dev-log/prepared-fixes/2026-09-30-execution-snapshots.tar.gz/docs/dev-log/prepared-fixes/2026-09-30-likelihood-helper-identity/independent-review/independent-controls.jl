using Test,HSquared,LinearAlgebra,SparseArrays
@testset "Independent legacy helper and computational buffer controls" begin
    y=Float32[1,2,4];X=ones(Float32,3,1);Z=sparse(Matrix{Float32}(I,3,3));Q=spdiagm(0=>Float32[1,2,4]);ids=[:z,:a,:m]
    original=animal_model_spec(y,X,Z,Q;ids=ids,relationship_diag=[1.,.5,.25])
    legacy,F=HSquared._validated_sparse_relationship_spec(original)
    @test legacy===original
    @test legacy.ids===original.ids
    @test legacy.relationship_diag===original.relationship_diag
    @test F\ones(3)≈[1.,.5,.25]
    computation,FC=HSquared._likelihood_validated_spec(original)
    @test computation!==original
    @test eltype(computation.y)==Float64
    @test eltype(computation.X)==Float64
    @test eltype(computation.Z)==Float64
    @test eltype(computation.Ainv)==Float64
    @test computation.X isa SparseMatrixCSC
    @test computation.Ainv==Float64.(Q)
    @test FC\ones(3)≈F\ones(3)
    @test sparse_reml_loglik(original,.8,1.2).loglik≈sparse_reml_loglik(computation,.8,1.2).loglik atol=1e-12
    q=[1. eps() 0.;0. 2. 0.;0. 0. 4.]
    changed=animal_model_spec(y,X,Z,sparse(q);ids=ids,relationship_diag=ones(3))
    canon,FQ=HSquared._validated_sparse_relationship_spec(changed)
    @test canon!==changed
    @test Matrix(canon.Ainv)==(q+q')/2
    @test canon.relationship_diag===nothing
    @test canon.ids==ids
    @test changed.relationship_diag==ones(3)
    @test Matrix(changed.Ainv)==q
    @test FQ\ones(3)≈canon.Ainv\ones(3)
    for bad in (animal_model_spec([Inf,2,4],X,Z,Q),animal_model_spec(y,ones(3,2),Z,Q),animal_model_spec(y,X,Z,spdiagm(0=>[1.,0.,4.])),animal_model_spec([big"1e10000",2,4],X,Z,Q))
        @test_throws ArgumentError HSquared._validated_sparse_relationship_spec(bad)
    end
end
