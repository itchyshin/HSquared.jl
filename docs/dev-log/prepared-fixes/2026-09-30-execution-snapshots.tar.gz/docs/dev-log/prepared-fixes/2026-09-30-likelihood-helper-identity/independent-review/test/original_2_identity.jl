using Test,HSquared,LinearAlgebra,SparseArrays,Random

function _mme_inverse_random_block_for_test(X, Z, Ainv, sigma_a2, sigma_e2)
    Xd = Matrix{Float64}(X)
    Zd = Matrix{Float64}(Z)
    Q = Matrix{Float64}(Ainv)
    n = size(Xd, 1)

    Rinv = Matrix{Float64}(I, n, n) / sigma_e2
    Ginv = Q / sigma_a2

    lhs = [
        transpose(Xd) * Rinv * Xd transpose(Xd) * Rinv * Zd
        transpose(Zd) * Rinv * Xd transpose(Zd) * Rinv * Zd + Ginv
    ]
    inverse_lhs = inv(Symmetric(lhs))
    p = size(Xd, 2)
    return inverse_lhs[(p + 1):end, (p + 1):end]
end

@testset "Phase 1 dense variance component fitting" begin
    ids = ["sire", "dam", "calf"]
    ped = normalize_pedigree(ids, ["0", "0", "sire"], ["0", "0", "dam"])
    Ainv = pedigree_inverse(ped)
    y = [1.0, 2.5, 4.0]
    X = ones(3, 1)
    Z = sparse(I, 3, 3)
    spec = animal_model_spec(y, X, Z, Ainv; ids = ped.ids, method = :ML)

    start = gaussian_loglik(spec, 1.0, 1.0; method = :ML)
    fit = fit_variance_components(spec; initial = (sigma_a2 = 0.5, sigma_e2 = 0.5), method = :ML)

    @test fit isa AnimalModelFit
    @test fit.spec === spec
    @test fit.likelihood.method == :ML
    @test fit.likelihood.loglik >= start.loglik
    @test fit.variance_components.sigma_a2 > 0
    @test fit.variance_components.sigma_e2 > 0
    @test fit.iterations > 0
    @test fit.optimizer_status in ("converged", "not_converged")

    fit2 = fit_animal_model(spec; initial = [1.0, 1.0], iterations = 100)
    @test fit2 isa AnimalModelFit

    reml_spec = animal_model_spec(y, X, Z, Ainv; ids = ped.ids, method = :REML)
    sparse_start = sparse_reml_loglik(reml_spec, 1.0, 1.0)
    sparse_fit = fit_sparse_reml(reml_spec; initial = (sigma_a2 = 0.8, sigma_e2 = 0.8), iterations = 100)
    @test sparse_fit isa AnimalModelFit
    @test sparse_fit.spec === reml_spec
    @test sparse_fit.target == :sparse_reml
    @test sparse_fit.likelihood.method == :REML
    @test sparse_fit.likelihood.loglik >= sparse_start.loglik
    @test sparse_fit.variance_components.sigma_a2 > 0
    @test sparse_fit.variance_components.sigma_e2 > 0
    @test sparse_fit.optimizer_status in ("converged", "not_converged")

    target_sparse = fit_animal_model(
        reml_spec;
        target = :sparse_reml,
        initial = [0.8, 0.8],
        iterations = 100,
    )
    @test target_sparse isa AnimalModelFit
    @test target_sparse.target == :sparse_reml
    @test target_sparse.likelihood.loglik ≈ sparse_fit.likelihood.loglik

    target_mme = fit_animal_model(
        spec;
        target = :henderson_mme,
        variance_components = (sigma_a2 = 1.0, sigma_e2 = 1.0),
    )
    direct_mme = henderson_mme(spec, 1.0, 1.0)
    @test target_mme isa HendersonMMEResult
    @test variance_components(target_mme) == (sigma_a2 = 1.0, sigma_e2 = 1.0)
    @test isapprox(fixed_effects(target_mme), fixed_effects(direct_mme))
    @test isapprox(breeding_values(target_mme).values, breeding_values(direct_mme).values)
    @test_throws ArgumentError fit_variance_components(spec; initial = (sigma_a2 = 1.0,))
    @test_throws ArgumentError fit_variance_components(spec; initial = [1.0])
    @test_throws ArgumentError fit_variance_components(spec; initial = (sigma_a2 = -1.0, sigma_e2 = 1.0))
    @test_throws ArgumentError fit_variance_components(spec; max_dense_cells = 17)
    @test_throws ArgumentError fit_sparse_reml(spec)
    @test_throws ArgumentError fit_sparse_reml(reml_spec; initial = (sigma_a2 = -1.0, sigma_e2 = 1.0))
    @test_throws ArgumentError fit_animal_model(spec; target = :sparse_reml)
    @test_throws ArgumentError fit_animal_model(
        reml_spec;
        target = :sparse_reml,
        variance_components = (sigma_a2 = 1.0, sigma_e2 = 1.0),
    )
    @test_throws ArgumentError fit_animal_model(spec; max_dense_cells = 17)
    @test_throws ArgumentError fit_animal_model(
        spec;
        target = :henderson_mme,
    )
    @test_throws ArgumentError fit_animal_model(
        spec;
        target = :henderson_mme,
        variance_components = (sigma_a2 = 1.0, sigma_e2 = 1.0),
        initial = (sigma_a2 = 1.0, sigma_e2 = 1.0),
    )
    @test_throws ArgumentError fit_animal_model(
        spec;
        target = :variance_components,
        variance_components = (sigma_a2 = 1.0, sigma_e2 = 1.0),
    )
    @test_throws ArgumentError fit_animal_model(spec; target = :unknown)
end

