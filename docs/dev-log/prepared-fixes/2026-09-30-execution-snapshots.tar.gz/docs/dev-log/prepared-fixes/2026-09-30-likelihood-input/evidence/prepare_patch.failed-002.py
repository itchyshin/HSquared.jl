from pathlib import Path
base=Path('evidence/likelihood.baseline.jl').read_text().splitlines(keepends=True)
edits={}
def edit(a,b,fn):
 text=''.join(base[a-1:b]);edits[(a,b)]=fn(text)
def replace(t,a,b,count=1):
 assert t.count(a)==count,(a,t.count(a),count)
 return t.replace(a,b)
def finite_end(t,marker,vars):return replace(t,marker,'    _likelihood_result_finite('+vars+')\n'+marker)
def controls(t):return replace(t,'    n = length(y)','    iterations >= 1 || throw(ArgumentError("iterations must be at least 1"))\n    n = length(y)')
def original_starts(t,fields):
 a='    all(s -> isfinite(s) && s > 0, ('+', '.join('initial.'+f for f in fields)+')) ||\n        throw(ArgumentError("initial variance components must be finite and positive"))'
 return replace(t,a,'    starts = [_likelihood_positive("initial '+f+'", initial.'+f+')\n              for f in ()]' if False else '    starts = ['+', '.join('_likelihood_positive("initial '+f+'", initial.'+f+')' for f in fields)+']')
helpers='''
# Likelihood ingress shares the sparse QR and precision contracts with the
# iterative engine. Validation happens once before optimization, including p=0.
function _likelihood_check_finite(name::AbstractString, value)
    finite = value isa Number ? isfinite(value) :
             all(isfinite, issparse(value) ? nonzeros(value) : value)
    finite || throw(ArgumentError("likelihood numerical range: $name must be finite"))
    return value
end

function _likelihood_positive(name::AbstractString, value::Real; precision::Bool = false)
    (isfinite(value) && value > 0) ||
        throw(ArgumentError("$name must be finite and positive"))
    return precision ? _finite_positive_variance_float64(name, value) :
                       _finite_positive_float64(name, value)
end

function _likelihood_design(y::AbstractVector, X::AbstractMatrix; method::Symbol = :REML)
    method in (:ML, :REML) || throw(ArgumentError("method must be :ML or :REML"))
    n = length(y)
    n > 0 || throw(ArgumentError("at least one response record is required"))
    size(X, 1) == n || throw(ArgumentError("X must have one row per response value"))
    yv = _likelihood_check_finite("converted y", Float64.(y))
    Xs = _likelihood_check_finite("converted X", sparse(Float64.(X)))
    method == :REML && size(Xs, 2) >= n &&
        throw(ArgumentError("REML requires fewer fixed-effect columns than observations"))
    _require_full_fixed_effect_rank(Xs)
    return yv, Xs
end

function _likelihood_random_inputs(Z::AbstractMatrix, Q::AbstractMatrix, n::Integer, i::Int)
    size(Z, 1) == n || throw(ArgumentError("Z[$i] must have one row per record"))
    size(Q, 1) == size(Q, 2) || throw(ArgumentError("Ainv[$i] must be square"))
    size(Z, 2) == size(Q, 1) || throw(ArgumentError("Z[$i] columns must match Ainv[$i] dimensions"))
    Zs = _likelihood_check_finite("converted Z[$i]", sparse(Float64.(Z)))
    Qs, factor = _validate_matrix_free_precision(sparse(Float64.(Q)), i)
    return Zs, Qs, factor
end

function _likelihood_effect_ids(ids, q::Integer, name::AbstractString)
    values = ids === nothing ? collect(1:q) : collect(ids)
    length(values) == q || throw(ArgumentError("$name length must match relationship dimensions"))
    length(unique(values)) == q || throw(ArgumentError("$name must contain unique IDs"))
    return values
end

function _likelihood_block_ids(ids, qs)
    ids === nothing || length(ids) == length(qs) ||
        throw(ArgumentError("ids must contain one ID vector per random effect"))
    return [_likelihood_effect_ids(ids === nothing ? nothing : ids[i], qs[i], "ids[$i]")
            for i in eachindex(qs)]
end

function _likelihood_validated_spec(spec::AnimalModelSpec; method = spec.method)
    spec.family isa GaussianFamily || throw(ArgumentError("family must be GaussianFamily()"))
    normalized_method = _coerce_method(method)
    yv, Xs = _likelihood_design(spec.y, spec.X; method = normalized_method)
    Zs, Q, factor = _likelihood_random_inputs(spec.Z, spec.Ainv, length(yv), 1)
    ids = _likelihood_effect_ids(spec.ids, size(Q, 1), "ids")
    rdiag = Q == sparse(Float64.(spec.Ainv)) ? spec.relationship_diag : nothing
    validated = animal_model_spec(yv, Xs, Zs, Q; ids = ids, family = spec.family,
                                  method = normalized_method, relationship_diag = rdiag)
    return validated, factor
end

function _likelihood_result_finite(loglik, beta, effects...)
    _likelihood_check_finite("log-likelihood", loglik)
    _likelihood_check_finite("fixed effects", beta)
    for effect in effects
        _likelihood_check_finite("random effects", effect)
    end
    return nothing
end

# Only expected numerical range/factorization failures become rejected proposals.
_likelihood_proposal_failure(err) = err isa PosDefException || err isa SingularException ||
    err isa LinearAlgebra.LAPACKException || err isa LinearAlgebra.ZeroPivotException ||
    (err isa ArgumentError && startswith(err.msg, "likelihood numerical range:"))
'''
# Dense public evaluator validates once; inner repeated objective keeps cached model.
def dense_public(t):
 t=replace(t,'    sigma_a2 > 0 ||\n        throw(ArgumentError("sigma_a2 must be positive"))\n    sigma_e2 > 0 ||\n        throw(ArgumentError("sigma_e2 must be positive"))','    sigma_a2 = _likelihood_positive("sigma_a2", sigma_a2)\n    sigma_e2 = _likelihood_positive("sigma_e2", sigma_e2)')
 return replace(t,'    _check_dense_validation_size(spec, max_dense_cells)','    spec, _ = _likelihood_validated_spec(spec; method = normalized_method)\n    _check_dense_validation_size(spec, max_dense_cells)')
edit(106,125,dense_public)
def dense_precision(t):
 return '''function _dense_relationship_covariance(Ainv_input::AbstractMatrix)
    canonical, _ = _validate_matrix_free_precision(sparse(Float64.(Ainv_input)), 1)
    A = inv(Symmetric(Matrix{Float64}(canonical)))
    return _likelihood_check_finite("relationship covariance", A)
end
'''
edit(127,138,dense_precision)
def dense_inner(t):
 t=replace(t,'    sigma_a2 > 0 || throw(ArgumentError("sigma_a2 must be positive"))\n    sigma_e2 > 0 || throw(ArgumentError("sigma_e2 must be positive"))','    sigma_a2 = _likelihood_positive("sigma_a2", sigma_a2)\n    sigma_e2 = _likelihood_positive("sigma_e2", sigma_e2)')
 t=replace(t,'    cholV = cholesky(V; check = true)','    _likelihood_check_finite("marginal covariance", V)\n    cholV = cholesky(V; check = true)')
 return finite_end(t,'    return GaussianLikelihoodResult(','loglik, beta')
edit(140,188,dense_inner)
edit(214,226,lambda t:'''function _validated_sparse_relationship_spec(spec::AnimalModelSpec)
    return _likelihood_validated_spec(spec)
end
''')
edit(228,269,lambda t:finite_end(t,'    return GaussianLikelihoodResult(','loglik, beta, u'))
def dense_fit(t):
 t=replace(t,'    sigma_a2_start > 0 ||\n        throw(ArgumentError("initial sigma_a2 must be positive"))\n    sigma_e2_start > 0 ||\n        throw(ArgumentError("initial sigma_e2 must be positive"))','    iterations >= 1 || throw(ArgumentError("iterations must be at least 1"))')
 t=replace(t,'    _check_dense_validation_size(spec, max_dense_cells)','    spec, _ = _likelihood_validated_spec(spec; method = normalized_method)\n    _check_dense_validation_size(spec, max_dense_cells)')
 old='''    objective(logtheta) = -_gaussian_loglik_with_covariance(
        spec,
        exp(logtheta[1]),
        exp(logtheta[2]),
        A,
        normalized_method,
    ).loglik'''
 new='''    function objective(logtheta)
        variances = _try_positive_exp(logtheta)
        variances === nothing && return Inf
        try
            value = -_gaussian_loglik_with_covariance(spec, variances..., A, normalized_method).loglik
            return isfinite(value) ? value : Inf
        catch err
            _likelihood_proposal_failure(err) || rethrow()
            return Inf
        end
    end'''
 t=replace(t,old,new)
 return replace(t,'    sigma_a2, sigma_e2 = exp.(Optim.minimizer(result))','    isfinite(Optim.minimum(result)) || throw(ArgumentError("dense optimizer did not find a finite objective"))\n    variances = _try_positive_exp(Optim.minimizer(result))\n    variances === nothing && throw(ArgumentError("dense optimizer did not return finite positive variances"))\n    sigma_a2, sigma_e2 = variances')
edit(287,339,dense_fit)
def sparse_fit(t):
 t=replace(t,'        (isfinite(sigma_a2) && sigma_a2 > 0 && isfinite(sigma_e2) && sigma_e2 > 0) ||','        _finite_positive_variance_update((sigma_a2,), sigma_e2) ||')
 t=replace(t,'            return -_sparse_reml_loglik(','            value = -_sparse_reml_loglik(')
 t=replace(t,'            ).loglik\n        catch err','            ).loglik\n            return isfinite(value) ? value : Inf\n        catch err')
 t=replace(t,'            err isa PosDefException && return Inf','            _likelihood_proposal_failure(err) && return Inf')
 return replace(t,'    sigma_a2, sigma_e2 = exp.(Optim.minimizer(result))','    isfinite(Optim.minimum(result)) || throw(ArgumentError("sparse optimizer did not find a finite objective"))\n    variances = _try_positive_exp(Optim.minimizer(result))\n    variances === nothing && throw(ArgumentError("sparse optimizer did not return finite positive variances"))\n    sigma_a2, sigma_e2 = variances\n    _finite_positive_variance_update((sigma_a2,), sigma_e2) ||\n        throw(ArgumentError("sparse optimizer returned variances outside the finite precision range"))')
edit(353,412,sparse_fit)
def scalar_ai(t):
 return replace(t,'        if !(a_new > 0 && e_new > 0)','        if !_finite_positive_variance_update((a_new,), e_new)')
edit(470,665,scalar_ai)
def supplied_single(t):
 t=replace(t,'    sigma_a2 > 0 ||\n        throw(ArgumentError("sigma_a2 must be positive"))\n    sigma_e2 > 0 ||\n        throw(ArgumentError("sigma_e2 must be positive"))','    sigma_a2 = _likelihood_positive("sigma_a2", sigma_a2; precision = true)\n    sigma_e2 = _likelihood_positive("sigma_e2", sigma_e2; precision = true)\n    spec, _ = _validated_sparse_relationship_spec(spec)')
 return replace(t,'    solution = lhs \\ rhs','    solution = lhs \\ rhs\n    _likelihood_check_finite("MME solution", solution)')
edit(1174,1197,supplied_single)
def two_mme(t):
 for f in ('sigma1','sigma2','sigma_e2'):
  t=replace(t,'    '+f+' > 0 || throw(ArgumentError("'+f+' must be positive"))','    '+f+' = _likelihood_positive("'+f+'", '+f+'; precision = true)')
 t=replace(t,'    yv = Float64.(y)\n    Xs = sparse(Float64.(X))\n    Z1s = sparse(Float64.(Z1))\n    Z2s = sparse(Float64.(Z2))\n    A1 = sparse(Float64.(Ainv1))\n    A2 = sparse(Float64.(Ainv2))','    yv, Xs = _likelihood_design(y, X; method = :ML)\n    Z1s, A1, _ = _likelihood_random_inputs(Z1, Ainv1, n, 1)\n    Z2s, A2, _ = _likelihood_random_inputs(Z2, Ainv2, n, 2)\n    e1ids = _likelihood_effect_ids(e1ids, n1, "ids1")\n    e2ids = _likelihood_effect_ids(e2ids, n2, "ids2")')
 return replace(t,'    solution = lhs \\ rhs','    _likelihood_check_finite("MME coefficient matrix", lhs)\n    _likelihood_check_finite("MME right-hand side", rhs)\n    solution = lhs \\ rhs\n    _likelihood_check_finite("MME solution", solution)')
edit(1246,1308,two_mme)
# Three repeated dense GLS kernels get finite output guards and V checks.
for a,b,marker,args in [(1442,1459,'    return loglik, beta, u1, u2','loglik, beta, u1, u2'),(1817,1835,'    return loglik, Vector{Float64}(beta), us','loglik, beta, us...'),(3000,3015,'    return loglik, Vector{Float64}(beta), Vector{Float64}(u[1:q]), Vector{Float64}(u[(q + 1):(2q)])','loglik, beta, u')]:
 def dense_kernel(t,marker=marker,args=args):
  t=replace(t,'    Vf = cholesky(V)','    _likelihood_check_finite("marginal covariance", V)\n    Vf = cholesky(V)')
  return finite_end(t,marker,args)
 edit(a,b,dense_kernel)
def two_fit(t):
 t=controls(original_starts(t,['sigma1','sigma2','sigma_e2']))
 t=replace(t,'    A1 = inv(Symmetric(Matrix{Float64}(Ainv1)))\n    A2 = inv(Symmetric(Matrix{Float64}(Ainv2)))\n    Xd = Matrix{Float64}(X)\n    Z1d = Matrix{Float64}(Z1)\n    Z2d = Matrix{Float64}(Z2)\n    yv = Float64.(y)','    yv, Xs = _likelihood_design(y, X)\n    Z1s, Q1, _ = _likelihood_random_inputs(Z1, Ainv1, n, 1)\n    Z2s, Q2, _ = _likelihood_random_inputs(Z2, Ainv2, n, 2)\n    A1 = _dense_relationship_covariance(Q1)\n    A2 = _dense_relationship_covariance(Q2)\n    Xd = Matrix{Float64}(Xs)\n    Z1d = Matrix{Float64}(Z1s)\n    Z2d = Matrix{Float64}(Z2s)\n    e1ids = _likelihood_effect_ids(e1ids, n1, "ids1")\n    e2ids = _likelihood_effect_ids(e2ids, n2, "ids2")')
 t=replace(t,'            err isa PosDefException && return Inf','            _likelihood_proposal_failure(err) && return Inf')
 return replace(t,'    p0 = log.([Float64(initial.sigma1), Float64(initial.sigma2), Float64(initial.sigma_e2)])','    p0 = log.(starts)')
edit(1481,1547,two_fit)
def multi_mme(t):
 t=replace(t,'    all(s -> s > 0, sigmas) || throw(ArgumentError("all sigmas must be positive"))\n    sigma_e2 > 0 || throw(ArgumentError("sigma_e2 must be positive"))','    sigmas = [_likelihood_positive("sigma[$i]", s; precision = true) for (i, s) in enumerate(sigmas)]\n    sigma_e2 = _likelihood_positive("sigma_e2", sigma_e2; precision = true)')
 t=replace(t,'        push!(Zs, sparse(Float64.(Zi)))\n        push!(Ainvs, sparse(Float64.(Ainvi)))','        Zif, Qif, _ = _likelihood_random_inputs(Zi, Ainvi, n, i)\n        push!(Zs, Zif)\n        push!(Ainvs, Qif)')
 t=replace(t,'    yv = Float64.(y)\n    Xs = sparse(Float64.(X))','    yv, Xs = _likelihood_design(y, X; method = :ML)\n    eids = _likelihood_block_ids(eids, qs)')
 return replace(t,'    solution = lhs \\ rhs','    _likelihood_check_finite("MME coefficient matrix", lhs)\n    _likelihood_check_finite("MME right-hand side", rhs)\n    solution = lhs \\ rhs\n    _likelihood_check_finite("MME solution", solution)')
edit(1746,1810,multi_mme)
def multi_fit(t):
 t=controls(t)
 t=replace(t,'        push!(As, inv(Symmetric(Matrix{Float64}(Ainvi))))\n        push!(Zds, Matrix{Float64}(Zi))','        Zif, Qif, _ = _likelihood_random_inputs(Zi, Ainvi, n, i)\n        push!(As, _dense_relationship_covariance(Qif))\n        push!(Zds, Matrix{Float64}(Zif))')
 t=replace(t,'    if initial === nothing','    eids = _likelihood_block_ids(ids, qs)\n    if initial === nothing')
 t=replace(t,'        p0 = log.(Float64.(collect(initial)))','        p0 = log.([_likelihood_positive("initial variance component $i", s) for (i, s) in enumerate(initial)])')
 t=replace(t,'    yv = Float64.(y)\n    Xd = Matrix{Float64}(X)','    yv, Xs = _likelihood_design(y, X)\n    Xd = Matrix{Float64}(Xs)')
 t=replace(t,'            (err isa PosDefException || err isa SingularException) && return Inf','            _likelihood_proposal_failure(err) && return Inf')
 return replace(t,'    eids = ids === nothing ? [collect(1:qs[i]) for i in 1:K] : [collect(ids[i]) for i in 1:K]\n','')
edit(1869,1943,multi_fit)
def workspace(t):
 t=replace(t,'    yv = Float64.(y)\n    all(isfinite, yv) || throw(ArgumentError("y must be finite after conversion to Float64"))\n    Xs = sparse(Float64.(X))\n    all(isfinite, nonzeros(Xs)) ||\n        throw(ArgumentError("X must be finite after conversion to Float64"))','    yv, Xs = _likelihood_design(y, X)')
 return t
edit(2502,2584,workspace)
def multi_ll(t):
 t=replace(t,'    all(s -> s > 0, sigmas) || throw(ArgumentError("all sigmas must be positive"))\n    sigma_e2 > 0 || throw(ArgumentError("sigma_e2 must be positive"))\n    ss = Float64.(collect(sigmas))\n    se2 = Float64(sigma_e2)','    ss = [_likelihood_positive("sigma[$i]", s; precision = true) for (i, s) in enumerate(sigmas)]\n    se2 = _likelihood_positive("sigma_e2", sigma_e2; precision = true)')
 t=replace(t,'    factor = _factorize!(ws)','    _likelihood_check_finite("MME coefficient matrix", lhs)\n    _likelihood_check_finite("MME right-hand side", rhs)\n    factor = _factorize!(ws)')
 return finite_end(t,'    return loglik, beta, us','loglik, beta, us...')
edit(2592,2630,multi_ll)
def multi_ai(t):
 t=replace(t,'    if initial === nothing','    eids = _likelihood_block_ids(eids, qs)\n    if initial === nothing')
 return t
edit(2763,2958,multi_ai)
def direct_fit(t):
 t=controls(t)
 t=replace(t,'    A = inv(Symmetric(Matrix{Float64}(Ainv)))\n    Xd = Matrix{Float64}(X)\n    Zdd = Matrix{Float64}(Zd)\n    Zmd = Matrix{Float64}(Zm)\n    yv = Float64.(y)','    yv, Xs = _likelihood_design(y, X)\n    Zds, Q, _ = _likelihood_random_inputs(Zd, Ainv, n, 1)\n    Zms, _, _ = _likelihood_random_inputs(Zm, Q, n, 2)\n    aids = _likelihood_effect_ids(ids, q, "ids")\n    A = _dense_relationship_covariance(Q)\n    Xd = Matrix{Float64}(Xs)\n    Zdd = Matrix{Float64}(Zds)\n    Zmd = Matrix{Float64}(Zms)')
 t=replace(t,'        isposdef(Symmetric(G0)) || throw(ArgumentError("initial.G_dm must be positive definite"))','        Gcanonical, _ = _validate_matrix_free_precision(sparse(G0), 1)\n        G0 = Matrix(Gcanonical)')
 t=replace(t,'        s = Float64(initial.sigma_e2)\n        isfinite(s) && s > 0 || throw(ArgumentError("initial.sigma_e2 must be finite and positive"))','        s = _likelihood_positive("initial.sigma_e2", initial.sigma_e2)')
 t=replace(t,'    function negloglik(p)','    se0 = _likelihood_positive("initial residual variance", se0)\n    _likelihood_check_finite("initial genetic covariance", G0)\n    function negloglik(p)')
 t=replace(t,'            (err isa PosDefException || err isa SingularException) && return Inf','            _likelihood_proposal_failure(err) && return Inf')
 return replace(t,'    aids = ids === nothing ? collect(1:q) : collect(ids)\n    length(aids) == q || throw(ArgumentError("ids length must match Ainv dimensions"))\n','')
edit(3051,3136,direct_fit)
def repeat_fit(t):
 t=controls(original_starts(t,['sigma_a2','sigma_pe2','sigma_e2']))
 t=replace(t,'    A = inv(Symmetric(Matrix{Float64}(Ainv)))\n    Xd = Matrix{Float64}(X)\n    Zd = Matrix{Float64}(Z)\n    yv = Float64.(y)','    yv, Xs = _likelihood_design(y, X)\n    Zs, Q, _ = _likelihood_random_inputs(Z, Ainv, n, 1)\n    encoded_ids = _likelihood_effect_ids(encoded_ids, na, "ids")\n    A = _dense_relationship_covariance(Q)\n    Xd = Matrix{Float64}(Xs)\n    Zd = Matrix{Float64}(Zs)')
 t=replace(t,'            err isa PosDefException && return Inf','            _likelihood_proposal_failure(err) && return Inf')
 return replace(t,'    p0 = log.([Float64(initial.sigma_a2), Float64(initial.sigma_pe2), Float64(initial.sigma_e2)])','    p0 = log.(starts)')
edit(3309,3368,repeat_fit)
# Coercers preserve their shape error contracts and validate before Float64 conversion.
def coercers(t,root,label,precision=False):
 import re
 pat=rf'Float64\({root}\.([a-z_0-9]+)\)|Float64\({root}\[([12])\]\)'
 def repl(m):
  expr=f'{root}.{m.group(1)}' if m.group(1) else f'{root}[{m.group(2)}]'
  return f'_likelihood_positive("{label}", {expr}'+('; precision = true)' if precision else ')')
 return re.sub(pat,repl,t)
edit(4185,4203,lambda t:coercers(t,'initial','initial variance'))
edit(4229,4247,lambda t:coercers(t,'variance_components','supplied variance',True))
for a,b in [(4258,4279),(4327,4341)]:
 edit(a,b,lambda t:replace(t,'    return lhs, rhs, residual_precision * ','    _likelihood_check_finite("MME coefficient matrix", lhs)\n    _likelihood_check_finite("MME right-hand side", rhs)\n    return lhs, rhs, residual_precision * '))
# Document optimizer status honestly; closed boundaries remain unavailable here.
base[346-1:346-1]=[] # do not shift baseline coordinates
text=''.join(base)
for (a,b),new in sorted(edits.items(),reverse=True):
 text=text[:sum(map(len,base[:a-1]))]+new+text[sum(map(len,base[:b])):]
text=text.replace('const DEFAULT_MAX_DENSE_CELLS = 1_000_000\n','const DEFAULT_MAX_DENSE_CELLS = 1_000_000\n'+helpers,1)
needle='path toward sparse fitting. It is REML-only, not AI-REML, not the default\nfitting path, and not a production sparse solver.'
assert needle in text
text=text.replace(needle,needle+'\n\n`converged` is the optimizer stopping flag for a finite returned result. It does\nnot certify score stationarity or a closed-boundary optimum. Exact zero\ncomponents are unavailable in this positive log-variance parameterization;\nnonfinite proposals are rejected and nonfinite final results raise an error.',1)
Path('src/likelihood.jl').write_text(text)
print('prepared',len(edits),'bounded source spans')
