using Test, HSquared, LinearAlgebra, SparseArrays
println("THREADS ",Threads.nthreads()," BLAS ",BLAS.get_num_threads())
@testset "Independent likelihood ingress challenges" begin
    n=3; y=[1.5,-.7,2.2]; I3=Matrix{Float64}(I,n,n); Z=sparse(I3); Q=spdiagm(0=>[2.,3.,5.]); ids=["zebra","apple","middle"]
    @testset "analytic supplied equation and label order" begin
        for X in (zeros(n,0),ones(n,1),I3)
            p=size(X,2); s=.8; e=1.3
            C=[X'X/e X'Z/e; Z'X/e Matrix(Z'Z/e+Q/s)]
            ref=C\vcat(X'y/e,Z'y/e)
            spec=animal_model_spec(y,X,Z,Q;ids=ids)
            h=henderson_mme(spec,s,e)
            k=multi_effect_mme(y,X,[(Z,Q)],[s],e;ids=[ids])
            @test h.beta ≈ ref[1:p] atol=1e-12
            @test h.animal_effects.values ≈ ref[p+1:end] atol=1e-12
            @test h.animal_effects.ids==ids
            @test k.effects[1].ids==ids
            @test k.beta≈h.beta atol=1e-12
            @test k.effects[1].values≈h.animal_effects.values atol=1e-12
            t=two_effect_mme(y,X,Z,Q,Z,Q,s,.4,e;ids1=ids,ids2=reverse(ids))
            C2=[X'X/e X'Z/e X'Z/e;Z'X/e Matrix(Z'Z/e+Q/s) Matrix(Z'Z/e);Z'X/e Matrix(Z'Z/e) Matrix(Z'Z/e+Q/.4)]
            r2=C2\vcat(X'y/e,Z'y/e,Z'y/e)
            @test t.beta≈r2[1:p] atol=1e-12
            @test t.effect1.ids==ids
            @test t.effect2.ids==reverse(ids)
            @test t.effect1.values≈r2[p+1:p+n] atol=1e-12
            @test t.effect2.values≈r2[p+n+1:end] atol=1e-12
        end
    end
    @testset "dense smallest-positive covariance domain" begin
        tiny=nextfloat(0.)
        for X in (zeros(n,0),ones(n,1))
            spec=animal_model_spec(y,X,Z,sparse(I3))
            for (a,e) in ((tiny,1.),(1.,tiny))
                d=gaussian_loglik(spec,a,e)
                b=size(X,2)==0 ? Float64[] : [sum(y)/n]
                resid=y-X*b
                oracle=-.5*((n-size(X,2))*log(2pi)+sum(abs2,resid)+(size(X,2)==0 ? 0. : log(n)))
                @test d.loglik≈oracle atol=1e-12
                @test d.beta≈b atol=1e-12
                @test_throws ArgumentError sparse_reml_loglik(spec,a,e)
            end
        end
        zspec=animal_model_spec(zeros(n),zeros(n,0),Z,sparse(I3))
        ll=gaussian_loglik(zspec,tiny,tiny)
        @test ll.loglik≈-.5*n*(log(2pi)+log(2*tiny)) atol=1e-10
        @test isfinite(ll.loglik)
    end
    @testset "converted arrays finite on every ingress" begin
        X=ones(n,1); big=BigFloat("1e10000")
        function routes(yy,xx,zz,qq)
            sp=animal_model_spec(yy,xx,zz,qq)
            [()->gaussian_loglik(sp,1.,1.),()->sparse_reml_loglik(sp,1.,1.),()->henderson_mme(sp,1.,1.),
             ()->multi_effect_mme(yy,xx,[(zz,qq)],[1.],1.),()->two_effect_mme(yy,xx,zz,qq,Z,Q,1.,1.,1.),
             ()->fit_direct_maternal_reml(yy,xx,zz,zz,qq;iterations=1),()->fit_repeatability_reml(yy,xx,zz,qq;iterations=1)]
        end
        for input in (([NaN,0.,0.],X,Z,Q),(y,reshape([big,1,1],3,1),Z,Q),(y,X,Diagonal([big,1,1]),Q),(y,X,Z,Diagonal([big,1,1])),(y,X,Z,Diagonal([NaN,1,1])),(y,X,Z,Diagonal([0.,1,1])))
            for f in routes(input...); @test_throws ArgumentError f(); end
        end
    end
    @testset "roundoff canonicalization consistently propagated" begin
        Qnear=[2. 0.1 0.;0.1+eps() 3. 0.;0. 0. 5.]
        canon=(Qnear+Qnear')/2
        sp=animal_model_spec(y,ones(n,1),Z,sparse(Qnear);ids=ids)
        h=henderson_mme(sp,.8,1.3)
        hc=henderson_mme(animal_model_spec(y,ones(n,1),Z,sparse(canon);ids=ids),.8,1.3)
        @test Matrix(h.spec.Ainv)==canon
        @test h.animal_effects.ids==ids
        @test h.animal_effects.values≈hc.animal_effects.values atol=1e-13
        @test gaussian_loglik(sp,.8,1.3).loglik≈sparse_reml_loglik(sp,.8,1.3).loglik atol=1e-12
    end
    @testset "finite arithmetic failures have explicit range errors" begin
        sp=animal_model_spec([1e308,-1e308,0.],zeros(n,0),Z,Q)
        for f in (() -> gaussian_loglik(sp,1.,1.),()->sparse_reml_loglik(sp,1.,1.))
            err=try f(); nothing catch e; e end
            @test err isa ArgumentError
            @test occursin("likelihood numerical range:",sprint(showerror,err))
        end
    end
end
