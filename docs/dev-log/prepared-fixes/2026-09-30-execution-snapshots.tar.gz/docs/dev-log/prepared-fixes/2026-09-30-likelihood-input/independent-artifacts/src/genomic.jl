function _symmetrize_roundoff!(G::Matrix{Float64})
    all(isfinite, G) ||
        throw(ArgumentError("constructed genomic relationship or precision must be finite"))
    n = size(G, 1)
    @inbounds for j in 2:n, i in 1:(j - 1)
        midpoint = G[i, j] / 2 + G[j, i] / 2
        G[i, j] = midpoint
        G[j, i] = midpoint
    end
    return G
end

"""
    centered_markers(markers; allele_frequencies = nothing)

Center a biallelic marker matrix for SNP-BLUP / RR-BLUP, using the same
allele-frequency centering and VanRaden scaling as
[`genomic_relationship_matrix`](@ref).

Returns a `NamedTuple` `(W, p, k)`: `W = markers − 2p` is the centered marker
matrix (each column sums to zero), `p` are the per-marker allele frequencies
(estimated from the columns unless supplied), and `k = 2 Σ_j p_j(1 − p_j)` is the
VanRaden scale, so that `genomic_relationship_matrix(markers) == W * Wᵀ / k`.
Computing `W`, `p`, and `k` together guarantees they share one `p`, which the
GBLUP↔SNP-BLUP equivalence requires.
"""
function centered_markers(
    markers::AbstractMatrix;
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
)
    M = Float64.(markers)
    n, m = size(M)
    (n >= 1 && m >= 1) || throw(ArgumentError("markers must be non-empty"))
    all(g -> 0 <= g <= 2, M) ||
        throw(ArgumentError("marker genotypes must be counts or dosages in [0, 2]"))

    p = if allele_frequencies === nothing
        vec(sum(M, dims = 1)) ./ (2 * n)
    else
        length(allele_frequencies) == m ||
            throw(ArgumentError("allele_frequencies must have one entry per marker"))
        Float64.(allele_frequencies)
    end
    all(f -> 0 <= f <= 1, p) ||
        throw(ArgumentError("allele frequencies must lie in [0, 1]"))

    k = 2 * sum(p .* (1 .- p))
    k > 0 ||
        throw(ArgumentError("genomic scaling is zero; all markers are monomorphic"))

    W = M .- 2 .* transpose(p)
    return (W = W, p = p, k = k)
end

"""
    genomic_relationship_matrix(markers; allele_frequencies = nothing, method = :vanraden1,
                                weights = nothing, backend = :cpu)

VanRaden (2008) genomic relationship matrix `G` from a biallelic marker genotype
matrix `markers` (rows = individuals, columns = markers; entries are the count of
one allele, `0`/`1`/`2`, or an imputed dosage in `[0, 2]`).

Allele frequencies are estimated from the columns (`p_j = mean(markers[:, j]) / 2`)
unless supplied via `allele_frequencies`. Two standard constructions:

- `method = :vanraden1` (default) — centered markers, single overall scale:
  `G = Z Zᵀ / (2 Σ_j p_j(1 − p_j))`, `Z = markers − 2p`.
- `method = :vanraden2` — per-marker standardized, equal marker weight:
  `G = Zₛ Zₛᵀ / m`, `Zₛ[:, j] = (markers[:, j] − 2p_j) / √(2 p_j(1 − p_j))`, `m`
  markers. Requires every marker polymorphic (`0 < p_j < 1`).

Optional per-marker `weights` (for weighted GBLUP / GWAS-informed prediction,
`method = :vanraden1` only) give `G = Z·diag(w)·Zᵀ / Σ_j w_j·2 p_j(1 − p_j)`,
which reduces exactly to the unweighted method-1 `G` when the weights are equal.

`backend = :cpu` (default) computes on the CPU as described. `backend = :cuda`
(v0.7-G-D, opt-in) routes to the GPU twin [`gpu_genomic_relationship_matrix`](@ref)
(the `HSquaredCUDAExt` extension) — the SAME estimand (it reuses the validated
`centered_markers` verbatim) accelerated on-device; without a CUDA backend in scope
it throws a `MethodError` asking you to load CUDA. The `:cpu` result is unchanged by
the addition of this keyword.

CPU cross-products are symmetrized at floating-point precision before return,
so the constructed relationship is exactly symmetric for downstream validation.
This leaves the covariance estimand unchanged.

This is the Phase 2 genomic-relationship construction utility — it builds `G`
only. Its regularized inverse is [`genomic_relationship_inverse`](@ref), and the
experimental supplied-variance GBLUP / SNP-BLUP fitting that consume `G` / `Ginv`
are [`fit_gblup`](@ref) / [`fit_snp_blup`](@ref). `G` is typically rank-deficient
when there are fewer markers than individuals and needs regularization before
inversion.
"""
function genomic_relationship_matrix(
    markers::AbstractMatrix;
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    method::Symbol = :vanraden1,
    weights::Union{Nothing,AbstractVector} = nothing,
    backend::Symbol = :cpu,
)
    if backend === :cuda
        # v0.7-G-D: opt-in device dispatch. Routes to the GPU twin (HSquaredCUDAExt), which
        # throws a `MethodError` asking you to load CUDA when no CUDA backend is in scope. Same
        # estimand (the GPU twin reuses `centered_markers` verbatim); the default `:cpu` path below
        # is byte-identical to before this kwarg existed.
        return gpu_genomic_relationship_matrix(markers; allele_frequencies = allele_frequencies,
                                               method = method, weights = weights)
    end
    backend === :cpu || throw(ArgumentError("backend must be :cpu (default) or :cuda"))
    cm = centered_markers(markers; allele_frequencies = allele_frequencies)
    if weights !== nothing
        method === :vanraden1 ||
            throw(ArgumentError("per-marker weights are supported with method = :vanraden1 only"))
        length(weights) == size(cm.W, 2) ||
            throw(ArgumentError("weights must have one entry per marker"))
        w = Float64.(weights)
        all(isfinite, w) || throw(ArgumentError("weights must be finite"))
        all(>=(0), w) || throw(ArgumentError("weights must be non-negative"))
        scale = sum(w .* 2 .* cm.p .* (1 .- cm.p))
        isfinite(scale) && scale > 0 ||
            throw(ArgumentError("weighted genomic scaling must be finite and positive"))
        G = (cm.W * Diagonal(w) * transpose(cm.W)) ./ scale
        return _symmetrize_roundoff!(G)
    end
    if method === :vanraden1
        G = (cm.W * transpose(cm.W)) ./ cm.k
        return _symmetrize_roundoff!(G)
    elseif method === :vanraden2
        scale = 2 .* cm.p .* (1 .- cm.p)
        all(>(0), scale) ||
            throw(ArgumentError("method = :vanraden2 requires every marker polymorphic (0 < p < 1); a monomorphic marker cannot be standardized"))
        Zs = cm.W ./ transpose(sqrt.(scale))
        G = (Zs * transpose(Zs)) ./ size(cm.W, 2)
        return _symmetrize_roundoff!(G)
    else
        throw(ArgumentError("method must be :vanraden1 or :vanraden2"))
    end
end

"""
    genomic_relationship_inverse(G; ridge = 0.01, backend = :cpu)

Regularized inverse of a genomic relationship matrix `G` (e.g. from
[`genomic_relationship_matrix`](@ref)) — the genomic relationship inverse `Ginv`
consumed by the experimental supplied-variance [`fit_gblup`](@ref). A genomic `G`
built from markers is usually rank-deficient (markers < individuals), so a ridge
is added to the diagonal before inversion: `inv(G + ridge·I)`.

This is a simple ridge regularization. Blending `G` with a pedigree `A`
(single-step / `H`-matrix) exists as an internal validation utility and is not
yet part of the public surface.

`backend = :cpu` (default) is unchanged; `backend = :cuda` (v0.7-G-D, opt-in)
routes to the GPU twin [`gpu_genomic_relationship_inverse`](@ref) (MethodError
without CUDA in scope).
"""
function genomic_relationship_inverse(G::AbstractMatrix; ridge::Real = 0.01, backend::Symbol = :cpu)
    if backend === :cuda
        # v0.7-G-D: opt-in device dispatch (routes to the GPU twin; MethodError without CUDA).
        # The default `:cpu` path below is byte-identical to before this kwarg existed.
        return gpu_genomic_relationship_inverse(G; ridge = ridge)
    end
    backend === :cpu || throw(ArgumentError("backend must be :cpu (default) or :cuda"))
    n = size(G, 1)
    size(G, 2) == n || throw(ArgumentError("G must be square"))
    ridge >= 0 || throw(ArgumentError("ridge must be non-negative"))
    issymmetric(G) || throw(ArgumentError("G must be symmetric"))
    regularized = Symmetric(Matrix{Float64}(G) + ridge * I)
    isposdef(regularized) ||
        throw(ArgumentError("regularized G is not positive definite; increase ridge"))
    return inv(regularized)
end

# Canonical provenance encoding for the v0.7 genomic activation contract. These helpers are
# intentionally internal: R receives the fingerprints and semantic metadata, but the byte format
# remains owned by the Julia engine. Integers and Float64 bit patterns are written little-endian so
# the digest is independent of host byte order.
const _GENOMIC_PROVENANCE_DOMAIN = "HSquared-provenance-v1\0"

function _provenance_write_u64(io::IO, value::Integer)
    value >= 0 || throw(ArgumentError("canonical provenance integers must be non-negative"))
    write(io, htol(UInt64(value)))
    return io
end


function _provenance_write_string(io::IO, value::AbstractString)
    bytes = codeunits(String(value))
    _provenance_write_u64(io, length(bytes))
    write(io, bytes)
    return io
end


function _provenance_write_strings(io::IO, values::AbstractVector{<:AbstractString})
    _provenance_write_u64(io, length(values))
    for value in values
        _provenance_write_string(io, value)
    end
    return io
end


function _provenance_write_float64(io::IO, value::Real)
    x = Float64(value)
    isfinite(x) || throw(ArgumentError("canonical provenance values must be finite"))
    x == 0.0 && (x = 0.0) # canonicalize -0.0 to +0.0
    _provenance_write_u64(io, reinterpret(UInt64, x))
    return io
end


function _provenance_buffer(kind::AbstractString)
    io = IOBuffer()
    write(io, codeunits(_GENOMIC_PROVENANCE_DOMAIN))
    write(io, codeunits(String(kind)))
    write(io, UInt8(0))
    return io
end


_provenance_digest(io::IOBuffer) = bytes2hex(SHA.sha256(take!(io)))


function _canonical_genomic_ids(ids, n::Integer)
    length(ids) == n || throw(ArgumentError("ids must have one entry per genomic row"))
    all(x -> x !== missing && x !== nothing, ids) ||
        throw(ArgumentError("genomic ids must be non-missing"))
    values = string.(collect(ids))
    all(!isempty, values) || throw(ArgumentError("genomic ids must be non-empty"))
    length(unique(values)) == length(values) || throw(ArgumentError("genomic ids must be unique"))
    return values
end


function _genomic_id_order_fingerprint(ids::AbstractVector{<:AbstractString})
    io = _provenance_buffer("id_order")
    _provenance_write_strings(io, ids)
    return _provenance_digest(io)
end


function _genomic_marker_fingerprint(markers::AbstractMatrix, ids::AbstractVector{<:AbstractString},
                                     marker_names)
    n, m = size(markers)
    io = _provenance_buffer("markers")
    _provenance_write_u64(io, n)
    _provenance_write_u64(io, m)
    _provenance_write_strings(io, ids)
    if marker_names === nothing
        write(io, UInt8(0))
        _provenance_write_u64(io, m)
        for j in 1:m
            _provenance_write_u64(io, j)
        end
    else
        all(x -> x !== missing && x !== nothing, marker_names) ||
            throw(ArgumentError("marker_names must be non-missing"))
        names = string.(collect(marker_names))
        length(names) == m || throw(ArgumentError("marker_names must have one entry per marker"))
        all(!isempty, names) || throw(ArgumentError("marker_names must be non-empty"))
        length(unique(names)) == m || throw(ArgumentError("marker_names must be unique"))
        write(io, UInt8(1))
        _provenance_write_strings(io, names)
    end
    for value in markers # Julia arrays iterate in column-major semantic order
        _provenance_write_float64(io, value)
    end
    return _provenance_digest(io)
end


function _genomic_matrix_fingerprint(kind::AbstractString, matrix::AbstractMatrix,
                                     ids::AbstractVector{<:AbstractString})
    n, m = size(matrix)
    n == m || throw(ArgumentError("$kind must be square"))
    length(ids) == n || throw(ArgumentError("ids must match $kind dimensions"))
    io = _provenance_buffer(kind)
    _provenance_write_u64(io, n)
    _provenance_write_u64(io, m)
    _provenance_write_strings(io, ids) # row IDs
    _provenance_write_strings(io, ids) # column IDs, framed separately by contract
    for value in matrix
        _provenance_write_float64(io, value)
    end
    return _provenance_digest(io)
end


"""
    _genomic_precision_provenance(Q, ids)

Internal provenance for a caller-supplied genomic precision. Construction method, allele-frequency
source, ridge, scale denominator, and covariance-kernel fingerprint are deliberately unknown.
"""
function _genomic_precision_provenance(Q::AbstractMatrix, ids)
    n = size(Q, 1)
    size(Q, 2) == n || throw(ArgumentError("Q must be square"))
    values = Matrix{Float64}(Q)
    all(isfinite, values) || throw(ArgumentError("Q must contain only finite values"))
    id_values = _canonical_genomic_ids(ids, n)
    return (
        relationship_source = "supplied_Ginv",
        relationship_method = nothing,
        allele_frequency_source = nothing,
        ridge = nothing,
        scale_denominator = nothing,
        relationship_scale = "inverse_of_supplied_precision",
        id_order_fingerprint = _genomic_id_order_fingerprint(id_values),
        marker_content_fingerprint = nothing,
        kernel_fingerprint = nothing,
        precision_fingerprint = _genomic_matrix_fingerprint("Q_lambda", values, id_values),
    )
end


"""
    _genomic_activation_construction(markers, ids; marker_names = nothing, ridge = 0.01)

Internal, bridge-facing construction for the frozen v0.7 genomic activation route. It uses sample
allele frequencies, unweighted VanRaden method 1, and the supplied ridge, returning every symbolic
intermediate plus engine-owned semantic provenance. This is not a new public Julia API.
"""
function _genomic_activation_construction(markers::AbstractMatrix, ids;
                                          marker_names = nothing, ridge::Real = 0.01)
    ridge_value = Float64(ridge)
    isfinite(ridge_value) && ridge_value >= 0 ||
        throw(ArgumentError("ridge must be non-negative and finite"))
    M = Matrix{Float64}(markers)
    n, _ = size(M)
    id_values = _canonical_genomic_ids(ids, n)
    cm = centered_markers(M)
    G = genomic_relationship_matrix(M; allele_frequencies = cm.p, method = :vanraden1)
    K = Matrix{Float64}(G) + ridge_value * I
    Q = Matrix{Float64}(genomic_relationship_inverse(G; ridge = ridge_value))
    provenance = (
        relationship_source = "markers",
        relationship_method = "vanraden1",
        allele_frequency_source = "sample",
        ridge = ridge_value,
        scale_denominator = cm.k,
        relationship_scale = "K_lambda",
        id_order_fingerprint = _genomic_id_order_fingerprint(id_values),
        marker_content_fingerprint = _genomic_marker_fingerprint(M, id_values, marker_names),
        kernel_fingerprint = _genomic_matrix_fingerprint("K_lambda", K, id_values),
        precision_fingerprint = _genomic_matrix_fingerprint("Q_lambda", Q, id_values),
    )
    return (p = cm.p, W = cm.W, k = cm.k, G = G, K = K, Q = Q,
            provenance = provenance)
end

"""
    apy_genomic_relationship_inverse(G, core; ridge = 0.0)

APY (Algorithm for Proven & Young, Misztal et al. 2014) sparse-structured inverse of a genomic
relationship matrix `G` — the large-genotyped-population scale path for `Ginv` (v0.8-S4/V8.5). It
inverts only the `core × core` block and adds a DIAGONAL conditional-variance correction for the
non-core animals, instead of the full `O(n³)` dense inverse: partition animals into `core` `c` and
non-core `n`,

  - `Mnn = Diagonal(gᵢᵢ − G[i,c]·Gcc⁻¹·G[c,i])` (each non-core animal's conditional "Mendelian"
    variance);
  - `Ginv = [[Gcc⁻¹ + Gcc⁻¹Gcn·Mnn⁻¹·GncGcc⁻¹,  −Gcc⁻¹Gcn·Mnn⁻¹];  [−Mnn⁻¹·GncGcc⁻¹,  Mnn⁻¹]]`.

`core` is the vector of core-animal row indices into `G`. `ridge` is added to the `core` block
before its Cholesky (a VanRaden `G` is rank-deficient). As the core set approaches the effective
rank of `G`, `Ginv_APY → inv(G)`; with `core = 1:n` (all animals) it equals the full regularized
`inv(G + ridge·I)` EXACTLY. Returns the dense `n × n` `Ginv` (the APY STRUCTURE — the compute win is
inverting `Gcc` (`ncore³`) + the diagonal `Mnn`, `O(ncore³ + nnoncore·ncore²)`, not `O(n³)`; the
result is returned dense at validation scale — a sparse/on-device representation is future work).

EXPERIMENTAL, engine-internal, validation-scale, supplied-`G`; no core-selection algorithm (the
caller supplies `core`), no R surface. Throws when a conditional variance is non-finite or is not
positive relative to its subtraction scale (increase the core set or `ridge`).
"""
function apy_genomic_relationship_inverse(G::AbstractMatrix, core::AbstractVector{<:Integer};
                                          ridge::Real = 0.0)
    n = size(G, 1)
    size(G, 2) == n || throw(ArgumentError("G must be square"))
    isfinite(ridge) || throw(ArgumentError("ridge must be finite"))
    ridge >= 0 || throw(ArgumentError("ridge must be non-negative"))
    ridge_f = Float64(ridge)
    isfinite(ridge_f) || throw(ArgumentError("ridge must remain finite after conversion to Float64"))
    all(isfinite, G) || throw(ArgumentError("G must contain only finite values"))
    issymmetric(G) || throw(ArgumentError("G must be symmetric"))
    core = sort(unique(Int.(core)))
    (isempty(core) || core[1] < 1 || core[end] > n) &&
        throw(ArgumentError("core must be a non-empty set of row indices in 1:$n"))
    noncore = setdiff(1:n, core)
    nc = length(core)
    Gd = Matrix{Float64}(G)
    all(isfinite, Gd) || throw(ArgumentError("G must remain finite after conversion to Float64"))
    Gcc_values = Gd[core, core] + ridge_f * I
    all(isfinite, Gcc_values) ||
        throw(ArgumentError("APY regularized core block is not finite at this scale"))
    Gcc = Symmetric(Gcc_values)
    Gcc_f = try
        cholesky(Gcc)
    catch err
        err isa LinearAlgebra.PosDefException &&
            throw(ArgumentError("APY core block is not positive definite; increase ridge or the core set"))
        rethrow(err)
    end
    Gcc_inv = Gcc_f \ Matrix{Float64}(I, nc, nc)
    Ginv = zeros(Float64, n, n)
    Ginv[core, core] .= Gcc_inv
    if !isempty(noncore)
        Gcn = Gd[core, noncore]                              # nc × nn
        B = Gcc_inv * Gcn                                    # Gcc⁻¹Gcn
        m = Vector{Float64}(undef, length(noncore))
        m_scale = similar(m)
        for j in eachindex(noncore)
            diagonal = Gd[noncore[j], noncore[j]]
            correction = dot(view(Gcn, :, j), view(B, :, j))
            m[j] = diagonal - correction
            m_scale[j] = max(abs(diagonal), abs(correction))
        end
        all(j -> isfinite(m[j]) && m[j] > 16eps(Float64) * m_scale[j], eachindex(m)) ||
            throw(ArgumentError("APY: non-core conditional variance is non-finite or numerically non-positive; increase the core set or ridge"))
        Minv = 1.0 ./ m
        all(isfinite, Minv) ||
            throw(ArgumentError("APY: conditional-variance inverse is not finite at this scale"))
        Ginv[core, core] .+= B * (Diagonal(Minv) * transpose(B))
        cn = -(B .* transpose(Minv))                         # −Gcc⁻¹Gcn·Mnn⁻¹
        Ginv[core, noncore] .= cn
        Ginv[noncore, core] .= transpose(cn)
        Ginv[noncore, noncore] .= Diagonal(Minv)
    end
    all(isfinite, Ginv) || throw(ArgumentError("APY precision is not finite at this scale"))
    return _symmetrize_roundoff!(Ginv)
end

"""
    loco_relationship_precisions(markers, marker_groups; allele_frequencies = nothing,
                                 ridge = 0.01)

Construct dense leave-one-group-out genomic relationship precisions from marker
dosages.

`marker_groups` must provide one group label per marker column, for example a
chromosome label. For each group, the helper drops that group's markers, builds a
VanRaden genomic relationship matrix from the remaining markers using
[`genomic_relationship_matrix`](@ref), and returns its regularized dense inverse
from [`genomic_relationship_inverse`](@ref). The return value is a
`Dict{String, Matrix{Float64}}` keyed by group label, ready to pass as the
`relationship_precisions` argument to [`loco_mixed_model_marker_scan`](@ref).

This is a validation-scale construction helper. It does not choose public LOCO
defaults, estimate variance components, calibrate marker-scan p-values, parse
marker files, or activate R-facing `marker_scan()` syntax.
"""
function loco_relationship_precisions(
    markers::AbstractMatrix,
    marker_groups;
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    ridge::Real = 0.01,
)
    M = Float64.(markers)
    n, m = size(M)
    (n >= 1 && m >= 1) || throw(ArgumentError("markers must be non-empty"))

    groups = string.(collect(marker_groups))
    length(groups) == m ||
        throw(ArgumentError("marker_groups must have one entry per marker"))
    all(!isempty, groups) ||
        throw(ArgumentError("marker_groups cannot contain empty labels"))
    group_order = _unique_strings(groups)
    length(group_order) >= 2 ||
        throw(ArgumentError("LOCO relationship construction requires at least two marker groups"))

    ridge_value = Float64(ridge)
    isfinite(ridge_value) && ridge_value >= 0 ||
        throw(ArgumentError("ridge must be non-negative and finite"))

    p = if allele_frequencies === nothing
        nothing
    else
        length(allele_frequencies) == m ||
            throw(ArgumentError("allele_frequencies must have one entry per marker"))
        p_values = Float64.(allele_frequencies)
        all(f -> 0 <= f <= 1, p_values) ||
            throw(ArgumentError("allele frequencies must lie in [0, 1]"))
        p_values
    end

    precisions = Dict{String,Matrix{Float64}}()
    for group in group_order
        keep = groups .!= group
        any(keep) ||
            throw(ArgumentError("LOCO group $(group) leaves no markers for relationship construction"))
        group_p = p === nothing ? nothing : p[keep]
        G = genomic_relationship_matrix(M[:, keep]; allele_frequencies = group_p)
        precisions[group] = genomic_relationship_inverse(G; ridge = ridge_value)
    end
    return precisions
end

"""
    fit_gblup(y, X, Z, Ginv, sigma_a2, sigma_e2; ids = nothing, method = :REML)

Genomic BLUP (GBLUP) at supplied variance components: solve the Gaussian animal
model with a genomic relationship inverse `Ginv` in place of the pedigree `Ainv`,
reusing the existing Henderson mixed-model-equation solve.

`Ginv` is the (regularized) inverse of a genomic relationship matrix, e.g. from
[`genomic_relationship_inverse`](@ref). A VanRaden `G` is rank-deficient
(column-centering puts the all-ones vector in its null space, so `rank(G) ≤
n − 1`), so it must be regularized before inversion — that is
`genomic_relationship_inverse`'s job, not this function's. `sigma_a2` and
`sigma_e2` are the supplied genomic and residual variances; GBLUP here does not
estimate them.

This is a thin convenience over [`animal_model_spec`](@ref) +
[`henderson_mme`](@ref): the genomic precision enters the same `Ainv` slot the
pedigree animal model uses, so it returns the same [`HendersonMMEResult`](@ref)
and works with every existing extractor (`fixed_effects`, `breeding_values`,
`heritability`, …). It is experimental and engine-internal; the user-facing R
`genomic()` model-spec mapping is coordinated separately and not part of this
function. The dense `Ginv` path is validation-scale only — it does not gain the
sparse selected-inversion advantage.
"""
function fit_gblup(
    y::AbstractVector,
    X::AbstractMatrix,
    Z::AbstractMatrix,
    Ginv::AbstractMatrix,
    sigma_a2::Real,
    sigma_e2::Real;
    ids = nothing,
    method = :REML,
)
    spec = animal_model_spec(y, X, Z, Ginv; ids = ids, method = method)
    return henderson_mme(spec, sigma_a2, sigma_e2)
end

"""
    fit_gblup_reml(y, X, Z, Ginv; initial = (sigma_a2 = 1.0, sigma_e2 = 1.0),
                   target = :ai_reml, iterations = nothing, ids = nothing)

GBLUP with REML-estimated variance components: build the genomic animal-model
spec (genomic precision `Ginv` in the `Ainv` slot) and estimate `(sigma_a2,
sigma_e2)` by REML, instead of supplying them as in [`fit_gblup`](@ref). A
one-call convenience over `animal_model_spec(...; method = :REML)` +
[`fit_animal_model`](@ref); `target = :ai_reml` (default) or `:sparse_reml`.
Returns the [`AnimalModelFit`](@ref) (estimated `variance_components`, genomic
`breeding_values`, `likelihood`, `converged`, …).

`iterations` (hsquared#212), when supplied, forwards to whichever `target`
optimizer is selected (`fit_ai_reml`'s own default is 100; `fit_sparse_reml`'s
and `fit_variance_components`'s is 1000) via [`fit_animal_model`](@ref)'s
`kwargs...` passthrough. Default `nothing` omits the keyword entirely, so the
call is byte-identical to the pre-#212-fix behaviour (each target's own
hardcoded default).

Experimental, dense/validation-scale (the dense `Ginv` path gains no sparse
selected-inversion advantage); no external comparator, no R model-spec.
"""
function fit_gblup_reml(
    y::AbstractVector,
    X::AbstractMatrix,
    Z::AbstractMatrix,
    Ginv::AbstractMatrix;
    initial = (sigma_a2 = 1.0, sigma_e2 = 1.0),
    target::Symbol = :ai_reml,
    iterations::Union{Nothing,Integer} = nothing,
    ids = nothing,
)
    spec = animal_model_spec(y, X, Z, Ginv; ids = ids, method = :REML)
    iterations === nothing && return fit_animal_model(spec; target = target, initial = initial)
    return fit_animal_model(spec; target = target, initial = initial, iterations = iterations)
end

"""
    fit_snp_blup(y, X, markers, sigma_g2, sigma_e2; allele_frequencies = nothing,
                 ids = nothing)

SNP-BLUP / RR-BLUP at supplied variance components: estimate marker effects with
the existing Henderson MME, treating the centered markers as the random-effect
design with an identity prior.

The centered markers `W` (from [`centered_markers`](@ref)) are the random-effect
design `Z`, the relationship inverse is the identity `I_m` (markers a priori
independent), and the per-marker variance is `sigma_g2 / k` with
`k = 2 Σ_j p_j(1 − p_j)`. Returns a `NamedTuple` `(marker_effects, gebv, beta, k,
p)` where `marker_effects = â`, `gebv = W·â` are the implied genomic breeding
values, and `beta` are the fixed effects.

`gebv` equals the GBLUP genomic breeding values for the same data and variances,
exactly for `G` itself (the GBLUP↔SNP-BLUP equivalence) — but through
[`fit_gblup`](@ref)'s required `Ginv = inv(G + ridge·I)`, the package's only
GBLUP route, the two differ by O(ridge): about 1–2 % of `sd(gebv)` at the
package default `ridge = 0.01`, because the ridge changes the covariance kernel.
See issue #333 for the measured per-cell gap; [Genomic models](genomic-models.md)
explains why the ridge breaks the equivalence but does not carry the measurement.
The random block is
deliberately labelled `marker_effects` (not `breeding_values`/EBV), because on
this spec the random effects are marker effects, not animal breeding values.
Experimental, supplied-variance only (no variance-component estimation); unweighted VanRaden
method-1 / single identity prior only.
"""
function fit_snp_blup(
    y::AbstractVector,
    X::AbstractMatrix,
    markers::AbstractMatrix,
    sigma_g2::Real,
    sigma_e2::Real;
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    ids = nothing,
)
    cm = centered_markers(markers; allele_frequencies = allele_frequencies)
    Im = Matrix{Float64}(I, size(cm.W, 2), size(cm.W, 2))
    spec = animal_model_spec(y, X, cm.W, Im; ids = ids, method = :REML)
    res = henderson_mme(spec, sigma_g2 / cm.k, sigma_e2)
    a = breeding_values(res).values
    return (marker_effects = a, gebv = cm.W * a, beta = fixed_effects(res), k = cm.k, p = cm.p)
end

"""
    fit_snp_blup_reml(y, X, markers; initial = (sigma_a2 = 1.0, sigma_e2 = 1.0),
                      allele_frequencies = nothing, target = :ai_reml, ids = nothing)

SNP-BLUP / RR-BLUP with REML-estimated variance components: estimate the per-marker
random-effect variance and residual variance by REML on the centered-marker spec
(markers as the random-effect design with an identity prior), instead of supplying
them as in [`fit_snp_blup`](@ref). Returns a `NamedTuple`
`(marker_effects, gebv, beta, sigma_g2, sigma_e2, k, p, loglik, converged)`, where
`sigma_g2 = σ̂²_marker · k` is the total genomic variance (`k = 2 Σ_j p_j(1 − p_j)`).

At the estimated variances this reproduces [`fit_snp_blup`](@ref) exactly (the REML
wrapper just supplies the estimated variances). Experimental, dense/validation-scale,
unweighted VanRaden method-1 / single identity prior; no external comparator.
"""
function fit_snp_blup_reml(
    y::AbstractVector,
    X::AbstractMatrix,
    markers::AbstractMatrix;
    initial = (sigma_a2 = 1.0, sigma_e2 = 1.0),
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    target::Symbol = :ai_reml,
    ids = nothing,
)
    cm = centered_markers(markers; allele_frequencies = allele_frequencies)
    Im = Matrix{Float64}(I, size(cm.W, 2), size(cm.W, 2))
    spec = animal_model_spec(y, X, cm.W, Im; ids = ids, method = :REML)
    fit = fit_animal_model(spec; target = target, initial = initial)
    a = breeding_values(fit).values
    return (marker_effects = a, gebv = cm.W * a, beta = fixed_effects(fit),
            sigma_g2 = fit.variance_components.sigma_a2 * cm.k,
            sigma_e2 = fit.variance_components.sigma_e2, k = cm.k, p = cm.p,
            loglik = fit.likelihood.loglik, converged = fit.converged)
end

"""
    single_marker_scan(y, X, markers; allele_frequencies = nothing,
                       sigma_e2 = 1.0, marker_ids = nothing)

Fixed-effect single-marker scan for biallelic marker dosages at a supplied
residual variance.

Each marker column is centered with [`centered_markers`](@ref), residualized
against the fixed-effect design `X`, and tested one marker at a time in the
Gaussian linear model `y = Xβ + marker * α + e`. The returned `NamedTuple`
contains `marker_ids`, `effects`, `standard_errors`, `z_scores`, `chisq`,
`p_values`, `bonferroni_p_values`, `bh_q_values`, `lod_scores`,
`denominators`, `p`, and `k`. `p_values` are approximate two-sided
Gaussian/Wald p-values implied by the supplied residual variance.
`bonferroni_p_values` and `bh_q_values` are deterministic Bonferroni and
Benjamini-Hochberg adjustments over the returned marker set. `lod_scores` are
known-variance fixed-effect LOD-equivalent scores, computed as
`chisq / (2log(10))`.

This is a deterministic Phase 5 validation-scale utility. It is not a mixed
model GWAS/QTL scan, does not account for relatedness or population structure,
does not compute interval-mapping or mixed-model LOD scores or calibrated /
correlated-marker multiple-testing workflows, and does not activate the
R-facing `marker_scan()` formula term.
"""
function single_marker_scan(
    y::AbstractVector,
    X::AbstractMatrix,
    markers::AbstractMatrix;
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    sigma_e2::Real = 1.0,
    marker_ids = nothing,
)
    yv = Float64.(y)
    Xmat = Matrix{Float64}(X)
    length(yv) == size(Xmat, 1) ||
        throw(ArgumentError("X row count must match y length"))
    n, p = size(Xmat)
    n > p || throw(ArgumentError("single-marker scan requires more observations than fixed effects"))
    all(isfinite, yv) || throw(ArgumentError("y must contain only finite values"))
    all(isfinite, Xmat) || throw(ArgumentError("X must contain only finite values"))
    sigma_e2_f = Float64(sigma_e2)
    isfinite(sigma_e2_f) && sigma_e2_f > 0 ||
        throw(ArgumentError("sigma_e2 must be finite and positive"))

    cm = centered_markers(markers; allele_frequencies = allele_frequencies)
    size(cm.W, 1) == n ||
        throw(ArgumentError("markers row count must match y length"))
    marker_names = if marker_ids === nothing
        ["marker_$j" for j in axes(cm.W, 2)]
    else
        length(marker_ids) == size(cm.W, 2) ||
            throw(ArgumentError("marker_ids must have one entry per marker"))
        string.(marker_ids)
    end

    XtX = Symmetric(transpose(Xmat) * Xmat)
    isposdef(XtX) ||
        throw(ArgumentError("X must have full column rank"))
    Xty = transpose(Xmat) * yv
    y_resid = yv - Xmat * (XtX \ Xty)

    effects = zeros(Float64, size(cm.W, 2))
    standard_errors = similar(effects)
    z_scores = similar(effects)
    chisq = similar(effects)
    p_values = similar(effects)
    denominators = similar(effects)

    for j in axes(cm.W, 2)
        w = view(cm.W, :, j)
        w_resid = Vector(w) - Xmat * (XtX \ (transpose(Xmat) * w))
        denom = dot(w_resid, w_resid)
        denom > sqrt(eps(Float64)) ||
            throw(ArgumentError("marker $(marker_names[j]) is collinear with X after centering"))
        alpha = dot(w_resid, y_resid) / denom
        se = sqrt(sigma_e2_f / denom)
        z = alpha / se
        denominators[j] = denom
        effects[j] = alpha
        standard_errors[j] = se
        z_scores[j] = z
        chisq[j] = z^2
        p_values[j] = _standard_normal_two_sided_pvalue(z)
    end

    bonferroni_p_values = _bonferroni_adjust(p_values)
    bh_q_values = _benjamini_hochberg_adjust(p_values)
    lod_scores = chisq ./ (2 * log(10))

    return (
        marker_ids = marker_names,
        effects = effects,
        standard_errors = standard_errors,
        z_scores = z_scores,
        chisq = chisq,
        p_values = p_values,
        bonferroni_p_values = bonferroni_p_values,
        bh_q_values = bh_q_values,
        lod_scores = lod_scores,
        denominators = denominators,
        p = cm.p,
        k = cm.k,
    )
end

"""
    mixed_model_marker_scan(y, X, Z, Ainv, markers, sigma_a2, sigma_e2;
                            allele_frequencies = nothing, marker_ids = nothing)

Supplied-variance mixed-model single-marker scan for biallelic marker dosages.

The helper forms the dense validation-scale marginal covariance
`V = sigma_a2 * Z * A * Z' + sigma_e2 * I`, where `A = inv(Ainv)`, then tests
each centered marker as a fixed effect by generalized least squares conditional
on the fixed-effect design `X`. The returned fields mirror
[`single_marker_scan`](@ref): marker effects, standard errors, Wald z-scores,
chi-square statistics, approximate two-sided Gaussian/Wald p-values,
Bonferroni-adjusted p-values, Benjamini-Hochberg q-values, LOD-equivalent
scores, GLS denominators, marker IDs, allele frequencies, and the VanRaden
scale, plus supplied variance components and `target = :mixed_model_marker_scan`.

This is an engine-internal, dense, supplied-variance Phase 5 utility. It is not
variance-component estimation, LOCO, interval mapping, calibrated genome-wide
testing, a plotting backend, a bridge payload, or activation of the R-facing
`marker_scan()` formula term.
"""
function mixed_model_marker_scan(
    y::AbstractVector,
    X::AbstractMatrix,
    Z::AbstractMatrix,
    Ainv::AbstractMatrix,
    markers::AbstractMatrix,
    sigma_a2::Real,
    sigma_e2::Real;
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    marker_ids = nothing,
)
    common = _mixed_marker_scan_common(
        y,
        X,
        Z,
        markers,
        sigma_a2,
        sigma_e2;
        allele_frequencies = allele_frequencies,
        marker_ids = marker_ids,
    )
    cache = _mixed_marker_scan_cache(common.y, common.X, common.Z, Ainv, common.sigma_a2, common.sigma_e2)
    stats = _mixed_marker_scan_stats(common.cm.W, common.marker_ids, _ -> cache)
    return _mixed_marker_scan_result(common, stats, :mixed_model_marker_scan)
end

"""
    loco_mixed_model_marker_scan(y, X, Z, relationship_precisions, marker_groups,
                                 markers, sigma_a2, sigma_e2; ...)

Leave-one-group-out supplied-variance mixed-model marker scan.

`relationship_precisions` is a dictionary or named tuple mapping each marker
group label (for example a chromosome) to the relationship precision that should
be used when testing markers in that group. The helper selects the matching
precision for each marker, forms the dense validation-scale GLS covariance, and
runs the same marker-by-marker Wald scan as [`mixed_model_marker_scan`](@ref).
Callers can build the dictionary with [`loco_relationship_precisions`](@ref), or
provide their own externally constructed matrices.

This helper only selects among supplied matrices; it does not choose public LOCO
defaults, estimate variance components, calibrate p-values, run sparse
production scans, or activate the R-facing `marker_scan()` formula term.
"""
function loco_mixed_model_marker_scan(
    y::AbstractVector,
    X::AbstractMatrix,
    Z::AbstractMatrix,
    relationship_precisions,
    marker_groups,
    markers::AbstractMatrix,
    sigma_a2::Real,
    sigma_e2::Real;
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    marker_ids = nothing,
)
    common = _mixed_marker_scan_common(
        y,
        X,
        Z,
        markers,
        sigma_a2,
        sigma_e2;
        allele_frequencies = allele_frequencies,
        marker_ids = marker_ids,
    )
    groups = string.(collect(marker_groups))
    length(groups) == size(common.cm.W, 2) ||
        throw(ArgumentError("marker_groups must have one entry per marker"))
    all(!isempty, groups) ||
        throw(ArgumentError("marker_groups cannot contain empty labels"))

    precision_lookup = _relationship_precision_lookup(relationship_precisions)
    group_order = _unique_strings(groups)
    missing_groups = _ordered_setdiff(group_order, collect(keys(precision_lookup)))
    isempty(missing_groups) ||
        throw(ArgumentError("relationship_precisions missing marker groups: $(join(missing_groups, ", "))"))

    cache_by_group = Dict(
        group => _mixed_marker_scan_cache(
            common.y,
            common.X,
            common.Z,
            precision_lookup[group],
            common.sigma_a2,
            common.sigma_e2,
        ) for group in group_order
    )
    stats = _mixed_marker_scan_stats(common.cm.W, common.marker_ids, j -> cache_by_group[groups[j]])
    result = _mixed_marker_scan_result(common, stats, :loco_mixed_model_marker_scan)
    return merge(result, (marker_groups = groups, relationship_groups = group_order))
end

function _mixed_marker_scan_common(
    y::AbstractVector,
    X::AbstractMatrix,
    Z::AbstractMatrix,
    markers::AbstractMatrix,
    sigma_a2::Real,
    sigma_e2::Real;
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    marker_ids = nothing,
)
    yv = Float64.(y)
    Xmat = Matrix{Float64}(X)
    Zmat = Matrix{Float64}(Z)
    n = length(yv)
    size(Xmat, 1) == n ||
        throw(ArgumentError("X row count must match y length"))
    size(Zmat, 1) == n ||
        throw(ArgumentError("Z row count must match y length"))
    n > size(Xmat, 2) ||
        throw(ArgumentError("mixed-model marker scan requires more observations than fixed effects"))
    all(isfinite, yv) || throw(ArgumentError("y must contain only finite values"))
    all(isfinite, Xmat) || throw(ArgumentError("X must contain only finite values"))
    all(isfinite, Zmat) || throw(ArgumentError("Z must contain only finite values"))
    rank(Xmat) == size(Xmat, 2) ||
        throw(ArgumentError("X must have full column rank"))
    sigma_a2 < 0 &&
        throw(ArgumentError("sigma_a2 must be nonnegative and finite"))
    sa2 = Float64(sigma_a2)
    se2 = Float64(sigma_e2)
    isfinite(sa2) && sa2 >= 0 ||
        throw(ArgumentError("sigma_a2 must be nonnegative and finite"))
    isfinite(se2) && se2 > 0 ||
        throw(ArgumentError("sigma_e2 must be positive and finite"))

    cm = centered_markers(markers; allele_frequencies = allele_frequencies)
    size(cm.W, 1) == n ||
        throw(ArgumentError("markers row count must match y length"))
    marker_names = if marker_ids === nothing
        ["marker_$j" for j in axes(cm.W, 2)]
    else
        length(marker_ids) == size(cm.W, 2) ||
            throw(ArgumentError("marker_ids must have one entry per marker"))
        string.(marker_ids)
    end
    return (y = yv, X = Xmat, Z = Zmat, cm = cm, marker_ids = marker_names, sigma_a2 = sa2, sigma_e2 = se2)
end

function _mixed_marker_scan_cache(
    yv::Vector{Float64},
    Xmat::Matrix{Float64},
    Zmat::Matrix{Float64},
    Ainv::AbstractMatrix,
    sigma_a2::Float64,
    sigma_e2::Float64,
)
    n = length(yv)
    Ainvmat = Matrix{Float64}(Ainv)
    size(Ainvmat, 1) == size(Ainvmat, 2) ||
        throw(ArgumentError("Ainv must be square"))
    size(Zmat, 2) == size(Ainvmat, 1) ||
        throw(ArgumentError("Z columns must match Ainv dimensions"))
    all(isfinite, Ainvmat) || throw(ArgumentError("Ainv must contain only finite values"))

    issymmetric(Ainvmat) || throw(ArgumentError("Ainv must be symmetric"))
    Ainv_sym = Symmetric(Ainvmat)
    isposdef(Ainv_sym) ||
        throw(ArgumentError("Ainv must be positive definite"))
    A = inv(Ainv_sym)
    V = Symmetric(sigma_a2 * Zmat * A * transpose(Zmat) + sigma_e2 * Matrix{Float64}(I, n, n))
    isposdef(V) ||
        throw(ArgumentError("supplied covariance must be positive definite"))
    cholV = cholesky(V)

    Vinv_X = cholV \ Xmat
    Vinv_y = cholV \ yv
    XtVinvX = Symmetric(transpose(Xmat) * Vinv_X)
    isposdef(XtVinvX) ||
        throw(ArgumentError("X must have full column rank under the supplied covariance"))
    cholXtVinvX = cholesky(XtVinvX)
    Py = Vinv_y - Vinv_X * (cholXtVinvX \ (transpose(Xmat) * Vinv_y))
    return (cholV = cholV, Vinv_X = Vinv_X, cholXtVinvX = cholXtVinvX, Py = Py)
end

function _mixed_marker_scan_stats(W::AbstractMatrix, marker_names::Vector{String}, cache_for_marker)
    effects = zeros(Float64, size(W, 2))
    standard_errors = similar(effects)
    z_scores = similar(effects)
    chisq = similar(effects)
    p_values = similar(effects)
    denominators = similar(effects)

    for j in axes(W, 2)
        cache = cache_for_marker(j)
        w = Vector(@view(W[:, j]))
        Vinv_w = cache.cholV \ w
        Pw = Vinv_w - cache.Vinv_X * (cache.cholXtVinvX \ (transpose(cache.Vinv_X) * w))
        denom = dot(w, Pw)
        denom > sqrt(eps(Float64)) ||
            throw(ArgumentError("marker $(marker_names[j]) is collinear with X under the supplied covariance"))
        alpha = dot(w, cache.Py) / denom
        se = sqrt(inv(denom))
        z = alpha / se
        denominators[j] = denom
        effects[j] = alpha
        standard_errors[j] = se
        z_scores[j] = z
        chisq[j] = z^2
        p_values[j] = _standard_normal_two_sided_pvalue(z)
    end

    bonferroni_p_values = _bonferroni_adjust(p_values)
    bh_q_values = _benjamini_hochberg_adjust(p_values)
    lod_scores = chisq ./ (2 * log(10))
    return (
        effects = effects,
        standard_errors = standard_errors,
        z_scores = z_scores,
        chisq = chisq,
        p_values = p_values,
        bonferroni_p_values = bonferroni_p_values,
        bh_q_values = bh_q_values,
        lod_scores = lod_scores,
        denominators = denominators,
    )
end

function _mixed_marker_scan_result(common, stats, target::Symbol)
    return (
        marker_ids = common.marker_ids,
        effects = stats.effects,
        standard_errors = stats.standard_errors,
        z_scores = stats.z_scores,
        chisq = stats.chisq,
        p_values = stats.p_values,
        bonferroni_p_values = stats.bonferroni_p_values,
        bh_q_values = stats.bh_q_values,
        lod_scores = stats.lod_scores,
        denominators = stats.denominators,
        p = common.cm.p,
        k = common.cm.k,
        variance_components = (sigma_a2 = common.sigma_a2, sigma_e2 = common.sigma_e2),
        target = target,
    )
end

"""
    marker_scan_result_payload(scan)

Return the bridge-facing marker-scan result payload.

This is the stable, boring `NamedTuple` shape for post-fit GWAS/QTL/eQTL bridge
work. It preserves the row-aligned scan fields returned by
[`single_marker_scan`](@ref), [`mixed_model_marker_scan`](@ref), or
[`loco_mixed_model_marker_scan`](@ref): marker IDs, effect estimates, standard
errors, Wald statistics, chi-square values, nominal p-values,
Bonferroni/BH-adjusted p-values, LOD-equivalent scores, denominators, allele
frequencies, VanRaden scale, optional supplied variance components, and optional
LOCO group metadata.

The payload does not run a scan, calibrate genome-wide thresholds, estimate
marker-scan variance components, join marker maps, draw figures, or activate the
R-facing `marker_scan()` formula term.
"""
function marker_scan_result_payload(scan)
    marker_ids = _scan_marker_ids(scan)
    m = length(marker_ids)
    payload = (
        engine = "HSquared.jl",
        target = hasproperty(scan, :target) ? getproperty(scan, :target) : :direct_marker_scan,
        n_markers = m,
        marker_ids = marker_ids,
        effects = _checked_scan_float_field(scan, :effects, m),
        standard_errors = _checked_scan_float_field(scan, :standard_errors, m; positive = true),
        z_scores = _checked_scan_float_field(scan, :z_scores, m),
        chisq = _checked_scan_float_field(scan, :chisq, m; nonnegative = true),
        p_values = _checked_scan_p_value_field(scan, :p_values, m),
        bonferroni_p_values = _checked_scan_p_value_field(scan, :bonferroni_p_values, m),
        bh_q_values = _checked_scan_p_value_field(scan, :bh_q_values, m),
        lod_scores = _checked_scan_float_field(scan, :lod_scores, m; nonnegative = true),
        denominators = _checked_scan_float_field(scan, :denominators, m; positive = true),
        allele_frequencies = _checked_scan_allele_frequencies(scan, m),
        vanraden_scale = hasproperty(scan, :k) ? _checked_scan_scalar(scan, :k; nonnegative = true) : nothing,
        variance_components = hasproperty(scan, :variance_components) ? getproperty(scan, :variance_components) : nothing,
    )
    if hasproperty(scan, :marker_groups)
        payload = merge(payload, (marker_groups = _checked_scan_marker_groups(scan, m),))
    end
    if hasproperty(scan, :relationship_groups)
        payload = merge(payload, (relationship_groups = string.(collect(getproperty(scan, :relationship_groups))),))
    end
    return payload
end

function _relationship_precision_lookup(relationship_precisions::AbstractDict)
    lookup = Dict{String,Any}()
    for (key, value) in relationship_precisions
        canonical_key = string(key)
        haskey(lookup, canonical_key) &&
            throw(ArgumentError("relationship_precisions keys must remain unique after conversion to strings; duplicate key: $(canonical_key)"))
        lookup[canonical_key] = value
    end
    isempty(lookup) ||
        return lookup
    throw(ArgumentError("relationship_precisions cannot be empty"))
end

function _relationship_precision_lookup(relationship_precisions::NamedTuple)
    lookup = Dict{String,Any}()
    for key in keys(relationship_precisions)
        lookup[string(key)] = getproperty(relationship_precisions, key)
    end
    isempty(lookup) ||
        return lookup
    throw(ArgumentError("relationship_precisions cannot be empty"))
end

function _relationship_precision_lookup(relationship_precisions)
    throw(ArgumentError("relationship_precisions must be a dictionary or named tuple"))
end

"""
    marker_manhattan_data(scan; chromosomes = nothing, positions = nothing,
                          p_floor = floatmin(Float64), chromosome_gap = 1.0)
    marker_manhattan_data(scan, marker_spec::HSMarkerMapSpec; ...)
    marker_manhattan_data(scan, data::HSData; ...)

Prepare plot-ready Manhattan data from a direct [`single_marker_scan`](@ref)
result.

The helper returns marker IDs, raw p-values, `-log10(p)` values, chromosome
labels, marker positions, cumulative plotting positions, and a deterministic
plot order. If chromosome or position metadata is omitted, all markers are
placed on chromosome `"1"` with sequential positions. Zero p-values are floored
only for `-log10` display values, and the floor is returned in the output.
When a validated [`HSMarkerMapSpec`](@ref) or [`HSData`](@ref) with marker
metadata is supplied, marker IDs must match the scan exactly; chromosome and
position metadata are then aligned to the scan marker order, while chromosome
display order follows the marker-map order.

This is a data-preparation helper only. It does not draw a plot, does not parse
marker maps, does not run a mixed-model marker scan, and does not activate the
R-facing `marker_scan()` formula term.
"""
function marker_manhattan_data(
    scan;
    chromosomes = nothing,
    positions = nothing,
    p_floor::Real = floatmin(Float64),
    chromosome_gap::Real = 1.0,
)
    marker_ids, p_values = _scan_marker_ids_and_p_values(scan)

    m = length(p_values)
    chromosome_values = if chromosomes === nothing
        fill("1", m)
    elseif chromosomes isa AbstractString || chromosomes isa Symbol
        fill(string(chromosomes), m)
    else
        string.(collect(chromosomes))
    end
    position_values = if positions === nothing
        Float64.(collect(1:m))
    else
        Float64.(collect(positions))
    end

    return _marker_manhattan_data_from_vectors(
        marker_ids,
        p_values,
        chromosome_values,
        position_values,
        p_floor,
        chromosome_gap,
    )
end

function marker_manhattan_data(
    scan,
    marker_spec::HSMarkerMapSpec;
    p_floor::Real = floatmin(Float64),
    chromosome_gap::Real = 1.0,
)
    marker_ids, p_values = _scan_marker_ids_and_p_values(scan)
    map_order = _marker_map_order_for_scan(marker_ids, marker_spec)
    return _marker_manhattan_data_from_vectors(
        marker_ids,
        p_values,
        marker_spec.chromosome[map_order],
        marker_spec.position[map_order],
        p_floor,
        chromosome_gap;
        chromosome_order = _unique_strings(marker_spec.chromosome),
    )
end

function marker_manhattan_data(
    scan,
    data::HSData;
    p_floor::Real = floatmin(Float64),
    chromosome_gap::Real = 1.0,
)
    data.marker_spec !== nothing ||
        throw(ArgumentError("HSData must contain marker metadata"))
    return marker_manhattan_data(
        scan,
        data.marker_spec;
        p_floor = p_floor,
        chromosome_gap = chromosome_gap,
    )
end

function _scan_marker_ids_and_p_values(scan)
    marker_ids = _scan_marker_ids(scan)
    hasproperty(scan, :p_values) ||
        throw(ArgumentError("scan must have a p_values field"))

    p_values = _checked_p_values(getproperty(scan, :p_values))
    m = length(p_values)
    length(marker_ids) == m ||
        throw(ArgumentError("marker_ids and p_values must have the same length"))
    return marker_ids, p_values
end

function _scan_marker_ids(scan)
    hasproperty(scan, :marker_ids) ||
        throw(ArgumentError("scan must have a marker_ids field"))
    marker_ids = string.(collect(getproperty(scan, :marker_ids)))
    !isempty(marker_ids) ||
        throw(ArgumentError("marker_ids must be non-empty"))
    return marker_ids
end

function _marker_manhattan_data_from_vectors(
    marker_ids::Vector{String},
    p_values::Vector{Float64},
    chromosome_values::AbstractVector,
    position_values::AbstractVector,
    p_floor::Real,
    chromosome_gap::Real;
    chromosome_order = nothing,
)
    m = length(p_values)

    p_floor_value = Float64(p_floor)
    isfinite(p_floor_value) && 0 < p_floor_value <= 1 ||
        throw(ArgumentError("p_floor must be finite and in (0, 1]"))
    gap = Float64(chromosome_gap)
    isfinite(gap) && gap >= 0 ||
        throw(ArgumentError("chromosome_gap must be finite and non-negative"))

    chromosome_labels = string.(collect(chromosome_values))
    length(chromosome_labels) == m ||
        throw(ArgumentError("chromosomes must have one entry per marker"))

    positions_float = Float64.(collect(position_values))
    length(positions_float) == m ||
        throw(ArgumentError("positions must have one entry per marker"))
    all(x -> isfinite(x) && x >= 0, positions_float) ||
        throw(ArgumentError("positions must be finite and non-negative"))

    chromosome_order_values = chromosome_order === nothing ?
        _unique_strings(chromosome_labels) :
        string.(collect(chromosome_order))
    duplicates = _duplicate_string_ids(chromosome_order_values)
    isempty(duplicates) ||
        throw(ArgumentError("chromosome order cannot contain duplicate values: $(join(duplicates, ", "))"))
    missing_chromosomes = _ordered_setdiff(_unique_strings(chromosome_labels), chromosome_order_values)
    isempty(missing_chromosomes) ||
        throw(ArgumentError("chromosome order is missing chromosomes: $(join(missing_chromosomes, ", "))"))

    chromosome_rank = Dict{String,Int}()
    for (rank, chromosome) in pairs(chromosome_order_values)
        chromosome_rank[chromosome] = rank
    end

    marker_order = sortperm(collect(1:m);
        by = i -> (chromosome_rank[chromosome_labels[i]], positions_float[i], i))
    plot_positions = zeros(Float64, m)
    offset = 0.0
    for chromosome in chromosome_order_values
        chromosome_indices = [i for i in marker_order if chromosome_labels[i] == chromosome]
        isempty(chromosome_indices) && continue
        for i in chromosome_indices
            plot_positions[i] = offset + positions_float[i]
        end
        offset = maximum(plot_positions[chromosome_indices]) + gap
    end

    return (
        marker_ids = marker_ids,
        chromosomes = chromosome_labels,
        positions = positions_float,
        plot_positions = plot_positions,
        p_values = p_values,
        neglog10_p_values = .-log10.(max.(p_values, p_floor_value)),
        order = marker_order,
        p_floor = p_floor_value,
    )
end

"""
    marker_region_data(scan; chromosomes, positions, chromosome, start = nothing,
                       stop = nothing, flank = 0, total_variance = nothing,
                       p_floor = floatmin(Float64))
    marker_region_data(scan, marker_spec::HSMarkerMapSpec; ...)
    marker_region_data(scan, data::HSData; ...)

Prepare scan data for one chromosome or chromosome-window region.

The helper reuses [`marker_scan_table`](@ref) validation, then subsets the
row-aligned marker-scan table by chromosome and optional coordinate bounds.
When `start` and/or `stop` are supplied, a non-negative `flank` expands that
window before filtering. Returned rows are ordered by position within the
region, with original scan indices preserved.

This is a direct Julia data-preparation helper only. It does not draw a plot,
choose thresholds, calibrate p-values, run interval mapping, activate
`gwas_table()` / `qtl_table()` / `eqtl_table()`, activate R-facing
`marker_scan()` syntax, or change the bridge payload.
"""
function marker_region_data(
    scan;
    chromosomes = nothing,
    positions = nothing,
    chromosome,
    start = nothing,
    stop = nothing,
    flank::Real = 0,
    total_variance = nothing,
    p_floor::Real = floatmin(Float64),
)
    (chromosomes !== nothing && positions !== nothing) ||
        throw(ArgumentError("chromosomes and positions are required for marker_region_data"))
    return _marker_region_data(
        scan,
        chromosomes,
        positions;
        chromosome = chromosome,
        start = start,
        stop = stop,
        flank = flank,
        total_variance = total_variance,
        p_floor = p_floor,
    )
end

function marker_region_data(
    scan,
    marker_spec::HSMarkerMapSpec;
    chromosome,
    start = nothing,
    stop = nothing,
    flank::Real = 0,
    total_variance = nothing,
    p_floor::Real = floatmin(Float64),
)
    marker_ids = _scan_marker_ids(scan)
    map_order = _marker_map_order_for_scan(marker_ids, marker_spec)
    return _marker_region_data(
        scan,
        marker_spec.chromosome[map_order],
        marker_spec.position[map_order];
        chromosome = chromosome,
        start = start,
        stop = stop,
        flank = flank,
        total_variance = total_variance,
        p_floor = p_floor,
    )
end

function marker_region_data(
    scan,
    data::HSData;
    chromosome,
    start = nothing,
    stop = nothing,
    flank::Real = 0,
    total_variance = nothing,
    p_floor::Real = floatmin(Float64),
)
    data.marker_spec !== nothing ||
        throw(ArgumentError("HSData must contain marker metadata"))
    return marker_region_data(
        scan,
        data.marker_spec;
        chromosome = chromosome,
        start = start,
        stop = stop,
        flank = flank,
        total_variance = total_variance,
        p_floor = p_floor,
    )
end

function _marker_region_data(
    scan,
    chromosomes,
    positions;
    chromosome,
    start,
    stop,
    flank::Real,
    total_variance,
    p_floor::Real,
)
    table = _marker_scan_table(scan, chromosomes, positions; total_variance = total_variance)
    m = length(table.marker_ids)

    chromosome_value = string(chromosome)
    !isempty(chromosome_value) ||
        throw(ArgumentError("chromosome must be a non-empty value"))
    start_value = _checked_optional_region_bound(start, :start)
    stop_value = _checked_optional_region_bound(stop, :stop)
    if start_value !== nothing && stop_value !== nothing
        stop_value >= start_value ||
            throw(ArgumentError("stop must be greater than or equal to start"))
    end
    flank_value = _checked_region_flank(flank)
    p_floor_value = Float64(p_floor)
    isfinite(p_floor_value) && 0 < p_floor_value <= 1 ||
        throw(ArgumentError("p_floor must be finite and in (0, 1]"))

    window_start = start_value === nothing ? nothing : max(0.0, start_value - flank_value)
    window_stop = stop_value === nothing ? nothing : stop_value + flank_value
    lower = window_start === nothing ? -Inf : window_start
    upper = window_stop === nothing ? Inf : window_stop

    selected = [
        i for i in 1:m if table.chromosomes[i] == chromosome_value &&
            lower <= table.positions[i] <= upper
    ]
    !isempty(selected) ||
        throw(ArgumentError("marker region contains no markers"))

    order = selected[sortperm(selected; by = i -> (table.positions[i], table.scan_indices[i]))]
    region = (
        marker_ids = table.marker_ids[order],
        chromosomes = table.chromosomes[order],
        positions = table.positions[order],
        plot_positions = table.positions[order],
        scan_indices = table.scan_indices[order],
        effects = table.effects[order],
        abs_effects = table.abs_effects[order],
        standard_errors = table.standard_errors[order],
        z_scores = table.z_scores[order],
        chisq = table.chisq[order],
        p_values = table.p_values[order],
        bonferroni_p_values = table.bonferroni_p_values[order],
        bh_q_values = table.bh_q_values[order],
        lod_scores = table.lod_scores[order],
        denominators = table.denominators[order],
        allele_frequencies = table.allele_frequencies[order],
        allele_variances = table.allele_variances[order],
        marker_variances = table.marker_variances[order],
        proportion_variance_explained = table.proportion_variance_explained === nothing ?
            nothing :
            table.proportion_variance_explained[order],
        total_variance = table.total_variance,
        chromosome = chromosome_value,
        requested_start = start_value,
        requested_stop = stop_value,
        flank = flank_value,
        window_start = window_start,
        window_stop = window_stop,
        neglog10_p_values = .-log10.(max.(table.p_values[order], p_floor_value)),
        p_floor = p_floor_value,
        target = table.target,
    )

    if hasproperty(table, :vanraden_scale)
        region = merge(region, (vanraden_scale = table.vanraden_scale,))
    end
    if hasproperty(table, :variance_components)
        region = merge(region, (variance_components = table.variance_components,))
    end
    if hasproperty(table, :marker_groups)
        region = merge(region, (marker_groups = table.marker_groups[order],))
    end

    return region
end

function _checked_optional_region_bound(value, field::Symbol)
    value === nothing && return nothing
    bound = _checked_real_scalar(value, field)
    isfinite(bound) && bound >= 0 ||
        throw(ArgumentError("$(field) must be finite and non-negative"))
    return bound
end

function _checked_region_flank(flank::Real)
    flank_value = Float64(flank)
    isfinite(flank_value) && flank_value >= 0 ||
        throw(ArgumentError("flank must be finite and non-negative"))
    return flank_value
end

function _checked_marker_alpha(alpha)
    alpha_value = _checked_real_scalar(alpha, :alpha)
    isfinite(alpha_value) && 0 < alpha_value <= 1 ||
        throw(ArgumentError("alpha must be finite and in (0, 1]"))
    return alpha_value
end

function _marker_map_order_for_scan(marker_ids::Vector{String}, marker_spec::HSMarkerMapSpec)
    duplicate_scan_ids = _duplicate_string_ids(marker_ids)
    isempty(duplicate_scan_ids) ||
        throw(ArgumentError("scan marker_ids must be unique when matching a marker map: $(join(duplicate_scan_ids, ", "))"))

    missing_from_map = _ordered_setdiff(marker_ids, marker_spec.marker_ids)
    missing_from_scan = _ordered_setdiff(marker_spec.marker_ids, marker_ids)
    if !isempty(missing_from_map) || !isempty(missing_from_scan)
        details = String[]
        isempty(missing_from_map) || push!(details, "missing from marker map: $(join(missing_from_map, ", "))")
        isempty(missing_from_scan) || push!(details, "missing from scan: $(join(missing_from_scan, ", "))")
        throw(ArgumentError("scan marker_ids must match marker map IDs exactly; $(join(details, "; "))"))
    end

    marker_index = Dict(id => i for (i, id) in pairs(marker_spec.marker_ids))
    return [marker_index[id] for id in marker_ids]
end

"""
    marker_qq_data(scan; p_floor = floatmin(Float64))

Prepare plot-ready QQ data from a direct [`single_marker_scan`](@ref) result.

The helper sorts observed p-values from smallest to largest and returns the
paired expected uniform order-statistic p-values, raw and sorted p-values,
marker IDs, sorted marker IDs, `-log10` observed and expected values, the sort
order, and the display p-value floor. Zero p-values are floored only for
display values; raw p-values are preserved.

This is a data-preparation helper only. It does not draw a plot, estimate
genomic inflation, calibrate p-values, run a mixed-model marker scan, or
activate the R-facing `marker_scan()` formula term.
"""
function marker_qq_data(scan; p_floor::Real = floatmin(Float64))
    marker_ids, p_values = _scan_marker_ids_and_p_values(scan)
    p_floor_value = Float64(p_floor)
    isfinite(p_floor_value) && 0 < p_floor_value <= 1 ||
        throw(ArgumentError("p_floor must be finite and in (0, 1]"))

    order = sortperm(collect(eachindex(p_values)); by = i -> (p_values[i], i))
    sorted_p_values = p_values[order]
    m = length(sorted_p_values)
    expected_p_values = collect(1:m) ./ (m + 1)

    return (
        marker_ids = marker_ids,
        p_values = p_values,
        sorted_marker_ids = marker_ids[order],
        sorted_p_values = sorted_p_values,
        expected_p_values = expected_p_values,
        observed_neglog10_p_values = .-log10.(max.(sorted_p_values, p_floor_value)),
        expected_neglog10_p_values = .-log10.(expected_p_values),
        order = order,
        p_floor = p_floor_value,
    )
end

const _CHISQ1_MEDIAN = 0.454936423119572

"""
    marker_genomic_inflation(scan; expected_median = 0.454936423119572)

Compute a genomic-control-style inflation diagnostic from a direct marker-scan
result.

The helper expects a `chisq` field such as the one returned by
[`single_marker_scan`](@ref), [`mixed_model_marker_scan`](@ref), or
[`loco_mixed_model_marker_scan`](@ref). It returns a compact `NamedTuple` with
`lambda_gc = median(chisq) / expected_median`, the observed median chi-square,
the expected median, the number of markers, and the scan target when available.
The default expected median is the 0.5 quantile of a one-degree-of-freedom
chi-square distribution.

This is a diagnostic summary only. It does not calibrate p-values, correct the
scan statistics, choose genome-wide thresholds, or activate R-facing
`marker_scan()` syntax.
"""
function marker_genomic_inflation(scan; expected_median::Real = _CHISQ1_MEDIAN)
    hasproperty(scan, :chisq) ||
        throw(ArgumentError("scan must have a chisq field"))
    values = Float64.(collect(getproperty(scan, :chisq)))
    !isempty(values) ||
        throw(ArgumentError("chisq values must be non-empty"))
    all(x -> isfinite(x) && x >= 0, values) ||
        throw(ArgumentError("chisq values must be finite and non-negative"))

    expected = Float64(expected_median)
    isfinite(expected) && expected > 0 ||
        throw(ArgumentError("expected_median must be positive and finite"))

    median_chisq = _median_float(values)
    target = hasproperty(scan, :target) ? getproperty(scan, :target) : :direct_marker_scan
    return (
        lambda_gc = median_chisq / expected,
        median_chisq = median_chisq,
        expected_median = expected,
        n_markers = length(values),
        target = target,
    )
end

"""
    marker_significance_summary(scan; alpha = 0.05)

Summarize nominal marker hits from a direct marker-scan result.

The helper expects the scan fields returned by [`single_marker_scan`](@ref),
[`mixed_model_marker_scan`](@ref), or [`loco_mixed_model_marker_scan`](@ref):
marker IDs, raw p-values, Bonferroni-adjusted p-values,
Benjamini-Hochberg q-values, chi-square values, and LOD-equivalent scores. It
returns per-marker significance flags, counts, marker IDs and scan indices for
raw, Bonferroni, and BH summaries, plus the top marker by raw p-value.

The thresholds are nominal summaries over the markers already present in the
scan: raw `p <= alpha`, Bonferroni raw-p threshold `alpha / m`, adjusted
Bonferroni `p_adj <= alpha`, and BH `q <= alpha`. This helper does not
calibrate correlated-marker genome-wide thresholds, estimate effective marker
counts, correct p-values, choose public GWAS/QTL thresholds, draw plots, or
activate R-facing `marker_scan()` syntax.
"""
function marker_significance_summary(scan; alpha = 0.05)
    alpha_value = _checked_marker_alpha(alpha)
    marker_ids, p_values = _scan_marker_ids_and_p_values(scan)
    m = length(marker_ids)
    bonferroni_p_values = _checked_scan_p_value_field(scan, :bonferroni_p_values, m)
    bh_q_values = _checked_scan_p_value_field(scan, :bh_q_values, m)
    chisq = _checked_scan_float_field(scan, :chisq, m; nonnegative = true)
    lod_scores = _checked_scan_float_field(scan, :lod_scores, m; nonnegative = true)

    raw_flags = collect(p_values .<= alpha_value)
    bonferroni_flags = collect(bonferroni_p_values .<= alpha_value)
    bh_flags = collect(bh_q_values .<= alpha_value)
    scan_indices = collect(1:m)
    top_index = first(sortperm(scan_indices; by = i -> (p_values[i], i)))
    target = hasproperty(scan, :target) ? getproperty(scan, :target) : :direct_marker_scan

    return (
        marker_count = m,
        alpha = alpha_value,
        nominal_p_threshold = alpha_value,
        bonferroni_raw_p_threshold = alpha_value / m,
        adjusted_p_threshold = alpha_value,
        bh_q_threshold = alpha_value,
        raw_significant = raw_flags,
        bonferroni_significant = bonferroni_flags,
        bh_significant = bh_flags,
        n_raw_significant = count(identity, raw_flags),
        n_bonferroni_significant = count(identity, bonferroni_flags),
        n_bh_significant = count(identity, bh_flags),
        raw_marker_ids = marker_ids[raw_flags],
        bonferroni_marker_ids = marker_ids[bonferroni_flags],
        bh_marker_ids = marker_ids[bh_flags],
        raw_scan_indices = scan_indices[raw_flags],
        bonferroni_scan_indices = scan_indices[bonferroni_flags],
        bh_scan_indices = scan_indices[bh_flags],
        min_p_value = minimum(p_values),
        min_bonferroni_p_value = minimum(bonferroni_p_values),
        min_bh_q_value = minimum(bh_q_values),
        max_chisq = maximum(chisq),
        max_lod_score = maximum(lod_scores),
        top_marker_id = marker_ids[top_index],
        top_scan_index = top_index,
        top_p_value = p_values[top_index],
        top_bonferroni_p_value = bonferroni_p_values[top_index],
        top_bh_q_value = bh_q_values[top_index],
        top_chisq = chisq[top_index],
        top_lod_score = lod_scores[top_index],
        target = target,
    )
end

"""
    marker_scan_table(scan; total_variance = nothing)
    marker_scan_table(scan, marker_spec::HSMarkerMapSpec; ...)
    marker_scan_table(scan, data::HSData; ...)

Prepare a deterministic row-aligned marker-scan table from a direct scan result.

The helper expects the scan fields returned by [`single_marker_scan`](@ref),
[`mixed_model_marker_scan`](@ref), or [`loco_mixed_model_marker_scan`](@ref):
marker effects, standard errors, Wald statistics, chi-square values, p-values,
Bonferroni p-values, Benjamini-Hochberg q-values, LOD-equivalent scores,
denominators, and allele frequencies. It preserves the original scan order and
returns those vectors with `scan_indices`, the scan `target`, allele variances,
and marker-level variance contributions `2p(1-p) * effect^2`. If
`total_variance` is supplied, it also returns
`proportion_variance_explained = marker_variance / total_variance`.

When an already-validated [`HSMarkerMapSpec`](@ref) or [`HSData`](@ref) with
marker metadata is supplied, marker IDs must match exactly and chromosome /
position vectors are aligned to the scan order.

This is a direct Julia table-preparation helper only. It does not sort markers,
draw plots, calibrate p-values, choose thresholds, estimate marker-scan
variance components, activate R-facing `marker_scan()` syntax, or change the
bridge payload.
"""
function marker_scan_table(scan; total_variance = nothing)
    return _marker_scan_table(scan, nothing, nothing; total_variance = total_variance)
end

function marker_scan_table(
    scan,
    marker_spec::HSMarkerMapSpec;
    total_variance = nothing,
)
    marker_ids = _scan_marker_ids(scan)
    map_order = _marker_map_order_for_scan(marker_ids, marker_spec)
    return _marker_scan_table(
        scan,
        marker_spec.chromosome[map_order],
        marker_spec.position[map_order];
        total_variance = total_variance,
    )
end

function marker_scan_table(
    scan,
    data::HSData;
    total_variance = nothing,
)
    data.marker_spec !== nothing ||
        throw(ArgumentError("HSData must contain marker metadata"))
    return marker_scan_table(scan, data.marker_spec; total_variance = total_variance)
end

function _marker_scan_table(scan, chromosomes, positions; total_variance)
    marker_ids = _scan_marker_ids(scan)
    m = length(marker_ids)

    effects = _checked_scan_float_field(scan, :effects, m)
    standard_errors = _checked_scan_float_field(scan, :standard_errors, m; positive = true)
    z_scores = _checked_scan_float_field(scan, :z_scores, m)
    chisq = _checked_scan_float_field(scan, :chisq, m; nonnegative = true)
    p_values = _checked_scan_p_value_field(scan, :p_values, m)
    bonferroni_p_values = _checked_scan_p_value_field(scan, :bonferroni_p_values, m)
    bh_q_values = _checked_scan_p_value_field(scan, :bh_q_values, m)
    lod_scores = _checked_scan_float_field(scan, :lod_scores, m; nonnegative = true)
    denominators = _checked_scan_float_field(scan, :denominators, m; positive = true)
    allele_frequencies = _checked_scan_allele_frequencies(scan, m)
    allele_variances = 2 .* allele_frequencies .* (1 .- allele_frequencies)
    marker_variances = allele_variances .* effects .^ 2
    total = _checked_marker_total_variance(total_variance)
    proportions = total === nothing ? nothing : marker_variances ./ total
    target = hasproperty(scan, :target) ? getproperty(scan, :target) : :direct_marker_scan

    table = (
        marker_ids = marker_ids,
        scan_indices = collect(1:m),
        effects = effects,
        abs_effects = abs.(effects),
        standard_errors = standard_errors,
        z_scores = z_scores,
        chisq = chisq,
        p_values = p_values,
        bonferroni_p_values = bonferroni_p_values,
        bh_q_values = bh_q_values,
        lod_scores = lod_scores,
        denominators = denominators,
        allele_frequencies = allele_frequencies,
        allele_variances = allele_variances,
        marker_variances = marker_variances,
        proportion_variance_explained = proportions,
        total_variance = total,
        target = target,
    )

    if hasproperty(scan, :k)
        table = merge(table, (vanraden_scale = _checked_scan_scalar(scan, :k; nonnegative = true),))
    end
    if hasproperty(scan, :variance_components)
        table = merge(table, (variance_components = getproperty(scan, :variance_components),))
    end
    if hasproperty(scan, :marker_groups)
        table = merge(table, (marker_groups = _checked_scan_marker_groups(scan, m),))
    end

    chromosomes === nothing && positions === nothing && return table
    chromosome_values, position_values = _checked_marker_summary_metadata(chromosomes, positions, m)
    return merge(table, (chromosomes = chromosome_values, positions = position_values))
end

"""
    gwas_table(scan; trait = nothing, total_variance = nothing)
    gwas_table(scan, marker_spec::HSMarkerMapSpec; ...)
    gwas_table(scan, data::HSData; ...)

Prepare a GWAS-labelled table from an already-computed direct marker scan.

This is a semantic wrapper around [`marker_scan_table`](@ref): it preserves the
row-aligned marker scan fields and adds `analysis = :gwas`. If `trait` is
supplied, it is recorded as non-empty scalar table metadata. Existing scan
statistics, optional marker-map metadata, and optional variance proportions are
not recomputed.

This helper does not run a marker scan, estimate variance components, calibrate
p-values, choose genome-wide thresholds, activate R-facing `marker_scan()`
syntax, draw plots, or change the bridge payload.
"""
function gwas_table(scan; trait = nothing, total_variance = nothing)
    table = marker_scan_table(scan; total_variance = total_variance)
    return _marker_analysis_table(table, :gwas; trait = trait)
end

function gwas_table(
    scan,
    marker_spec::HSMarkerMapSpec;
    trait = nothing,
    total_variance = nothing,
)
    table = marker_scan_table(scan, marker_spec; total_variance = total_variance)
    return _marker_analysis_table(table, :gwas; trait = trait)
end

function gwas_table(
    scan,
    data::HSData;
    trait = nothing,
    total_variance = nothing,
)
    data.marker_spec !== nothing ||
        throw(ArgumentError("HSData must contain marker metadata"))
    return gwas_table(scan, data.marker_spec; trait = trait, total_variance = total_variance)
end

"""
    qtl_table(scan; trait = nothing, total_variance = nothing)
    qtl_table(scan, marker_spec::HSMarkerMapSpec; ...)
    qtl_table(scan, data::HSData; ...)

Prepare a QTL-labelled table from an already-computed direct marker scan.

This is a semantic wrapper around [`marker_scan_table`](@ref): it preserves the
row-aligned marker scan fields and adds `analysis = :qtl`. If `trait` is
supplied, it is recorded as non-empty scalar table metadata. The LOD-equivalent
scores are the scan's existing fixed-effect known-variance scores; no interval
mapping or mixed-model LOD workflow is performed here.

This helper does not run a marker scan, perform interval mapping, estimate
variance components, calibrate p-values, choose QTL thresholds, activate
R-facing `marker_scan()` / `qtl_scan()` syntax, draw plots, or change the bridge
payload.
"""
function qtl_table(scan; trait = nothing, total_variance = nothing)
    table = marker_scan_table(scan; total_variance = total_variance)
    return _marker_analysis_table(table, :qtl; trait = trait)
end

function qtl_table(
    scan,
    marker_spec::HSMarkerMapSpec;
    trait = nothing,
    total_variance = nothing,
)
    table = marker_scan_table(scan, marker_spec; total_variance = total_variance)
    return _marker_analysis_table(table, :qtl; trait = trait)
end

function qtl_table(
    scan,
    data::HSData;
    trait = nothing,
    total_variance = nothing,
)
    data.marker_spec !== nothing ||
        throw(ArgumentError("HSData must contain marker metadata"))
    return qtl_table(scan, data.marker_spec; trait = trait, total_variance = total_variance)
end

"""
    eqtl_table(scan; feature = nothing, total_variance = nothing)
    eqtl_table(scan, marker_spec::HSMarkerMapSpec; ...)
    eqtl_table(scan, data::HSData; ...)

Prepare an eQTL-labelled table from an already-computed direct marker scan.

This is a semantic wrapper around [`marker_scan_table`](@ref): it preserves the
row-aligned marker scan fields and adds `analysis = :eqtl`. If `feature` is
supplied, it is recorded as non-empty scalar table metadata for the expression
feature, gene, or transcript represented by the scan.

This helper does not run expression-wide scans, classify cis/trans windows,
join expression or annotation tables, estimate variance components, calibrate
p-values, activate R-facing `marker_scan()` / eQTL syntax, draw plots, or
change the bridge payload.
"""
function eqtl_table(scan; feature = nothing, total_variance = nothing)
    table = marker_scan_table(scan; total_variance = total_variance)
    return _marker_analysis_table(table, :eqtl; feature = feature)
end

function eqtl_table(
    scan,
    marker_spec::HSMarkerMapSpec;
    feature = nothing,
    total_variance = nothing,
)
    table = marker_scan_table(scan, marker_spec; total_variance = total_variance)
    return _marker_analysis_table(table, :eqtl; feature = feature)
end

function eqtl_table(
    scan,
    data::HSData;
    feature = nothing,
    total_variance = nothing,
)
    data.marker_spec !== nothing ||
        throw(ArgumentError("HSData must contain marker metadata"))
    return eqtl_table(scan, data.marker_spec; feature = feature, total_variance = total_variance)
end

function _marker_analysis_table(table, analysis::Symbol; trait = nothing, feature = nothing)
    analysis in (:gwas, :qtl, :eqtl) ||
        throw(ArgumentError("analysis must be :gwas, :qtl, or :eqtl"))

    result = merge(table, (analysis = analysis,))
    trait_label = _checked_optional_label(trait, :trait)
    feature_label = _checked_optional_label(feature, :feature)
    trait_label === nothing || (result = merge(result, (trait = trait_label,)))
    feature_label === nothing || (result = merge(result, (feature = feature_label,)))
    return result
end

function _checked_optional_label(value, field::Symbol)
    value === nothing && return nothing
    label = strip(string(value))
    !isempty(label) ||
        throw(ArgumentError("$(field) must be a non-empty value when supplied"))
    return label
end

"""
    marker_effects(scan; sort_by = :p_value, top_n = nothing,
                           decreasing = nothing)
    marker_effects(scan, marker_spec::HSMarkerMapSpec; ...)
    marker_effects(scan, data::HSData; ...)

Prepare a deterministic marker-effect summary from a direct marker-scan result.

The helper expects the scan fields returned by [`single_marker_scan`](@ref),
[`mixed_model_marker_scan`](@ref), or [`loco_mixed_model_marker_scan`](@ref):
marker effects, standard errors, Wald statistics, chi-square values, p-values,
Bonferroni p-values, Benjamini-Hochberg q-values, LOD-equivalent scores, and
denominators. It returns those fields sorted into a compact `NamedTuple` with
`scan_indices`, `sort_by`, `decreasing`, `top_n`, and the scan target when
available. Supported `sort_by` values are `:p_value`, `:bonferroni_p_value`,
`:bh_q_value`, `:chisq`, `:lod_score`, `:effect`, and `:abs_effect`; p-value
metrics sort ascending by default, while effect-size/statistic metrics sort
descending by default.

When an already-validated [`HSMarkerMapSpec`](@ref) or [`HSData`](@ref) with
marker metadata is supplied, marker IDs must match exactly and chromosome /
position vectors are aligned to the returned summary order.

This is a direct Julia summary helper only. It does not calibrate p-values,
choose thresholds, draw plots, activate R-facing `marker_scan()` syntax, or
change the bridge payload.
"""
function marker_effects(
    scan;
    sort_by::Symbol = :p_value,
    top_n = nothing,
    decreasing::Union{Nothing,Bool} = nothing,
)
    return _marker_effects(
        scan,
        nothing,
        nothing;
        sort_by = sort_by,
        top_n = top_n,
        decreasing = decreasing,
    )
end

function marker_effects(
    scan,
    marker_spec::HSMarkerMapSpec;
    sort_by::Symbol = :p_value,
    top_n = nothing,
    decreasing::Union{Nothing,Bool} = nothing,
)
    marker_ids, _ = _scan_marker_ids_and_p_values(scan)
    map_order = _marker_map_order_for_scan(marker_ids, marker_spec)
    return _marker_effects(
        scan,
        marker_spec.chromosome[map_order],
        marker_spec.position[map_order];
        sort_by = sort_by,
        top_n = top_n,
        decreasing = decreasing,
    )
end

function marker_effects(
    scan,
    data::HSData;
    sort_by::Symbol = :p_value,
    top_n = nothing,
    decreasing::Union{Nothing,Bool} = nothing,
)
    data.marker_spec !== nothing ||
        throw(ArgumentError("HSData must contain marker metadata"))
    return marker_effects(
        scan,
        data.marker_spec;
        sort_by = sort_by,
        top_n = top_n,
        decreasing = decreasing,
    )
end

"""
    marker_variance_explained(scan; total_variance = nothing,
                              sort_by = :marker_variance, top_n = nothing,
                              decreasing = nothing)
    marker_variance_explained(scan, marker_spec::HSMarkerMapSpec; ...)
    marker_variance_explained(scan, data::HSData; ...)

Prepare deterministic marker-level variance-contribution summaries from a
direct marker-scan result.

The helper expects scan `marker_ids`, marker `effects`, and allele frequencies
`p` such as those returned by [`single_marker_scan`](@ref),
[`mixed_model_marker_scan`](@ref), or [`loco_mixed_model_marker_scan`](@ref).
For each biallelic marker it computes `2p(1-p) * effect^2`. If
`total_variance` is supplied, it also returns
`proportion_variance_explained = marker_variance / total_variance`. Supported
`sort_by` values are `:marker_variance`, `:proportion_variance_explained`,
`:allele_variance`, `:effect`, `:abs_effect`, and `:p_value`; p-value sorting
requires a scan `p_values` field. Variance and effect-size metrics sort
descending by default, while p-values sort ascending.

When an already-validated [`HSMarkerMapSpec`](@ref) or [`HSData`](@ref) with
marker metadata is supplied, marker IDs must match exactly and chromosome /
position vectors are aligned to the returned summary order.

This is a direct Julia summary helper only. It does not estimate marker-scan
variance components, calibrate p-values, claim calibrated PVE/model R², choose
thresholds, draw plots, activate R-facing `marker_scan()` syntax, or change the
bridge payload.
"""
function marker_variance_explained(
    scan;
    total_variance = nothing,
    sort_by::Symbol = :marker_variance,
    top_n = nothing,
    decreasing::Union{Nothing,Bool} = nothing,
)
    return _marker_variance_explained(
        scan,
        nothing,
        nothing;
        total_variance = total_variance,
        sort_by = sort_by,
        top_n = top_n,
        decreasing = decreasing,
    )
end

function marker_variance_explained(
    scan,
    marker_spec::HSMarkerMapSpec;
    total_variance = nothing,
    sort_by::Symbol = :marker_variance,
    top_n = nothing,
    decreasing::Union{Nothing,Bool} = nothing,
)
    marker_ids = _scan_marker_ids(scan)
    map_order = _marker_map_order_for_scan(marker_ids, marker_spec)
    return _marker_variance_explained(
        scan,
        marker_spec.chromosome[map_order],
        marker_spec.position[map_order];
        total_variance = total_variance,
        sort_by = sort_by,
        top_n = top_n,
        decreasing = decreasing,
    )
end

function marker_variance_explained(
    scan,
    data::HSData;
    total_variance = nothing,
    sort_by::Symbol = :marker_variance,
    top_n = nothing,
    decreasing::Union{Nothing,Bool} = nothing,
)
    data.marker_spec !== nothing ||
        throw(ArgumentError("HSData must contain marker metadata"))
    return marker_variance_explained(
        scan,
        data.marker_spec;
        total_variance = total_variance,
        sort_by = sort_by,
        top_n = top_n,
        decreasing = decreasing,
    )
end

function _marker_variance_explained(
    scan,
    chromosomes,
    positions;
    total_variance,
    sort_by::Symbol,
    top_n,
    decreasing::Union{Nothing,Bool},
)
    marker_ids = _scan_marker_ids(scan)
    m = length(marker_ids)

    effects = _checked_scan_float_field(scan, :effects, m)
    allele_frequencies = _checked_scan_allele_frequencies(scan, m)
    allele_variances = 2 .* allele_frequencies .* (1 .- allele_frequencies)
    marker_variances = allele_variances .* effects .^ 2
    total = _checked_marker_total_variance(total_variance)
    proportions = total === nothing ? nothing : marker_variances ./ total
    p_values = hasproperty(scan, :p_values) ?
        _checked_scan_p_value_field(scan, :p_values, m) :
        nothing

    metric, canonical_sort_by, default_decreasing = _marker_variance_sort_metric(
        sort_by,
        effects,
        allele_variances,
        marker_variances,
        proportions,
        p_values,
    )
    decreasing_value = decreasing === nothing ? default_decreasing : decreasing
    order_all = if decreasing_value
        sortperm(collect(1:m); by = i -> (-metric[i], i))
    else
        sortperm(collect(1:m); by = i -> (metric[i], i))
    end

    top_count = _checked_top_n(top_n, m)
    order = order_all[1:top_count]
    target = hasproperty(scan, :target) ? getproperty(scan, :target) : :direct_marker_scan

    summary = (
        marker_ids = marker_ids[order],
        effects = effects[order],
        abs_effects = abs.(effects[order]),
        allele_frequencies = allele_frequencies[order],
        allele_variances = allele_variances[order],
        marker_variances = marker_variances[order],
        proportion_variance_explained = proportions === nothing ? nothing : proportions[order],
        total_variance = total,
        scan_indices = order,
        sort_by = canonical_sort_by,
        decreasing = decreasing_value,
        top_n = top_count,
        target = target,
    )
    p_values === nothing || (summary = merge(summary, (p_values = p_values[order],)))

    chromosomes === nothing && positions === nothing && return summary
    chromosome_values, position_values = _checked_marker_summary_metadata(chromosomes, positions, m)
    return merge(
        summary,
        (
            chromosomes = chromosome_values[order],
            positions = position_values[order],
        ),
    )
end

function _checked_scan_allele_frequencies(scan, n::Int)
    hasproperty(scan, :p) ||
        throw(ArgumentError("scan must have a p field"))
    return _checked_allele_frequencies(getproperty(scan, :p), n)
end

function _checked_allele_frequencies(values, n::Int)
    allele_frequencies = Float64.(collect(values))
    length(allele_frequencies) == n ||
        throw(ArgumentError("p must have one entry per marker"))
    all(p -> isfinite(p) && 0 <= p <= 1, allele_frequencies) ||
        throw(ArgumentError("p values must be finite allele frequencies in [0, 1]"))
    return allele_frequencies
end

function _checked_marker_total_variance(total_variance)
    total_variance === nothing && return nothing
    total = _checked_real_scalar(total_variance, :total_variance)
    isfinite(total) && total > 0 ||
        throw(ArgumentError("total_variance must be positive and finite"))
    return total
end

function _checked_scan_scalar(scan, field::Symbol; nonnegative::Bool = false)
    value = _checked_real_scalar(getproperty(scan, field), field)
    isfinite(value) ||
        throw(ArgumentError("$(field) must be finite"))
    if nonnegative
        value >= 0 ||
            throw(ArgumentError("$(field) must be non-negative"))
    end
    return value
end

function _checked_real_scalar(value, field::Symbol)
    try
        return Float64(value)
    catch
        throw(ArgumentError("$(field) must be numeric"))
    end
end

function _checked_scan_marker_groups(scan, n::Int)
    marker_groups = string.(collect(getproperty(scan, :marker_groups)))
    length(marker_groups) == n ||
        throw(ArgumentError("marker_groups must have one entry per marker"))
    all(!isempty, marker_groups) ||
        throw(ArgumentError("marker_groups cannot contain empty labels"))
    return marker_groups
end

function _marker_variance_sort_metric(
    sort_by::Symbol,
    effects::Vector{Float64},
    allele_variances::Vector{Float64},
    marker_variances::Vector{Float64},
    proportions,
    p_values,
)
    if sort_by in (:marker_variance, :marker_variances, :variance, :variance_explained)
        return marker_variances, :marker_variance, true
    elseif sort_by in (:proportion_variance_explained, :proportion, :pve)
        proportions !== nothing ||
            throw(ArgumentError("total_variance is required when sort_by is $(sort_by)"))
        return proportions, :proportion_variance_explained, true
    elseif sort_by in (:allele_variance, :allele_variances)
        return allele_variances, :allele_variance, true
    elseif sort_by == :effect
        return effects, :effect, true
    elseif sort_by in (:abs_effect, :abs_effects, :absolute_effect)
        return abs.(effects), :abs_effect, true
    elseif sort_by in (:p_value, :p_values, :p)
        p_values !== nothing ||
            throw(ArgumentError("scan must have a p_values field when sort_by is $(sort_by)"))
        return p_values, :p_value, false
    end
    throw(ArgumentError("unsupported sort_by value: $(sort_by)"))
end

function _marker_effects(
    scan,
    chromosomes,
    positions;
    sort_by::Symbol,
    top_n,
    decreasing::Union{Nothing,Bool},
)
    marker_ids, p_values = _scan_marker_ids_and_p_values(scan)
    m = length(marker_ids)

    effects = _checked_scan_float_field(scan, :effects, m)
    standard_errors = _checked_scan_float_field(scan, :standard_errors, m; positive = true)
    z_scores = _checked_scan_float_field(scan, :z_scores, m)
    chisq = _checked_scan_float_field(scan, :chisq, m; nonnegative = true)
    bonferroni_p_values = _checked_scan_p_value_field(scan, :bonferroni_p_values, m)
    bh_q_values = _checked_scan_p_value_field(scan, :bh_q_values, m)
    lod_scores = _checked_scan_float_field(scan, :lod_scores, m; nonnegative = true)
    denominators = _checked_scan_float_field(scan, :denominators, m; positive = true)

    metric, canonical_sort_by, default_decreasing = _marker_summary_sort_metric(
        sort_by,
        effects,
        chisq,
        p_values,
        bonferroni_p_values,
        bh_q_values,
        lod_scores,
    )
    decreasing_value = decreasing === nothing ? default_decreasing : decreasing
    order_all = if decreasing_value
        sortperm(collect(1:m); by = i -> (-metric[i], i))
    else
        sortperm(collect(1:m); by = i -> (metric[i], i))
    end

    top_count = _checked_top_n(top_n, m)
    order = order_all[1:top_count]
    target = hasproperty(scan, :target) ? getproperty(scan, :target) : :direct_marker_scan

    summary = (
        marker_ids = marker_ids[order],
        effects = effects[order],
        abs_effects = abs.(effects[order]),
        standard_errors = standard_errors[order],
        z_scores = z_scores[order],
        chisq = chisq[order],
        p_values = p_values[order],
        bonferroni_p_values = bonferroni_p_values[order],
        bh_q_values = bh_q_values[order],
        lod_scores = lod_scores[order],
        denominators = denominators[order],
        scan_indices = order,
        sort_by = canonical_sort_by,
        decreasing = decreasing_value,
        top_n = top_count,
        target = target,
    )

    chromosomes === nothing && positions === nothing && return summary
    chromosome_values, position_values = _checked_marker_summary_metadata(chromosomes, positions, m)
    return merge(
        summary,
        (
            chromosomes = chromosome_values[order],
            positions = position_values[order],
        ),
    )
end

function _checked_scan_float_field(scan, field::Symbol, n::Int; nonnegative::Bool = false, positive::Bool = false)
    hasproperty(scan, field) ||
        throw(ArgumentError("scan must have a $(field) field"))
    values = Float64.(collect(getproperty(scan, field)))
    length(values) == n ||
        throw(ArgumentError("$(field) must have one entry per marker"))
    all(isfinite, values) ||
        throw(ArgumentError("$(field) values must be finite"))
    if positive
        all(>(0), values) ||
            throw(ArgumentError("$(field) values must be positive"))
    elseif nonnegative
        all(>=(0), values) ||
            throw(ArgumentError("$(field) values must be non-negative"))
    end
    return values
end

function _checked_scan_p_value_field(scan, field::Symbol, n::Int)
    hasproperty(scan, field) ||
        throw(ArgumentError("scan must have a $(field) field"))
    values = _checked_p_values(getproperty(scan, field))
    length(values) == n ||
        throw(ArgumentError("$(field) must have one entry per marker"))
    return values
end

function _marker_summary_sort_metric(
    sort_by::Symbol,
    effects::Vector{Float64},
    chisq::Vector{Float64},
    p_values::Vector{Float64},
    bonferroni_p_values::Vector{Float64},
    bh_q_values::Vector{Float64},
    lod_scores::Vector{Float64},
)
    if sort_by in (:p_value, :p_values, :p)
        return p_values, :p_value, false
    elseif sort_by in (:bonferroni_p_value, :bonferroni_p_values, :bonferroni)
        return bonferroni_p_values, :bonferroni_p_value, false
    elseif sort_by in (:bh_q_value, :bh_q_values, :q_value, :q_values)
        return bh_q_values, :bh_q_value, false
    elseif sort_by in (:chisq, :chi_square, :chi_square_statistic)
        return chisq, :chisq, true
    elseif sort_by in (:lod_score, :lod_scores, :lod)
        return lod_scores, :lod_score, true
    elseif sort_by == :effect
        return effects, :effect, true
    elseif sort_by in (:abs_effect, :abs_effects, :absolute_effect)
        return abs.(effects), :abs_effect, true
    end
    throw(ArgumentError("unsupported sort_by value: $(sort_by)"))
end

function _checked_top_n(top_n, n::Int)
    top_n === nothing && return n
    top_n isa Integer ||
        throw(ArgumentError("top_n must be an integer or nothing"))
    1 <= top_n <= n ||
        throw(ArgumentError("top_n must be between 1 and the number of markers"))
    return Int(top_n)
end

function _checked_marker_summary_metadata(chromosomes, positions, n::Int)
    (chromosomes !== nothing && positions !== nothing) ||
        throw(ArgumentError("chromosomes and positions must be supplied together"))
    chromosome_values = string.(collect(chromosomes))
    length(chromosome_values) == n ||
        throw(ArgumentError("chromosomes must have one entry per marker"))
    all(!isempty, chromosome_values) ||
        throw(ArgumentError("chromosomes cannot contain empty labels"))
    position_values = Float64.(collect(positions))
    length(position_values) == n ||
        throw(ArgumentError("positions must have one entry per marker"))
    all(x -> isfinite(x) && x >= 0, position_values) ||
        throw(ArgumentError("positions must be finite and non-negative"))
    return chromosome_values, position_values
end

function _median_float(values::Vector{Float64})
    sorted_values = sort(values)
    n = length(sorted_values)
    middle = n ÷ 2
    return isodd(n) ? sorted_values[middle + 1] :
           (sorted_values[middle] + sorted_values[middle + 1]) / 2
end

# Abramowitz-Stegun 7.1.26 approximation to Phi(z). Maximum absolute error is
# about 7.5e-8, enough for deterministic fixed-effect scan diagnostics without
# adding a statistics dependency.
function _standard_normal_cdf_approx(z::Real)
    x = Float64(z)
    isfinite(x) || throw(ArgumentError("z must be finite"))
    x == 0 && return 0.5
    t = 1 / (1 + 0.2316419 * abs(x))
    poly = (((((1.330274429 * t - 1.821255978) * t + 1.781477937) * t -
              0.356563782) * t + 0.319381530) * t)
    upper = exp(-0.5 * x^2) * inv(sqrt(2 * pi)) * poly
    cdf = x >= 0 ? 1 - upper : upper
    return clamp(cdf, 0.0, 1.0)
end

function _standard_normal_two_sided_pvalue(z::Real)
    x = Float64(z)
    isfinite(x) || throw(ArgumentError("z must be finite"))
    # Preserve the established central approximation used by cross-language
    # fixtures, taking the small tail directly to keep sign symmetry. At |z| ≥ 8
    # its relative tail error matters, so use Z² ~ χ²₁ and the existing accurate
    # upper-gamma tail instead of subtracting a CDF from one.
    abs(x) < 8 && return clamp(2 * _standard_normal_cdf_approx(-abs(x)), 0.0, 1.0)
    squared = x * x
    isinf(squared) && return 0.0   # finite |z| this large has an underflowed tail
    return clamp(_chisq_sf(squared, 1.0), 0.0, 1.0)
end

function _checked_p_values(p_values)
    values = Float64.(p_values)
    !isempty(values) || throw(ArgumentError("p_values must be non-empty"))
    all(p -> isfinite(p) && 0 <= p <= 1, values) ||
        throw(ArgumentError("p_values must be finite values in [0, 1]"))
    return values
end

function _bonferroni_adjust(p_values)
    values = _checked_p_values(p_values)
    m = length(values)
    return clamp.(m .* values, 0.0, 1.0)
end

function _benjamini_hochberg_adjust(p_values)
    values = _checked_p_values(p_values)
    m = length(values)
    order = sortperm(values)
    sorted_values = values[order]
    sorted_adjusted = similar(sorted_values)
    running_min = 1.0
    for i in m:-1:1
        running_min = min(running_min, sorted_values[i] * m / i)
        sorted_adjusted[i] = clamp(running_min, 0.0, 1.0)
    end
    adjusted = similar(values)
    adjusted[order] = sorted_adjusted
    return adjusted
end

"""
    _single_step_Hinv(Ainv, A, G, genotyped_rows; tau = 1.0, omega = 1.0,
                      blend_weight = 0.0, ridge = 0.0)

Single-step genomic relationship inverse `H⁻¹` (Aguilar et al. 2010;
Christensen & Lund 2009):

    H⁻¹ = A⁻¹ + scatter(τ·Gʷ⁻¹ − ω·A₂₂⁻¹)  over the genotyped rows `g`,

where `Ainv` is the pedigree inverse `A⁻¹`, `A` the dense pedigree relationship
matrix, `A₂₂ = A[g, g]` the block among the genotyped animals (in sorted
pedigree-row order), and `Gʷ = (1 − blend_weight)·G + blend_weight·A₂₂` the
optionally blended/ridged genomic relationship among them.

Critically, `A₂₂⁻¹` is the inverse of the *submatrix* `A[g, g]`, **not** the
submatrix `(A⁻¹)[g, g]` — the two differ.

Internal validation-only construction utility: dense, not exported, and **not**
wired into fitting. The `blend_weight` / `tau` / `omega` / `ridge` knobs are not
comparator-validated; defaults are `blend_weight = ridge = 0`, `tau = omega = 1`.
"""
function _single_step_Hinv(
    Ainv::AbstractMatrix,
    A::AbstractMatrix,
    G::AbstractMatrix,
    genotyped_rows::AbstractVector{<:Integer};
    tau::Real = 1.0,
    omega::Real = 1.0,
    blend_weight::Real = 0.0,
    ridge::Real = 0.0,
)
    n = size(Ainv, 1)
    size(Ainv, 2) == n || throw(ArgumentError("Ainv must be square"))
    size(A) == (n, n) || throw(ArgumentError("A must match Ainv dimensions"))
    g = collect(genotyped_rows)
    ng = length(g)
    all(r -> 1 <= r <= n, g) ||
        throw(ArgumentError("genotyped_rows must be valid row indices of Ainv"))
    length(unique(g)) == ng ||
        throw(ArgumentError("genotyped_rows must be unique"))
    size(G) == (ng, ng) ||
        throw(ArgumentError("G must be square of size length(genotyped_rows)"))

    tau_f, omega_f = Float64(tau), Float64(omega)
    blend_f, ridge_f = Float64(blend_weight), Float64(ridge)
    all(isfinite, (tau_f, omega_f, blend_f, ridge_f)) ||
        throw(ArgumentError("tau, omega, blend_weight, and ridge must be finite"))
    tau_f > 0 || throw(ArgumentError("tau must be positive"))
    omega_f >= 0 || throw(ArgumentError("omega must be non-negative"))
    0 <= blend_f <= 1 || throw(ArgumentError("blend_weight must be in [0, 1]"))
    ridge_f >= 0 || throw(ArgumentError("ridge must be non-negative"))

    Ainv_f = _single_step_symmetric_finite_matrix(Ainv, "Ainv")
    A_f = _single_step_symmetric_finite_matrix(A, "A")
    G_f = _single_step_symmetric_finite_matrix(G, "G")
    isposdef(Symmetric(Ainv_f)) ||
        throw(ArgumentError("Ainv must be positive definite"))
    isposdef(Symmetric(A_f)) ||
        throw(ArgumentError("A must be positive definite"))

    A22 = A_f[g, g]
    A22inv = inv(Symmetric(A22))                     # inverse of the SUBMATRIX of A
    Gblend = (1 - blend_f) .* G_f .+ blend_f .* A22
    Greg = Symmetric(Gblend + ridge_f * I)
    isposdef(Greg) ||
        throw(ArgumentError("genotyped genomic block is not positive definite; increase ridge or blend_weight"))
    Gwinv = inv(Greg)

    Hinv = Ainv_f
    Hinv[g, g] = Hinv[g, g] .+ (tau_f .* Gwinv .- omega_f .* A22inv)
    all(isfinite, Hinv) && isposdef(Symmetric(Hinv)) ||
        throw(ArgumentError("single-step precision must be finite and positive definite"))
    return Hinv
end

function _single_step_symmetric_finite_matrix(M::AbstractMatrix, name::AbstractString)
    result = Matrix{Float64}(M)
    all(isfinite, result) || throw(ArgumentError("$(name) must contain only finite values"))
    n = size(result, 1)
    for j in 2:n, i in 1:(j - 1)
        upper, lower = result[i, j], result[j, i]
        pair_scale = max(abs(upper), abs(lower))
        abs(upper - lower) <= 1e-10 * pair_scale ||
            throw(ArgumentError("$(name) must be symmetric"))
        midpoint = upper / 2 + lower / 2
        result[i, j] = midpoint
        result[j, i] = midpoint
    end
    return result
end

"""
    single_step_inverse(Ainv, A, G, genotyped_rows; tau = 1.0, omega = 1.0,
                        blend_weight = 0.0, ridge = 0.0)

Single-step genomic relationship inverse `H⁻¹` (Aguilar et al. 2010; Christensen
& Lund 2009): `H⁻¹ = A⁻¹ + scatter(τ·Gʷ⁻¹ − ω·A₂₂⁻¹)` over the genotyped rows,
where `A₂₂ = A[g, g]` is the pedigree block among the genotyped animals (NOT
`(A⁻¹)[g, g]`) and `Gʷ = (1 − blend_weight)·G + blend_weight·A₂₂` is the optionally
blended/ridged genomic block. When `G = A₂₂`, `H⁻¹` reduces exactly to `A⁻¹`.

`Ainv` is the pedigree inverse `A⁻¹`, `A` the dense pedigree relationship matrix,
`G` the genomic relationship among the `genotyped_rows` (in sorted pedigree-row
order). The result is the relationship PRECISION for the single-step animal model
— pass it where [`fit_gblup`](@ref) takes `Ginv`, or use [`fit_single_step`](@ref).

Inputs must be finite and symmetric; `A` and `Ainv` must be positive definite,
and `genotyped_rows` must contain unique valid indices. Require `tau > 0`,
`omega ≥ 0`, `blend_weight ∈ [0, 1]`, and `ridge ≥ 0`; the returned precision
must also be positive definite.

Experimental, dense/validation-scale. The `blend_weight`/`tau`/`omega`/`ridge`
knobs are not comparator-validated (defaults `blend_weight = ridge = 0`,
`tau = omega = 1`); a singular raw `G` requires blending/ridging.
"""
single_step_inverse(Ainv::AbstractMatrix, A::AbstractMatrix, G::AbstractMatrix,
                    genotyped_rows::AbstractVector{<:Integer}; kwargs...) =
    _single_step_Hinv(Ainv, A, G, genotyped_rows; kwargs...)

"""
    fit_single_step(y, X, Z, Ainv, A, G, genotyped_rows, sigma_a2, sigma_e2;
                    tau = 1.0, omega = 1.0, blend_weight = 0.0, ridge = 0.0, ids = nothing)

Single-step GBLUP at supplied variance components: build the single-step
relationship inverse `H⁻¹` ([`single_step_inverse`](@ref)) and solve the Gaussian
animal model with `H⁻¹` as the relationship precision (via [`fit_gblup`](@ref)).
When `G = A₂₂` it reproduces the pedigree animal model exactly. Experimental,
dense/validation-scale; supplied-variance.
"""
function fit_single_step(
    y::AbstractVector, X::AbstractMatrix, Z::AbstractMatrix,
    Ainv::AbstractMatrix, A::AbstractMatrix, G::AbstractMatrix,
    genotyped_rows::AbstractVector{<:Integer}, sigma_a2::Real, sigma_e2::Real;
    tau::Real = 1.0, omega::Real = 1.0, blend_weight::Real = 0.0, ridge::Real = 0.0,
    ids = nothing,
)
    Hinv = _single_step_Hinv(Ainv, A, G, genotyped_rows;
                             tau = tau, omega = omega, blend_weight = blend_weight, ridge = ridge)
    return fit_gblup(y, X, Z, Hinv, sigma_a2, sigma_e2; ids = ids)
end

"""
    fit_single_step_reml(y, X, Z, Ainv, A, G, genotyped_rows;
                         tau = 1.0, omega = 1.0, blend_weight = 0.0, ridge = 0.0,
                         initial = (sigma_a2 = 1.0, sigma_e2 = 1.0), target = :ai_reml,
                         iterations = nothing, ids = nothing)

Single-step GBLUP with REML-estimated variance components: build `H⁻¹`
([`single_step_inverse`](@ref)) and estimate `(sigma_a2, sigma_e2)` by REML on the
single-step spec (via [`fit_gblup_reml`](@ref)). When `G = A₂₂` it reproduces the
pedigree-REML optimum. Experimental, dense/validation-scale.

`iterations` (hsquared#212) forwards to [`fit_gblup_reml`](@ref) (and from there
to the `target` optimizer). Default `nothing` is byte-identical to the
pre-#212-fix call (this keyword did not previously exist).
"""
function fit_single_step_reml(
    y::AbstractVector, X::AbstractMatrix, Z::AbstractMatrix,
    Ainv::AbstractMatrix, A::AbstractMatrix, G::AbstractMatrix,
    genotyped_rows::AbstractVector{<:Integer};
    tau::Real = 1.0, omega::Real = 1.0, blend_weight::Real = 0.0, ridge::Real = 0.0,
    initial = (sigma_a2 = 1.0, sigma_e2 = 1.0), target::Symbol = :ai_reml,
    iterations::Union{Nothing,Integer} = nothing, ids = nothing,
)
    Hinv = _single_step_Hinv(Ainv, A, G, genotyped_rows;
                             tau = tau, omega = omega, blend_weight = blend_weight, ridge = ridge)
    return fit_gblup_reml(y, X, Z, Hinv; initial = initial, target = target,
                          iterations = iterations, ids = ids)
end

"""
    metafounder_single_step_inverse(pedigree, group_of, Gamma, G, genotyped_rows; ...)
    metafounder_single_step_inverse(ids, sire, dam, group_of, Gamma, G, genotyped_rows; ...)

Dense validation-scale single-step relationship precision `H^Γ⁻¹`: build the
animal-only metafounder relationship `A^Γ` from supplied `Gamma`, then apply the
ordinary single-step update

```math
H^Γ⁻¹ = (A^Γ)⁻¹ + scatter(τ·G_w⁻¹ - ω·(A^Γ₂₂)⁻¹)
```

over `genotyped_rows`. `group_of` is aligned to `pedigree.ids`; `Gamma` is
supplied and not estimated. At `Gamma = 0` this reduces to
[`single_step_inverse`](@ref) with the classical pedigree relationship.

For the raw-array overload, `group_of` and `genotyped_rows` use the original
`ids` row order. The wrapper maps them to the normalized pedigree order;
`G` stays in the same order as the supplied `genotyped_rows` vector.

Experimental and dense/validation-scale. The `blend_weight`/`tau`/`omega`/`ridge`
knobs inherit the ordinary single-step caveat: defaults are not
comparator-validated.
"""
function metafounder_single_step_inverse(
    pedigree::Pedigree, group_of, Gamma::AbstractMatrix, G::AbstractMatrix,
    genotyped_rows::AbstractVector{<:Integer};
    tau::Real = 1.0, omega::Real = 1.0, blend_weight::Real = 0.0, ridge::Real = 0.0,
    max_relationship_cache::Integer = 10_000,
)
    Aγ = metafounder_relationship(pedigree, group_of, Gamma;
                                  max_relationship_cache = max_relationship_cache)
    Aγinv = metafounder_relationship_inverse(pedigree, group_of, Gamma;
                                             max_relationship_cache = max_relationship_cache)
    return _single_step_Hinv(Aγinv, Aγ, G, genotyped_rows;
                             tau = tau, omega = omega,
                             blend_weight = blend_weight, ridge = ridge)
end

function metafounder_single_step_inverse(
    ids, sire, dam, group_of, Gamma::AbstractMatrix, G::AbstractMatrix,
    genotyped_rows::AbstractVector{<:Integer};
    missing_values = DEFAULT_UNKNOWN_PARENT_VALUES, allow_selfing::Bool = false,
    kwargs...,
)
    pedigree, groups = _normalize_metafounder_pedigree(
        ids, sire, dam, group_of; missing_values = missing_values,
        allow_selfing = allow_selfing)
    input_rows = collect(genotyped_rows)
    n = length(pedigree)
    all(i -> 1 <= i <= n, input_rows) ||
        throw(ArgumentError("genotyped_rows must index rows in the input pedigree"))
    normalized_rows = invperm(pedigree.original_order)[input_rows]
    return metafounder_single_step_inverse(
        pedigree, groups, Gamma, G, normalized_rows; kwargs...)
end

"""
    fit_metafounder_single_step(y, X, Z, pedigree, group_of, Gamma, G, genotyped_rows,
                                sigma_a2, sigma_e2; ...)

Supplied-variance single-step GBLUP under the supplied-`Γ` metafounder
relationship. This builds `H^Γ⁻¹` with [`metafounder_single_step_inverse`](@ref)
and delegates to [`fit_gblup`](@ref). Dense/validation-scale; variance
components and `Gamma` are inputs, not estimates.
"""
function fit_metafounder_single_step(
    y::AbstractVector, X::AbstractMatrix, Z::AbstractMatrix,
    pedigree::Pedigree, group_of, Gamma::AbstractMatrix, G::AbstractMatrix,
    genotyped_rows::AbstractVector{<:Integer}, sigma_a2::Real, sigma_e2::Real;
    tau::Real = 1.0, omega::Real = 1.0, blend_weight::Real = 0.0, ridge::Real = 0.0,
    max_relationship_cache::Integer = 10_000, ids = pedigree.ids,
)
    Hγinv = metafounder_single_step_inverse(pedigree, group_of, Gamma, G, genotyped_rows;
                                            tau = tau, omega = omega,
                                            blend_weight = blend_weight, ridge = ridge,
                                            max_relationship_cache = max_relationship_cache)
    return fit_gblup(y, X, Z, Hγinv, sigma_a2, sigma_e2; ids = ids)
end

"""
    fit_metafounder_single_step_reml(y, X, Z, pedigree, group_of, Gamma, G, genotyped_rows;
                                     iterations = nothing, ...)

REML-estimated variance components for the dense validation-scale
`H^Γ⁻¹` relationship precision. The metafounder covariance `Gamma` is supplied,
not estimated. External comparator parity and R-facing formula syntax remain
separate gates.

`iterations` (hsquared#212) forwards to [`fit_gblup_reml`](@ref). Default
`nothing` is byte-identical to the pre-#212-fix call (this keyword did not
previously exist).
"""
function fit_metafounder_single_step_reml(
    y::AbstractVector, X::AbstractMatrix, Z::AbstractMatrix,
    pedigree::Pedigree, group_of, Gamma::AbstractMatrix, G::AbstractMatrix,
    genotyped_rows::AbstractVector{<:Integer};
    tau::Real = 1.0, omega::Real = 1.0, blend_weight::Real = 0.0, ridge::Real = 0.0,
    max_relationship_cache::Integer = 10_000,
    initial = (sigma_a2 = 1.0, sigma_e2 = 1.0), target::Symbol = :ai_reml,
    iterations::Union{Nothing,Integer} = nothing, ids = pedigree.ids,
)
    Hγinv = metafounder_single_step_inverse(pedigree, group_of, Gamma, G, genotyped_rows;
                                            tau = tau, omega = omega,
                                            blend_weight = blend_weight, ridge = ridge,
                                            max_relationship_cache = max_relationship_cache)
    return fit_gblup_reml(y, X, Z, Hγinv; initial = initial, target = target,
                          iterations = iterations, ids = ids)
end

# ---------------------------------------------------------------------------
# Genome-wide significance threshold machinery (#48).
#
# Deterministic, RNG-FREE machinery that turns an empirical NULL distribution of
# per-scan maximum statistics (the max over markers, which is correlation/LD-aware
# because the markers are scanned jointly) into a genome-wide threshold at level
# alpha and an empirical genome-wide p-value. The null distribution itself is
# produced by phenotype-permutation / null-resimulation — that RNG-heavy step lives
# in the opt-in `sim/phase5_threshold_calibration.jl` harness (outside CI), exactly
# like the other recovery harnesses; this package layer is the deterministic,
# unit-tested core. EXPERIMENTAL, validation-scale: this is NOT a production
# genome-wide-significance claim (that needs a realistic LD/design calibration and
# is the gate, #48, that holds the R `gwas()` significance wording), and there is
# no external comparator (permutation-GWAS in PLINK max(T) / GenABEL) yet.

# Per-scan maximum statistic: max chi-square (default) or max -log10 p over the
# scanned markers. The maximum is the genome-wide statistic whose null
# distribution calibrates the threshold (it captures marker correlation because the
# markers are scanned together).
function _scan_max_statistic(scan; statistic::Symbol = :chisq)
    if statistic === :chisq
        hasproperty(scan, :chisq) ||
            throw(ArgumentError("scan must have a :chisq field for statistic = :chisq"))
        m = maximum(Float64.(scan.chisq))
    elseif statistic === :neglog10p
        hasproperty(scan, :p_values) ||
            throw(ArgumentError("scan must have a :p_values field for statistic = :neglog10p"))
        m = maximum(-log10.(max.(Float64.(scan.p_values), floatmin(Float64))))
    else
        throw(ArgumentError("statistic must be :chisq or :neglog10p"))
    end
    isfinite(m) ||
        throw(ArgumentError("scan statistic contained non-finite values (NaN/Inf)"))
    return m
end

# Deterministic empirical quantile (type-7 / linear interpolation, the R default),
# implemented in-package to avoid a Statistics dependency and any cross-version
# convention drift.
function _empirical_upper_quantile(values::AbstractVector{<:Real}, prob::Real)
    0 <= prob <= 1 || throw(ArgumentError("prob must be in [0, 1]"))
    isempty(values) && throw(ArgumentError("values must be non-empty"))
    v = sort!(Float64.(collect(values)))
    n = length(v)
    n == 1 && return v[1]
    h = (n - 1) * prob + 1            # 1-based interpolated position
    lo = floor(Int, h)
    lo >= n && return v[n]
    frac = h - lo
    return v[lo] + frac * (v[lo + 1] - v[lo])
end

"""
    genome_wide_threshold_from_null(null_max_statistics; alpha = 0.05, statistic = :chisq)

Turn a SUPPLIED empirical null distribution of per-scan maximum statistics into a
genome-wide significance threshold at level `alpha`: the `(1 - alpha)` empirical
quantile of `null_max_statistics`. Returns `(threshold, alpha, statistic, n_null)`.

The null distribution is the set of per-permutation (or per-null-simulation)
maxima (the internal `_scan_max_statistic` extracts the max chi-square / max
-log10 p of a scan); generate it with the opt-in
`sim/phase5_threshold_calibration.jl` harness (phenotype permutation re-runs the
marker scan, so the maximum is correlation/LD-aware). Because it uses the
distribution of the MAXIMUM over the jointly-scanned markers, the threshold is
correlation-aware; it may be less conservative than Bonferroni when markers are
strongly redundant, but a finite empirical threshold is not guaranteed to sit
below Bonferroni.

The `(1 - alpha)` type-7 quantile threshold and the add-one [`genome_wide_pvalue`](@ref)
are two DIFFERENT estimators of the same level: they agree asymptotically, but at
small `n_null` the quantile threshold is mildly anti-conservative (e.g. for
`n_null = 100`, `alpha = 0.05`, an observed value exactly at the threshold has an
add-one p of `6/101 ≈ 0.059`, not `0.05`). `genome_wide_pvalue` is the exact /
conservative decision rule; use the quantile `threshold` for display and the
add-one p-value for the formal accept/reject.

EXPERIMENTAL, validation-scale: this calibrates a threshold FROM a supplied null;
it is not itself a production genome-wide-significance claim (that needs a
realistic-design calibration — the #48 gate) and has no external comparator yet.
"""
function genome_wide_threshold_from_null(null_max_statistics::AbstractVector{<:Real};
                                         alpha::Real = 0.05, statistic::Symbol = :chisq)
    0 < alpha < 1 || throw(ArgumentError("alpha must be in (0, 1)"))
    statistic in (:chisq, :neglog10p) ||
        throw(ArgumentError("statistic must be :chisq or :neglog10p"))
    isempty(null_max_statistics) &&
        throw(ArgumentError("null_max_statistics must be non-empty"))
    nulls = Float64.(collect(null_max_statistics))
    all(isfinite, nulls) ||
        throw(ArgumentError("null_max_statistics must contain only finite values"))
    return (
        threshold = _empirical_upper_quantile(nulls, 1 - alpha),
        alpha = Float64(alpha),
        statistic = statistic,
        n_null = length(nulls),
    )
end

"""
    genome_wide_pvalue(observed, null_max_statistics)

Empirical genome-wide p-value for an `observed` per-scan maximum statistic against
a SUPPLIED null distribution of maxima: `(1 + #{null ≥ observed}) / (n_null + 1)`
(the standard add-one permutation p-value, so it is never 0). The same null
distribution feeds [`genome_wide_threshold_from_null`](@ref). EXPERIMENTAL,
validation-scale; not a production genome-wide-significance claim.
"""
function genome_wide_pvalue(observed::Real, null_max_statistics::AbstractVector{<:Real})
    isempty(null_max_statistics) &&
        throw(ArgumentError("null_max_statistics must be non-empty"))
    isfinite(observed) || throw(ArgumentError("observed must be finite"))
    nulls = Float64.(collect(null_max_statistics))
    all(isfinite, nulls) ||
        throw(ArgumentError("null_max_statistics must be finite"))
    return (1 + count(>=(Float64(observed)), nulls)) / (length(nulls) + 1)
end

"""
    genome_wide_marker_scan(y, X, markers; n_permutations = 1000, alpha = 0.05,
                            sigma_e2 = 1.0, allele_frequencies = nothing,
                            marker_ids = nothing, rng = Random.default_rng())

Genome-wide-CALIBRATED fixed-effect single-marker scan. Runs [`single_marker_scan`](@ref),
then builds a PER-DATASET residual-permutation null of the per-scan MAXIMUM chi-square
(permute the residuals of `y` on `X`, re-scan `n_permutations` times) and returns the
exact/conservative add-one genome-wide p-value ([`genome_wide_pvalue`](@ref)) for the
observed maximum AND for each marker, plus the `(1 - alpha)` permutation threshold.

This is the EXACT per-dataset permutation test (Phipson–Smyth add-one): the null is rebuilt
for THIS `y`, NOT reused across datasets. Its family-wise type-I control is validated at
validation scale (`sim/phase5_qtl_addone_gate.jl` + `…_design_sweep.jl`) AND production scale
(`sim/phase5_qtl_rebuild_production_gate.jl`, type-I at α). The fixed-null-REUSE shortcut is
mildly anti-conservative (a documented simulation caveat); this per-dataset rule is the
calibrated path.

SCOPE: fixed-effect `X` only (intercept or supplied covariates) — the validated calibration.
The relatedness-corrected MIXED-model genome-wide null (permuting under `V = σ²a ZAZ' + σ²e I`)
is a DIFFERENT, not-yet-validated calibration and is NOT this function.

Returns the [`single_marker_scan`](@ref) fields plus `genome_wide_p_values` (per marker),
`genome_wide_threshold`, `genome_wide_p_min` (the top marker's genome-wide p), `n_permutations`,
`alpha`, `null_max`, a `calibration` NamedTuple, and `target = :genome_wide_marker_scan`.
"""
function genome_wide_marker_scan(
    y::AbstractVector,
    X::AbstractMatrix,
    markers::AbstractMatrix;
    n_permutations::Integer = 1000,
    alpha::Real = 0.05,
    sigma_e2::Real = 1.0,
    allele_frequencies::Union{Nothing,AbstractVector} = nothing,
    marker_ids = nothing,
    rng::AbstractRNG = Random.default_rng(),
)
    n_permutations > 0 || throw(ArgumentError("n_permutations must be positive"))
    0 < alpha < 1 || throw(ArgumentError("alpha must be in (0, 1)"))
    sigma_e2 > 0 || throw(ArgumentError("sigma_e2 must be positive"))

    scan = single_marker_scan(y, X, markers; sigma_e2 = sigma_e2,
                              allele_frequencies = allele_frequencies,
                              marker_ids = marker_ids)

    yv = Float64.(y)
    Xmat = Matrix{Float64}(X)
    n = length(yv)
    # residual permutation conditional on X (the per-dataset null)
    beta = Symmetric(transpose(Xmat) * Xmat) \ (transpose(Xmat) * yv)
    fitted = Xmat * beta
    resid = yv .- fitted
    null_max = Vector{Float64}(undef, n_permutations)
    for i in 1:n_permutations
        yp = fitted .+ resid[randperm(rng, n)]
        sc = single_marker_scan(yp, Xmat, markers; sigma_e2 = sigma_e2,
                                allele_frequencies = allele_frequencies,
                                marker_ids = marker_ids)
        null_max[i] = _scan_max_statistic(sc; statistic = :chisq)
    end

    thr = genome_wide_threshold_from_null(null_max; alpha = alpha, statistic = :chisq)
    genome_wide_p_values = [genome_wide_pvalue(c, null_max) for c in scan.chisq]
    obs_max = maximum(scan.chisq)
    genome_wide_p_min = genome_wide_pvalue(obs_max, null_max)

    return (
        marker_ids = scan.marker_ids,
        effects = scan.effects,
        standard_errors = scan.standard_errors,
        z_scores = scan.z_scores,
        chisq = scan.chisq,
        p_values = scan.p_values,
        bonferroni_p_values = scan.bonferroni_p_values,
        bh_q_values = scan.bh_q_values,
        lod_scores = scan.lod_scores,
        denominators = scan.denominators,
        p = scan.p,
        k = scan.k,
        genome_wide_p_values = genome_wide_p_values,
        genome_wide_threshold = thr.threshold,
        genome_wide_p_min = genome_wide_p_min,
        n_permutations = Int(n_permutations),
        alpha = Float64(alpha),
        null_max = null_max,
        calibration = (
            method = :permutation_addone,
            alpha = Float64(alpha),
            n_permutations = Int(n_permutations),
            threshold = thr.threshold,
            statistic = :chisq,
            marker_panel_mode = :fixed,
            rebuilt_per_dataset = true,
        ),
        target = :genome_wide_marker_scan,
    )
end
