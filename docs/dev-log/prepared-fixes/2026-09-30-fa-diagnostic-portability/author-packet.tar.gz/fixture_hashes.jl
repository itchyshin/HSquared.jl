using HSquared
using LinearAlgebra
using Random
using Statistics
using Test

function fa_multistart_fixture(seed)
    rng = MersenneTwister(seed)
    ids = collect(1:12)
    sire = [0, 0, 0, 0, 1, 1, 2, 3, 5, 5, 6, 7]
    dam = [0, 0, 0, 0, 2, 3, 3, 4, 6, 7, 8, 9]
    ped = normalize_pedigree(ids, sire, dam)
    Ainv = pedigree_inverse(ped)
    A = Matrix(inv(Symmetric(Matrix(Ainv))))
    Λ = reshape([1.0, 0.8, 0.65, 0.5], 4, 1)
    ψ = [0.35, 0.4, 0.5, 0.45]
    G = Matrix(factor_analytic_covariance(Λ, ψ))
    R = [1.0 0.12 0.0 0.0; 0.12 0.9 0.08 0.0; 0.0 0.08 0.85 0.07; 0.0 0.0 0.07 0.8]
    U = cholesky(Symmetric(A)).L * randn(rng, 12, 4) * transpose(cholesky(Symmetric(G)).L)
    LR = cholesky(Symmetric(R)).L
    Y = Matrix{Float64}(undef, 24, 4)
    Z = zeros(24, 12)
    row = 0
    for animal in 1:12, _ in 1:2
        row += 1
        Z[row, animal] = 1.0
        Y[row, :] .= [0.3, -0.4, 0.5, 1.0] .+ U[animal, :] .+
                     (transpose(randn(rng, 4)) * transpose(LR))[:]
    end
    return (; Y, X = ones(24, 1), Z, Ainv, ids, G, R)
end

using SHA
fingerprint(A) = bytes2hex(sha256(reinterpret(UInt8,vec(Matrix{Float64}(A)))))
for seed in (20260927,20260928)
    d=fa_multistart_fixture(seed)
    rng=MersenneTwister(seed)
    draws=vcat(vec(randn(rng,12,4)), reduce(vcat,[randn(rng,4) for _ in 1:24]))
    println("seed=",seed," Y=",fingerprint(d.Y)," Ainv=",fingerprint(d.Ainv)," G=",fingerprint(d.G)," R=",fingerprint(d.R)," normal_draws=",bytes2hex(sha256(reinterpret(UInt8,draws))))
end
