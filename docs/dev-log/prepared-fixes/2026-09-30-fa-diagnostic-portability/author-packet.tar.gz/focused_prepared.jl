file = joinpath(@__DIR__, "test-prepared.jl")
source = read(file, String)
focused = first(split(source, "@testset \"Gaussian FA fit transforms with trait units away from the floor\" begin"))
include_string(Main, focused, file)
