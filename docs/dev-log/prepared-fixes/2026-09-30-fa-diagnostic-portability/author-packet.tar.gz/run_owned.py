import json, os, signal, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
root=Path(__file__).resolve().parent
exe,driver,label,budget=sys.argv[1:]
budget=float(budget)
env=os.environ.copy()
env.update(OPENBLAS_NUM_THREADS='1', JULIA_NUM_THREADS='1', JULIA_PKG_OFFLINE='true',
           JULIA_DEPOT_PATH='/private/tmp/hsq-goal-julia-depot:/Users/z3437171/.julia')
command=[exe,'--startup-file=no','--project=/Users/z3437171/.codex/worktrees/hsquared-fa-gllvm-foundations/HSquared.jl',str(root/driver)]
start=datetime.now(timezone.utc).isoformat(); tick=time.monotonic(); over=False
with (root/'logs'/f'{label}.log').open('w') as log:
    process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try: code=process.wait(timeout=budget)
    except subprocess.TimeoutExpired:
        over=True; os.killpg(process.pid,signal.SIGTERM)
        try: code=process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL); code=process.wait()
result=dict(start_utc=start,elapsed_seconds=time.monotonic()-tick,exit_status=code,
            over_estimate=over,estimate_seconds=budget,command=command,
            julia_threads=1,blas_threads=1)
(root/'logs'/f'{label}-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result)); sys.exit(1 if over else code)
