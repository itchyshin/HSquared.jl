using Test, HSquared, LinearAlgebra
@testset "Astra deterministic FA selector challenge" begin
    row(v,c,o) = (;valid=v,converged=c,objective=o)
    cases = [
        ([row(true,true,4.),row(true,false,3.)],1),
        ([row(true,false,3.),row(true,true,4.)],2),
        ([row(true,false,4.),row(true,false,3.)],2),
        ([row(true,true,4.),row(true,true,3.)],2),
        ([row(false,true,-100.),row(true,false,3.)],2),
        ([row(true,true,Inf),row(true,false,3.)],2),
        ([row(true,true,NaN),row(true,false,3.)],2),
        ([row(true,true,3.),row(true,true,3.)],1),
    ]
    for (attempts,expected) in cases
        @test HSquared._select_multivariate_fit_attempt(attempts) == expected
    end
    @test_throws ArgumentError HSquared._select_multivariate_fit_attempt([row(false,true,0.)])
    @test_throws ArgumentError HSquared._select_multivariate_fit_attempt([row(true,true,Inf)])
end
@testset "Astra independent whitened information Gram oracle" begin
    t=4; q=4; n=8
    A = [1.0 .2 .1 .05; .2 1.0 .25 .1; .1 .25 1.0 .3; .05 .1 .3 1.0]
    Z = kron(Matrix{Float64}(I,q,q),ones(2,1))
    lambda = [1.0,.8,.65,.5]; psi=[.35,.4,.5,.45]
    G=lambda*lambda'+Diagonal(psi)
    R=[1.0 .12 0.0 0.0; .12 .9 .08 0.0; 0.0 .08 .85 .07; 0.0 0.0 .07 .8]
    K=Z*A*Z'; V=kron(K,G)+kron(Matrix{Float64}(I,n,n),R)
    X=kron(ones(n,1),Matrix{Float64}(I,t,t)); L=cholesky(Symmetric(V)).L
    W=L\X; Q=Matrix(qr(W).Q)[:,1:t]
    projector=Matrix{Float64}(I,n*t,n*t)-Q*Q'
    derivatives=Matrix{Float64}[]
    for i in 1:t
        e=zeros(t);e[i]=1
        push!(derivatives,kron(K,e*lambda'+lambda*e'))
    end
    for i in 1:t
        d=zeros(t,t);d[i,i]=1;push!(derivatives,kron(K,d))
    end
    for j in 1:t,i in 1:j
        d=zeros(t,t);d[i,j]=d[j,i]=1
        push!(derivatives,kron(Matrix{Float64}(I,n,n),d))
    end
    whitened=[projector*(L\D/L')*projector for D in derivatives]
    raw=[dot(a,b)/2 for a in whitened,b in whitened]
    gd=diag(G);scale=vcat(sqrt.(gd),gd,[sqrt(gd[i]*gd[j]) for j in 1:t for i in 1:j])
    oracle=Diagonal(scale)*raw*Diagonal(scale)
    reported=_fa_expected_reml_information(A,Z,reshape(lambda,t,1),psi,R)
    @test Matrix(reported) ≈ oracle atol=2e-12 rtol=2e-12
    @test minimum(eigvals(Symmetric(oracle))) > 1e-8*maximum(eigvals(Symmetric(oracle)))
    @test size(oracle)==(18,18)
    # Destroy genetic information while retaining estimable residual covariance.
    absent=_fa_expected_reml_information(A,zeros(n,q),reshape(lambda,t,1),psi,R)
    @test maximum(abs,absent[1:8,:]) == 0
    @test count(>(1e-8*maximum(eigvals(absent))),eigvals(absent)) == 10
end
