using Test, HSquared, LinearAlgebra
BLAS.set_num_threads(1)
include("test_fa_likelihood_information.jl")
include("independent-controls.jl")
