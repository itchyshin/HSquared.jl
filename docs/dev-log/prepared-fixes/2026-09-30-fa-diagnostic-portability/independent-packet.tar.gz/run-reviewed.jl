using Test, HSquared, LinearAlgebra
BLAS.set_num_threads(1)
println((VERSION,Sys.ARCH,BLAS.get_config()))
include("focused_prepared.jl")
include("independent-controls.jl")
