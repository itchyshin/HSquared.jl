# FA diagnostic contracts: independent review notes

Source inspected before author proposal: multivariate.jl f975657ef43d86045171a9265e5536370043a46fc72880a3e80ee87fcad699c2, full source tree 59d4a803e4d290a840927b4bce26ea4722f4404c009c171d173ba0c300c7d76e, HEAD ec9414c35d7621c6bd4321a9d16067ac9a2ea2eb. This is an independent review preparation note, not the final proposal verdict.

## Selection

Eligible attempts have a finite objective and valid covariance. If any eligible attempt converged, restrict selection to converged attempts; otherwise use every eligible attempt. Minimize negative log likelihood within that set. The first eligible minimizer wins an exact tie. A lower objective from an unconverged attempt must not displace a converged fit. Invalid or nonfinite attempts cannot displace any valid candidate.

These conditions do not prescribe whether a given seed produces mixed convergence statuses. Independent controls cover both orders of a mixed pair, all-converged, all-unconverged, invalid/nonfinite candidates, ties, and absence of any eligible candidate: 10 assertions pass.

## Disagreement and warning fields

For two valid genetic covariance estimates, disagreement is their Frobenius distance divided by the larger Frobenius norm, with an eps floor. Residual disagreement follows the same definition. It can be zero or close to zero; the contract supplies no positive lower bound. Different datasets and optimization trajectories can yield different disagreement values without a software defect. The diagnostic should equal a recomputation from independent individual-start fits.

Objective range equals the maximum finite valid objective minus its minimum, equivalently the range of valid log likelihoods. A better-nonconverged warning is true exactly when an eligible nonconverged attempt has larger log likelihood than the selected fit. Its value must follow the actual attempts, not a seeded expectation.

## Uniqueness and inference

The returned FA covariance is Lambda Lambda' + diag(psi), with psi at least the frozen absolute variance floor 1e-4. The diagnostic floor distance is min(psi-1e-4); near-floor means that distance is at most 0.01*1e-4. The diagnostic flag is not evidence of regular inference. Away from the floor, changing trait units transforms variances quadratically; the fixed absolute floor is not globally unit-equivariant.

For a marginal Gaussian covariance V and fixed-effect design X, expected REML information in natural covariance coordinates is I_ab = tr(P V_a P V_b)/2, where P=V^-1-V^-1 X(X'V^-1 X)^-1 X'V^-1. The test helper applies diagonal coordinate scales after this calculation. My independent calculation whitens by a Cholesky factor of V, projects out a QR basis of the whitened X, and forms the Frobenius Gram matrix of projected whitened derivatives. Agreement, positive 18-dimensional rank at the chosen generic repeated-record point, and rank collapse to 10 after removing genetic incidence all pass. This does not turn expected information at a fitted near-floor point into observed curvature or an interval-coverage claim.

## Failure interpretation

The original failures demanded G disagreement greater than 0.1, R disagreement greater than 0.05, and at least one unconverged start for a second seed. All three concern a realized optimizer outcome, not one of the mathematical contracts above. The measured source uses identical estimator bytes across the comparison. Author logs separately establish different normal draws and Y hashes on Julia1.10.0 and Julia1.13.1 for both seeds, while Ainv/G/R hashes match. That identifies changed input data; it does not establish any general statement about all Julia releases or platforms.

No current evidence from these three assertions requires changing estimator code, scientific tolerances, or the frozen FA campaign. The final test-only proposal still requires exact replay and independent inspection.
