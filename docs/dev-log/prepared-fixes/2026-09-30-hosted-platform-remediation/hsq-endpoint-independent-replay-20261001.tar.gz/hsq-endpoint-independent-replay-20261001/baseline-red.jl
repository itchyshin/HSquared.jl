using Test, HSquared, LinearAlgebra, SparseArrays
include("/private/tmp/hsq-genomic-endpoint-roundoff-fix-20261001/fixture.jl")
f=boundary_fixture(:lower)
s=animal_model_spec(0.2 .* f.spec.y,f.spec.X,f.spec.Z,f.spec.Ainv;ids=f.spec.ids,method=:REML)
p=HSquared._genomic_boundary_precheck(s,f.provenance,f.K)
a=HSquared._genomic_boundary_profile(s,p)
println("baseline_profile=",a)
@test a.status=="boundary_lower"
