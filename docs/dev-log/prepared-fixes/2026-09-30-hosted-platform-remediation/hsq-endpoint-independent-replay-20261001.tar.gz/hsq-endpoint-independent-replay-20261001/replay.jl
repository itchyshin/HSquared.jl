using Test, HSquared, LinearAlgebra, SparseArrays
BLAS.set_num_threads(1)
author="/private/tmp/hsq-genomic-endpoint-roundoff-fix-20261001"
include(joinpath(author,"run-final.jl"))
function independent_ll(c,r)
 h=BigFloat(r).*BigFloat.(c.eigenvalues).+(1-BigFloat(r));Hi=Diagonal(inv.(h));X=BigFloat.(c.X);y=BigFloat.(c.y)
 F=X'*Hi*X;rhs=X'*Hi*y;quad=dot(y,Hi*y)-dot(rhs,F\rhs);df=c.n-c.p
 -.5*(df*(1+log(2big(pi)*quad/df))+sum(log,h)+logdet(F))
end
@testset "independent endpoint context controls" begin
 c=(eigenvalues=[2.,.5,1.,3.,.7,1.6],y=[1.,-1.,.5,2.,-.2,.1],X=hcat(ones(6),[-2.,-1.,0.,1.,2.,3.]),n=6,p=2)
 for r in (1e-10,1-1e-10)
  e=r<.5 ? 0. : 1.; expected=independent_ll(c,r)>independent_ll(c,e)
  for cc in (c,merge(c,(X=c.X*[1. 2.;0. 3.],)),merge(c,(y=0.2 .* c.y,)),merge(c,(eigenvalues=reverse(c.eigenvalues),y=reverse(c.y),X=c.X[end:-1:1,:])))
   l=HSquared._genomic_profile_reml(cc,e).loglik
   @test HSquared._genomic_endpoint_adjacent_improves(cc,r,l,l,l)===expected
  end
 end
 for bad in (merge(c,(y=fill(Inf,6),)),merge(c,(eigenvalues=fill(Inf,6),)),merge(c,(X=hcat(ones(6),ones(6)),)))
  @test HSquared._genomic_endpoint_adjacent_improves(bad,1e-10,0.,0.,0.)===nothing
 end
 f=boundary_fixture(:lower);fit=HSquared._fit_ai_reml_genomic_boundary(f.spec;provenance=f.provenance,kernel=f.K)
 @test fit.fit.spec===f.spec
 @test fit.boundary.profile_ratio==0.
 @test fit.boundary.numerical_ratio==1e-7
 @test Base.precision(BigFloat)==256
end
