using HSquared, LinearAlgebra, SparseArrays, Optim
BLAS.set_num_threads(1)
println((VERSION, Sys.ARCH, BLAS.get_config(), pkgversion(Optim)))
include("fixture.jl")
for mode in (:lower,:interior,:upper)
 f=boundary_fixture(mode)
 pre=HSquared._genomic_boundary_precheck(f.spec,f.provenance,f.K)
 c=HSquared._genomic_profile_context(pre)
 grid=collect(0.0:HSquared._GENOMIC_BOUNDARY_GRID_STEP:1.0)
 parts=[HSquared._genomic_profile_reml(c,r) for r in grid]
 vals=[p.loglik for p in parts]
 j=argmax(view(vals,2:length(vals)-1))+1
 opt=optimize(r -> -HSquared._genomic_profile_reml(c,r).loglik,grid[j-1],grid[j+1];abs_tol=1e-12)
 r=Optim.minimizer(opt); v=HSquared._genomic_profile_reml(c,r).loglik
 println((mode=mode,r=r,converged=Optim.converged(opt),adjacent_gain=v-(r<.5 ? first(vals) : last(vals)),d0=HSquared._genomic_profile_derivative(c,0.0),d1=HSquared._genomic_profile_derivative(c,1.0),profile=HSquared._genomic_boundary_profile(f.spec,pre)))
 result=HSquared._fit_ai_reml_genomic_boundary(f.spec;provenance=f.provenance,kernel=f.K)
 println(result.boundary)
end
