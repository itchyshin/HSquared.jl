    function boundary_fixture(mode)
        # Deliberately construct strong lower/interior/upper profile targets.
        # Do not regenerate endpoint expectations from a stdlib RNG: randn's
        # seeded stream changed between Julia 1.10 and 1.12.
        values = repeat(collect(range(0.25, 4.0; length = 20)), inner = 2)
        n = length(values)
        exponent = mode == :lower ? 0.0 : mode == :interior ? 0.3 :
                   mode == :upper ? 0.75 : error("unknown boundary fixture mode")
        signs = repeat([1.0, -1.0], n ÷ 2)
        y = signs .* values .^ exponent
        K = Matrix(Diagonal(values))
        Q = Matrix(Diagonal(1 ./ values))
        ids = ["id$(i)" for i in 1:n]
        provenance = (
            relationship_source = "markers",
            relationship_method = "deterministic_test_kernel",
            allele_frequency_source = "deterministic_test",
            ridge = 0.0,
            scale_denominator = 1.0,
            relationship_scale = "K_test",
            id_order_fingerprint = HSquared._genomic_id_order_fingerprint(ids),
            marker_content_fingerprint = repeat("0", 64),
            kernel_fingerprint = HSquared._genomic_matrix_fingerprint("K_lambda", K, ids),
            precision_fingerprint = HSquared._genomic_matrix_fingerprint("Q_lambda", Q, ids),
        )
        spec = animal_model_spec(y, ones(n, 1), sparse(1.0I, n, n), Q;
                                 ids = ids, method = :REML)
        return (spec = spec, provenance = provenance, K = K)
    end
