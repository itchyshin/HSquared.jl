@testset "v0.7 genomic closed-boundary resolution (doc 46)" begin
    function boundary_fixture(mode)
        # Deliberately construct strong lower/interior/upper profile targets.
        # Do not regenerate endpoint expectations from a stdlib RNG: randn's
        # seeded stream changed between Julia 1.10 and 1.12.
        values = repeat(collect(range(0.25, 4.0; length = 20)), inner = 2)
        n = length(values)
        exponent = mode == :lower ? 0.0 : mode == :interior ? 0.3 :
                   mode == :upper ? 0.75 : error("unknown boundary fixture mode")
        signs = repeat([1.0, -1.0], n ÷ 2)
        y = signs .* values .^ exponent
        K = Matrix(Diagonal(values))
        Q = Matrix(Diagonal(1 ./ values))
        ids = ["id$(i)" for i in 1:n]
        provenance = (
            relationship_source = "markers",
            relationship_method = "deterministic_test_kernel",
            allele_frequency_source = "deterministic_test",
            ridge = 0.0,
            scale_denominator = 1.0,
            relationship_scale = "K_test",
            id_order_fingerprint = HSquared._genomic_id_order_fingerprint(ids),
            marker_content_fingerprint = repeat("0", 64),
            kernel_fingerprint = HSquared._genomic_matrix_fingerprint("K_lambda", K, ids),
            precision_fingerprint = HSquared._genomic_matrix_fingerprint("Q_lambda", Q, ids),
        )
        spec = animal_model_spec(y, ones(n, 1), sparse(1.0I, n, n), Q;
                                 ids = ids, method = :REML)
        return (spec = spec, provenance = provenance, K = K)
    end

    @test HSquared._GENOMIC_BOUNDARY_EPSILON == 1e-7
    @test HSquared._GENOMIC_BOUNDARY_GRID_STEP == 0.0025
    @test HSquared._GENOMIC_BOUNDARY_DELTA == 1e-6
    @test HSquared._GENOMIC_BOUNDARY_KKT_TOL == 1e-8
    @test HSquared._GENOMIC_BOUNDARY_DOC46_COMMIT == "fe96a147"
    @test HSquared._GENOMIC_BOUNDARY_DOC46_SHA256 ==
          "283ab00bab3da925f0ac2916959efacaa7fb711c5da4dce09dd49ea568eef030"

    lower_fixture = boundary_fixture(:lower)
    lower = HSquared._fit_ai_reml_genomic_boundary(lower_fixture.spec;
        provenance = lower_fixture.provenance, kernel = lower_fixture.K)
    @test lower.boundary.status == "boundary_lower"
    @test lower.boundary.profile_ratio == 0.0
    @test lower.boundary.numerical_ratio == 1e-7
    @test lower.fit.converged
    @test lower.fit.optimizer_status == "boundary_lower"
    @test lower.fit.variance_components.sigma_a2 > 0
    @test lower.fit.variance_components.sigma_e2 > 0
    @test abs(lower.fit.likelihood.loglik - lower.boundary.profile_loglik) /
          length(lower_fixture.spec.y) <= 1e-8
    @test lower.boundary.lower_derivative_per_observation <= 1e-8

    upper_fixture = boundary_fixture(:upper)
    upper = HSquared._fit_ai_reml_genomic_boundary(upper_fixture.spec;
        provenance = upper_fixture.provenance, kernel = upper_fixture.K)
    @test upper.boundary.status == "boundary_upper"
    @test upper.boundary.profile_ratio == 1.0
    @test upper.boundary.numerical_ratio == 1 - 1e-7
    @test upper.fit.converged
    @test upper.fit.optimizer_status == "boundary_upper"
    # This compares the epsilon representation (r = 1 - 1e-7) with the exact
    # r = 1 profile. Its first-order gap is about 1e-8 per observation; Julia
    # 1.12 BLAS/LAPACK variation raises the observed gap to 1.09e-8.
    @test abs(upper.fit.likelihood.loglik - upper.boundary.profile_loglik) /
          length(upper_fixture.spec.y) <= 2e-8
    @test upper.boundary.upper_derivative_per_observation >= -1e-8

    interior_fixture = boundary_fixture(:interior)
    interior_spec = interior_fixture.spec
    ordinary = fit_ai_reml(interior_spec)
    interior = HSquared._fit_ai_reml_genomic_boundary(interior_spec;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K)
    @test interior.boundary.status == "interior"
    @test interior.fit.variance_components == ordinary.variance_components
    @test interior.fit.likelihood.loglik == ordinary.likelihood.loglik
    @test interior.fit.optimizer_status == ordinary.optimizer_status
    @test 1e-7 < interior.boundary.profile_ratio < 1 - 1e-7
    @test all(isfinite, (interior.boundary.profile_loglik,
                         interior.boundary.lower_derivative_per_observation,
                         interior.boundary.upper_derivative_per_observation))

    # The eigen-rotated evaluator is a performance rewrite of the frozen dense-H
    # formula, so compare the two directly at both endpoints and an interior r.
    precheck = HSquared._genomic_boundary_precheck(
        interior_spec, interior_fixture.provenance, interior_fixture.K)
    context = HSquared._genomic_profile_context(precheck)
    n_boundary = length(interior_spec.y)
    K_reconstructed = Matrix(precheck.qfactor \ Matrix{Float64}(I, n_boundary, n_boundary))
    function dense_profile(r)
        H = Symmetric(r .* K_reconstructed .+
                      (1-r) .* Matrix{Float64}(I, n_boundary, n_boundary))
        F = cholesky(H)
        hi_x = F \ Matrix(interior_spec.X)
        hi_y = F \ Vector(interior_spec.y)
        fixed = cholesky(Symmetric(transpose(interior_spec.X) * hi_x))
        rhs = transpose(interior_spec.X) * hi_y
        quad = dot(interior_spec.y, hi_y) - dot(rhs, fixed \ rhs)
        df = n_boundary - size(interior_spec.X, 2)
        t_hat = quad / df
        ll = -0.5 * (df * (1 + log(2pi*t_hat)) +
            2sum(log, diag(F.U)) + 2sum(log, diag(fixed.U)))
        (loglik=ll, t_hat=t_hat)
    end
    for r in (0.0, 0.37, 1.0)
        fast = HSquared._genomic_profile_reml(context, r)
        dense = dense_profile(r)
        @test fast.loglik ≈ dense.loglik atol=1e-10 rtol=0
        @test fast.t_hat ≈ dense.t_hat atol=1e-10 rtol=0
    end

    supplied_provenance = HSquared._genomic_precision_provenance(
        Matrix(interior_spec.Ainv), interior_spec.ids)
    supplied_route = HSquared._fit_ai_reml_genomic_boundary(interior_spec;
        provenance = supplied_provenance)
    @test supplied_route.boundary.profile_ratio == interior.boundary.profile_ratio
    @test supplied_route.boundary.profile_loglik == interior.boundary.profile_loglik

    bad_z = animal_model_spec(interior_spec.y, interior_spec.X,
        sparse(circshift(Matrix{Float64}(I, n_boundary, n_boundary), (0, 1))), interior_spec.Ainv;
        ids = interior_spec.ids, method = :REML)
    unresolved = HSquared._fit_ai_reml_genomic_boundary(bad_z;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K)
    @test unresolved.boundary.status == "boundary_unresolved"
    @test unresolved.boundary.reason == "nonidentity_Z"
    @test unresolved.fit === nothing
    @test unresolved.boundary.profile_ratio === nothing
    @test unresolved.boundary.numerical_ratio === nothing

    rescued = HSquared._fit_ai_reml_genomic_boundary(interior_spec;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K,
        iterations = 1)
    @test rescued.boundary.status == "interior_rescued"
    @test rescued.fit.converged
    @test rescued.fit.optimizer_status == "interior_rescued"
    @test abs(rescued.fit.likelihood.loglik - rescued.boundary.profile_loglik) /
          n_boundary <= 1e-8

    Q = Matrix(interior_spec.Ainv)
    asymmetric = copy(Q); asymmetric[1, 2] += 0.1
    asymmetric_spec = animal_model_spec(interior_spec.y, interior_spec.X,
        interior_spec.Z, asymmetric; ids = interior_spec.ids, method = :REML)
    asymmetric_result = HSquared._fit_ai_reml_genomic_boundary(asymmetric_spec;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K)
    @test asymmetric_result.fit === nothing
    @test asymmetric_result.boundary.reason == "asymmetric_precision"

    nonfinite_y = copy(interior_spec.y); nonfinite_y[1] = NaN
    nonfinite_y_spec = animal_model_spec(nonfinite_y, interior_spec.X,
        interior_spec.Z, interior_spec.Ainv; ids = interior_spec.ids, method = :REML)
    @test HSquared._fit_ai_reml_genomic_boundary(nonfinite_y_spec;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K).boundary.reason == "nonfinite_y"

    nonfinite_q = copy(Q); nonfinite_q[1, 1] = NaN
    nonfinite_q_spec = animal_model_spec(interior_spec.y, interior_spec.X,
        interior_spec.Z, nonfinite_q; ids = interior_spec.ids, method = :REML)
    @test HSquared._fit_ai_reml_genomic_boundary(nonfinite_q_spec;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K).boundary.reason == "nonfinite_precision"

    indefinite_q = copy(Q); indefinite_q[1, 1] = -1
    indefinite_q_spec = animal_model_spec(interior_spec.y, interior_spec.X,
        interior_spec.Z, indefinite_q; ids = interior_spec.ids, method = :REML)
    @test HSquared._fit_ai_reml_genomic_boundary(indefinite_q_spec;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K).boundary.reason == "nonpositive_precision"

    rank_bad_X = hcat(interior_spec.X, interior_spec.X)
    rank_bad_spec = animal_model_spec(interior_spec.y, rank_bad_X,
        interior_spec.Z, interior_spec.Ainv; ids = interior_spec.ids, method = :REML)
    @test HSquared._fit_ai_reml_genomic_boundary(rank_bad_spec;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K).boundary.reason == "rank_deficient_X"

    ml_spec = animal_model_spec(interior_spec.y, interior_spec.X,
        interior_spec.Z, interior_spec.Ainv; ids = interior_spec.ids, method = :ML)
    ml_result = HSquared._fit_ai_reml_genomic_boundary(ml_spec;
        provenance = interior_fixture.provenance, kernel = interior_fixture.K)
    @test ml_result.fit === nothing
    @test ml_result.boundary.reason == "non_reml_method"

    malformed_kernel = fill("not-a-number", size(interior_fixture.K))
    malformed_kernel_result = HSquared._fit_ai_reml_genomic_boundary(interior_spec;
        provenance = interior_fixture.provenance, kernel = malformed_kernel)
    @test malformed_kernel_result.fit === nothing
    @test malformed_kernel_result.boundary.reason == "nonnumeric_marker_kernel"

    @test HSquared._genomic_refinement_accepted(true, 0.4, -10.0, 0.3, 0.5, 10.0, 120)
    @test !HSquared._genomic_refinement_accepted(false, 0.4, -10.0, 0.3, 0.5, 10.0, 120)
    @test !HSquared._genomic_refinement_accepted(true, NaN, -10.0, 0.3, 0.5, 10.0, 120)
    @test !HSquared._genomic_refinement_accepted(true, 0.6, -10.0, 0.3, 0.5, 10.0, 120)

    wrong_provenance = merge(interior_fixture.provenance,
        (precision_fingerprint = repeat("0", 64),))
    @test HSquared._fit_ai_reml_genomic_boundary(interior_spec;
        provenance = wrong_provenance, kernel = interior_fixture.K).boundary.reason == "precision_fingerprint_mismatch"
    nongeno_provenance = merge(interior_fixture.provenance,
        (relationship_source = "pedigree",))
    @test HSquared._fit_ai_reml_genomic_boundary(interior_spec;
        provenance = nongeno_provenance, kernel = interior_fixture.K).boundary.reason == "non_genomic_provenance"

    tie_ids = ["t$(i)" for i in 1:8]
    tie_Q = Matrix{Float64}(I, 8, 8)
    tie_spec = animal_model_spec(collect(1.0:8.0), ones(8, 1),
        sparse(1.0I, 8, 8), tie_Q; ids = tie_ids, method = :REML)
    tie_provenance = HSquared._genomic_precision_provenance(tie_Q, tie_ids)
    tie_result = HSquared._fit_ai_reml_genomic_boundary(tie_spec;
        provenance = tie_provenance, iterations = 1)
    @test tie_result.boundary.status == "boundary_unresolved"
    @test tie_result.boundary.reason == "endpoint_pair_tie"
    @test tie_result.fit !== nothing && !tie_result.fit.converged
    @test tie_result.fit.optimizer_status == "boundary_unresolved"

    endpoint_interior_tie = HSquared._genomic_boundary_classify_candidates(
        10.0, 10.0, 9.0, true, -0.1, -0.1, 120)
    @test endpoint_interior_tie.status == "boundary_unresolved"
    @test endpoint_interior_tie.reason == "endpoint_interior_tie"
    reversed_lower_kkt = HSquared._genomic_boundary_classify_candidates(
        10.0, 9.0, 8.0, true, 0.1, -0.1, 120)
    @test reversed_lower_kkt.status == "boundary_unresolved"
    @test reversed_lower_kkt.reason == "classification_disagreement"

    big_n = 2001
    big_ids = ["big$(i)" for i in 1:big_n]
    big_spec = animal_model_spec(ones(big_n), ones(big_n, 1),
        sparse(1.0I, big_n, big_n), sparse(1.0I, big_n, big_n);
        ids = big_ids, method = :REML)
    big_result = HSquared._fit_ai_reml_genomic_boundary(big_spec;
        provenance = (relationship_source = "supplied_Ginv",
            id_order_fingerprint = "not-read", precision_fingerprint = "not-read"))
    @test big_result.fit === nothing
    @test big_result.boundary.reason == "dense_limit"
end
