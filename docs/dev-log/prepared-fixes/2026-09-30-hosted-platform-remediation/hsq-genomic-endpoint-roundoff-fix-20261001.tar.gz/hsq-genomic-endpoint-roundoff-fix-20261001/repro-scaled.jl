using HSquared, LinearAlgebra, SparseArrays, Optim
BLAS.set_num_threads(1)
include("fixture.jl")
f=boundary_fixture(:lower)
for scale in (0.2,1.0)
 spec=animal_model_spec(scale .* f.spec.y,f.spec.X,f.spec.Z,f.spec.Ainv;ids=f.spec.ids,method=:REML)
 pre=HSquared._genomic_boundary_precheck(spec,f.provenance,f.K)
 c=HSquared._genomic_profile_context(pre)
 println((scale=scale,profile=HSquared._genomic_boundary_profile(spec,pre)))
 r=1e-10
 near=HSquared._genomic_profile_reml(c,r).loglik;lo=HSquared._genomic_profile_reml(c,0.).loglik
 h=BigFloat(r) .* BigFloat.(c.eigenvalues) .+ (1-BigFloat(r))
 oracle=-(length(h)*log(sum(inv,h)/length(h))+sum(log,h))/2
 println((r=r,Float64_gain=near-lo,paired_oracle_gain=oracle,raw_improves=HSquared._genomic_endpoint_adjacent_improves(r,near,lo,-100.)))
end
