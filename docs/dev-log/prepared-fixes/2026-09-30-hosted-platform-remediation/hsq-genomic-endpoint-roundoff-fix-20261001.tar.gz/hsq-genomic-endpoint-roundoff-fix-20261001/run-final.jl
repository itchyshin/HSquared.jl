using Test, HSquared, LinearAlgebra, SparseArrays
BLAS.set_num_threads(1)
println((VERSION,Sys.ARCH,BLAS.get_config(),Base.precision(BigFloat)))
include("package/test/wave4_genomic_endpoint_roundoff.jl")
include("original-doc46.jl")
include("wave4_genomic_boundary_near_endpoint.jl")
