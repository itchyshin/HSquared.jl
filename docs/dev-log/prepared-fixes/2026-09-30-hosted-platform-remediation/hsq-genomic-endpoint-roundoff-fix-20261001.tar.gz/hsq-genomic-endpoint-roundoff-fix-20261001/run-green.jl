using Test, HSquared, LinearAlgebra, SparseArrays
BLAS.set_num_threads(1)
include("endpoint_roundoff_regression.jl")
include("original-doc46.jl")
include("wave4_genomic_boundary_near_endpoint.jl")
