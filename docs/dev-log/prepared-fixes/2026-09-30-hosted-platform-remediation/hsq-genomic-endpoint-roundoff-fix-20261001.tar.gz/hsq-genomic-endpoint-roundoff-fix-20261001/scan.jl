using HSquared, LinearAlgebra, SparseArrays, Optim
BLAS.set_num_threads(1)
include("fixture.jl")
f=boundary_fixture(:lower)
p=HSquared._genomic_boundary_precheck(f.spec,f.provenance,f.K)
c=HSquared._genomic_profile_context(p)
for scale in (0.1,0.2,0.3,0.5,0.7,0.9,1.,1.1,1.2,1.3,1.5,1.7,2.,3.,10.,100.)
 cs=merge(c,(y=scale .* c.y,))
 opt=optimize(r -> -HSquared._genomic_profile_reml(cs,r).loglik,0.,0.005;abs_tol=1e-12)
 rr=Optim.minimizer(opt); lo=HSquared._genomic_profile_reml(cs,0.).loglik
 gain=HSquared._genomic_profile_reml(cs,rr).loglik-lo
 println((scale=scale,r=rr,gain=gain))
end
for rr in (1e-12,1e-11,1e-10,1e-9,5e-9,1e-8,2e-8,3e-8,5e-8,1e-7)
 println((r=rr,gain=HSquared._genomic_profile_reml(c,rr).loglik-HSquared._genomic_profile_reml(c,0.).loglik))
end
