# Iterative (conjugate-gradient) solve of the animal-model MME — the ITERATIVE companion
# of the direct `henderson_mme` factorization. PCG solves the IDENTICAL sparse SPD system
# `C·[β; u] = rhs` (from `_sparse_mme_system`) without forming a Cholesky factor; it is the
# algorithmic primitive the production large-pedigree path needs. Correctness-validated
# (matches the direct solve to a tight tolerance); NOT a production-scale performance claim.

# Preconditioned conjugate gradient for a symmetric positive-definite operator. `applyC`
# is a callable `v ↦ C·v` (a matrix's `*`, or a matrix-free operator). `applyMinv` is a
# callable `r ↦ M⁻¹·r` (the preconditioner solve): `identity` for plain CG, `r ↦ Minv .* r`
# for Jacobi, or the IC(0) back/forward triangular solve for `:ichol`. `x0 = 0`, so the
# initial residual is `b`. Returns `(x, iterations, relative_residual)`.
# Unsupported arithmetic range throws; a finite unconverged iterate is still returned.
function _pcg_solve(applyC, b::Vector{Float64}; tol::Float64, maxiter::Int, applyMinv)
    _require_finite_matrix_free_result("PCG right-hand side", b)
    x = zeros(length(b))
    r = copy(b)
    bnorm = norm(b)
    _require_finite_matrix_free_result("PCG right-hand-side norm", bnorm)
    bnorm == 0 && return x, 0, 0.0
    z = applyMinv(r)
    _require_finite_matrix_free_result("PCG preconditioned residual", z)
    p = copy(z)
    rz = dot(r, z)
    isfinite(rz) && rz > 0 ||
        throw(ArgumentError("PCG residual inner product is outside the supported positive Float64 range"))
    iters = 0
    relres = norm(r) / bnorm
    for k in 1:maxiter
        Cp = applyC(p)
        _require_finite_matrix_free_result("PCG operator product", Cp)
        pCp = dot(p, Cp)
        _require_finite_matrix_free_result("PCG curvature", pCp)
        pCp > 0 ||
            throw(ArgumentError("PCG hit non-positive curvature (pᵀCp = $(pCp)); the system is not positive definite"))
        alpha = rz / pCp
        isfinite(alpha) && alpha > 0 ||
            throw(ArgumentError("PCG step is outside the supported positive Float64 range"))
        @. x += alpha * p
        @. r -= alpha * Cp
        iters = k
        relres = norm(r) / bnorm
        relres <= tol && break
        z = applyMinv(r)
        rz_new = dot(r, z)
        isfinite(rz_new) && rz_new > 0 ||
            throw(ArgumentError("PCG residual inner product is outside the supported positive Float64 range"))
        beta = rz_new / rz
        _require_finite_matrix_free_result("PCG direction update", beta)
        @. p = z + beta * p
        rz = rz_new
    end
    # Report the TRUE residual at the returned x (one extra matvec), not the
    # recursively-accumulated `r` — so `relative_residual`/`converged` are exactly
    # ‖b − Cx‖/‖b‖ regardless of any recursive-residual drift on ill-conditioned input.
    relres = norm(b - applyC(x)) / bnorm
    _require_finite_matrix_free_result("PCG solution", x)
    _require_finite_matrix_free_result("PCG relative residual", relres)
    return x, iters, relres
end

