using Test,HSquared,LinearAlgebra
BLAS.set_num_threads(1)
module BaselinePCG
 using HSquared,LinearAlgebra
 const _require_finite_matrix_free_result=HSquared._require_finite_matrix_free_result
 include("baseline-pcg-function.jl")
end
include("witness.jl")
old,ko,ro=BaselinePCG._pcg_solve(v->C*v,b;tol=1e-9,maxiter=240,applyMinv=identity)
println("baseline iterations=",ko," true_relative_residual=",ro," early_wrong_stop=",ro>1e-9 && ko<240)
@testset "independent PCG restart budget" begin
 for cap in (ko,ko+1,52,53,240)
  x,k,r=HSquared._pcg_solve(v->C*v,b;tol=1e-9,maxiter=cap,applyMinv=identity)
  println("budget=",cap," iterations=",k," true_relative_residual=",r)
  @test k<=cap
  @test r==norm(b-C*x)/norm(b)
  @test r<=1e-9 || k==cap
 end
end
