using Test,HSquared,LinearAlgebra,SparseArrays,Random
BLAS.set_num_threads(1)
println((VERSION,Sys.ARCH,BLAS.get_config(),Threads.nthreads(),BLAS.get_num_threads()))
include("/private/tmp/hsq-pcg-true-residual-fix-20260930/unchanged_ci_fit.jl")
