using Test,HSquared,LinearAlgebra,SparseArrays
BLAS.set_num_threads(1)
println((VERSION,Sys.ARCH,BLAS.get_config(),Threads.nthreads(),BLAS.get_num_threads()))
include("/private/tmp/hsq-pcg-true-residual-fix-20260930/pcg_true_residual_regression.jl")
@testset "independent PCG budget and finite contracts" begin
 for rhs in ([1.0], [1e-100], [1e-160])
  x,k,r=HSquared._pcg_solve(identity,rhs;tol=1e-12,maxiter=1,applyMinv=identity)
  @test x==rhs
  @test k==1
  @test r==0.0
  @test isnothing(HSquared._require_pcg_convergence(r,1e-12))
 end
 x,k,r=HSquared._pcg_solve(identity,[1.0];tol=1e-12,maxiter=0,applyMinv=identity)
 @test x==[0.0]
 @test k==0
 @test r==1.0
 @test_throws ArgumentError HSquared._require_pcg_convergence(r,1e-12)
 @test_throws ArgumentError HSquared._pcg_solve(identity,[1e-300];tol=1e-12,maxiter=3,applyMinv=identity)
 @test_throws ArgumentError HSquared._pcg_solve(identity,[Inf];tol=1e-12,maxiter=3,applyMinv=identity)
 @test_throws ArgumentError HSquared._pcg_solve(identity,[1.0];tol=1e-12,maxiter=3,applyMinv=x->fill(Inf,length(x)))
 @test_throws ArgumentError HSquared._pcg_solve(identity,[1.0];tol=1e-12,maxiter=3,applyMinv=x->-x)
 A=[4. 1.;1. 3.];b=[1.,2.]
 x,k,r=HSquared._pcg_solve(v->A*v,b;tol=1e-12,maxiter=1,applyMinv=identity)
 @test k==1
 @test r==norm(b-A*x)/norm(b)
 @test r>1e-12
 @test_throws ArgumentError HSquared._require_pcg_convergence(r,1e-12)
end
