include("kernel.jl")
include("comparison.jl")
include("fit.jl")
