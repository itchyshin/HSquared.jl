from pathlib import Path
import os,subprocess,json,time,sys
p=Path(__file__).resolve().parent;kind=sys.argv[1];arch=sys.argv[2];e=os.environ.copy();e.update(OPENBLAS_NUM_THREADS='1',JULIA_NUM_THREADS='1',OMP_NUM_THREADS='1',JULIA_PKG_PRECOMPILE_AUTO='0',JULIA_PKG_OFFLINE='true',JULIA_DEPOT_PATH='/private/tmp/hsq-goal-julia-depot:/Users/z3437171/.julia')
binary='/Users/z3437171/.julia/juliaup/julia-1.10.12+0.x64.apple.darwin14/Julia-1.10.app/Contents/Resources/julia/bin/julia' if arch=='intel' else ('/Users/z3437171/.julia/juliaup/julia-1.13.1+0.aarch64.apple.darwin14/Julia-1.13.app/Contents/Resources/julia/bin/julia' if arch=='latest' else '/Users/z3437171/.julia/juliaup/julia-1.10.0+0.aarch64.apple.darwin14/bin/julia');cmd=[binary,'--startup-file=no','--project='+str(p/'package'),str(p/(kind+'.jl'))];t=time.monotonic();cap=120
with (p/(kind+'-'+arch+'.log')).open('w') as f:
 try:c=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=cap);code=c.returncode
 except subprocess.TimeoutExpired:code=124
r={'exit':code,'elapsed':time.monotonic()-t,'estimate':cap,'command':cmd,'julia_threads':1,'blas_threads':1};(p/(kind+'-'+arch+'-result.json')).write_text(json.dumps(r,indent=2)+'\n');print((p/(kind+'-'+arch+'.log')).read_text());print(r);raise SystemExit(code)
