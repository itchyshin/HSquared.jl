using HSquared, LinearAlgebra, Random
BLAS.set_num_threads(1)
for seed in 1:40
    rng=MersenneTwister(seed)
    n=12
    Q=Matrix(qr(randn(rng,n,n)).Q)
    C=Symmetric(Q*Diagonal(exp.(range(0,log(1e8),length=n)))*Q')
    b=randn(rng,n)
    x,k,r=HSquared._pcg_solve(v->C*v,b;tol=1e-9,maxiter=240,applyMinv=identity)
    if r>1e-9 && k<240
        println("WITNESS seed=",seed," iterations=",k," residual=",r)
        open(joinpath(@__DIR__,"witness.txt"),"w") do io
            println(io,"C = Symmetric(",repr(Matrix(C)),")")
            println(io,"b = ",repr(b))
        end
        break
    end
end
