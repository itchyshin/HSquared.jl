using HSquared, Test, Random, SparseArrays, LinearAlgebra
BLAS.set_num_threads(1)
include(joinpath(@__DIR__, "witness.txt"))
x,k,r=HSquared._pcg_solve(v->C*v,b;tol=1e-9,maxiter=240,applyMinv=identity)
println("FIXED_SPD iterations=",k," true_residual=",r," requested=1e-9 budget=240")
include(joinpath(@__DIR__, "unchanged_ci_fit.jl"))
include(joinpath(@__DIR__, "neighbor_tests.jl"))
println("PCG_BOUNDED_INTEGRATION_PASS")
