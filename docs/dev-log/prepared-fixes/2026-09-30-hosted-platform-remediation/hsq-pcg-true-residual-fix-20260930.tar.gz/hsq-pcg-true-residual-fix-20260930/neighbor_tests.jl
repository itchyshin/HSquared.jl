using HSquared,Test,Random,SparseArrays,LinearAlgebra
BLAS.set_num_threads(1)
include("/Users/z3437171/.codex/worktrees/hsquared-fa-gllvm-foundations/HSquared.jl/test/iterative_finite_contracts.jl")
include("/Users/z3437171/.codex/worktrees/hsquared-fa-gllvm-foundations/HSquared.jl/test/wave1_numerical_contracts.jl")
